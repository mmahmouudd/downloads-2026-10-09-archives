import { useState } from 'react';
import { Activity, BacklogItem, ProjectItem, EnergyLog } from './types';
import { useLocalStorage, clearAllData } from './store';
import Budget from './components/Budget';
import Summary from './components/Summary';
import Backlog from './components/Backlog';
import Projects from './components/Projects';
import Energy from './components/Energy';
import Guide from './components/Guide';
import {
  CalendarClock, LayoutDashboard, GraduationCap, FolderKanban, Battery, Compass, Trash2,
} from 'lucide-react';

const TABS = [
  { key: 'guide', label: 'الدليل', icon: Compass },
  { key: 'budget', label: 'ميزانية 168 ساعة', icon: CalendarClock },
  { key: 'summary', label: 'لوحة الملخص', icon: LayoutDashboard },
  { key: 'backlog', label: 'التراكم الدراسي', icon: GraduationCap },
  { key: 'projects', label: 'المشاريع والأفكار', icon: FolderKanban },
  { key: 'energy', label: 'متابعة اليوم', icon: Battery },
] as const;

type TabKey = (typeof TABS)[number]['key'];

export default function App() {
  const [tab, setTab] = useState<TabKey>('budget');
  const [activities, setActivities] = useLocalStorage<Activity[]>('w168-activities', []);
  const [backlog, setBacklog] = useLocalStorage<BacklogItem[]>('w168-backlog', []);
  const [projects, setProjects] = useLocalStorage<ProjectItem[]>('w168-projects', []);
  const [logs, setLogs] = useLocalStorage<EnergyLog[]>('w168-energy', []);

  const handleClear = () => {
    if (confirm('سيتم حذف كل البيانات المحفوظة على هذا الجهاز. متأكد؟')) {
      clearAllData();
      setActivities([]);
      setBacklog([]);
      setProjects([]);
      setLogs([]);
    }
  };

  return (
    <div className="min-h-screen pb-16">
      {/* الترويسة */}
      <header className="bg-white/80 backdrop-blur border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-600 to-sky-500 text-white flex items-center justify-center shadow-md">
              <CalendarClock size={20} />
            </div>
            <div>
              <h1 className="font-bold text-slate-900 leading-tight">نظام الـ168 ساعة</h1>
              <p className="text-[11px] text-slate-500">إدارة الوقت الحقيقية — تُحفظ بياناتك محليًا على جهازك</p>
            </div>
          </div>
          <button
            onClick={handleClear}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-red-500 transition-colors"
            title="مسح كل البيانات"
          >
            <Trash2 size={14} /> مسح الكل
          </button>
        </div>
      </header>

      {/* التبويبات */}
      <nav className="max-w-6xl mx-auto px-4 mt-5">
        <div className="flex gap-1.5 overflow-x-auto scrollbar-thin rounded-2xl bg-white border border-slate-200 p-1.5 shadow-sm">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex items-center gap-1.5 whitespace-nowrap rounded-xl px-4 py-2 text-sm font-medium transition-colors ${
                  active ? 'bg-slate-900 text-white shadow' : 'text-slate-500 hover:bg-slate-100'
                }`}
              >
                <Icon size={15} />
                {t.label}
              </button>
            );
          })}
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 mt-6">
        {tab === 'guide' && <Guide />}
        {tab === 'budget' && <Budget activities={activities} setActivities={setActivities} />}
        {tab === 'summary' && <Summary activities={activities} />}
        {tab === 'backlog' && <Backlog items={backlog} setItems={setBacklog} />}
        {tab === 'projects' && <Projects items={projects} setItems={setProjects} />}
        {tab === 'energy' && <Energy logs={logs} setLogs={setLogs} />}
      </main>

      <footer className="max-w-6xl mx-auto px-4 mt-10 text-center text-xs text-slate-400 leading-relaxed">
        المعلومات الصحية هنا تنظيمية لا طبية. ألم العين وجفافها والأسنان وحالة البشرة
        تحتاج تقييم طبيب مختص. البيانات لا تغادر جهازك.
      </footer>
    </div>
  );
}
