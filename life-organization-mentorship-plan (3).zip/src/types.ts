export type Pattern = {
  id: string;
  hours: number;
  days: number;
};

export type Activity = {
  id: string;
  name: string;
  category: string;
  patterns: Pattern[];
};

export type BacklogItem = {
  id: string;
  institution: string;
  subject: string;
  totalLectures: number; // 0 = غير معروف
  doneLectures: number;
  avgMinutes: number;
  needsPractice: boolean;
  deadline: string;
  status: 'not-started' | 'in-progress' | 'done';
};

export type ProjectItem = {
  id: string;
  name: string;
  idea: string;
  state: string;
  works: string;
  missing: string;
  fixHours: number;
  potential: number; // 1-5
  nextStep: string;
  status: 'active' | 'queued' | 'archived';
};

export type EnergyLog = {
  date: string; // yyyy-mm-dd
  sleep: number; // 1-5
  sleepHours: number;
  food: number;
  movement: number;
  hygiene: boolean;
  prayers: number; // 0-5
  socialMinutes: number;
  win: string;
};

export type Category = {
  key: string;
  label: string;
  color: string;
  hint: string;
};

export const CATEGORIES: Category[] = [
  { key: 'sleep', label: 'النوم والراحة', color: '#6366f1', hint: 'نوم، قيلولة، استشفاء' },
  { key: 'study-required', label: 'دراسة إلزامية', color: '#0ea5e9', hint: 'كلية، محاضرات، واجبات، زاد، أوزون' },
  { key: 'study-optional', label: 'تعلّم اختياري', color: '#14b8a6', hint: 'إنجليزية، برمجة، تسويق...' },
  { key: 'work', label: 'عمل ودخل', color: '#10b981', hint: 'فريلانس، بيع، خدمات' },
  { key: 'projects', label: 'مشاريع شخصية', color: '#f59e0b', hint: 'مشروع محوري واحد فقط' },
  { key: 'worship', label: 'صلاة وعبادة', color: '#8b5cf6', hint: 'صلوات، أذكار، قرآن' },
  { key: 'food', label: 'طعام وشراب', color: '#f97316', hint: 'وجبات، إعداد، أكل' },
  { key: 'hygiene', label: 'عناية شخصية', color: '#ec4899', hint: 'استحمام، أسنان، ملابس، شعر' },
  { key: 'sport', label: 'حركة ورياضة', color: '#22c55e', hint: 'مشي، تمرين منزلي' },
  { key: 'family', label: 'أسرة وبيت', color: '#a78bfa', hint: 'واجبات منزلية، صلة رحم' },
  { key: 'commute', label: 'مشاوير وتنقل', color: '#64748b', hint: 'خروج، مواصلات' },
  { key: 'entertainment', label: 'ترفيه وسوشيال', color: '#ef4444', hint: 'TikTok، YouTube، منجا...' },
  { key: 'buffer', label: 'احتياطي وطوارئ', color: '#94a3b8', hint: 'مهام غير متوقعة' },
];

export const uid = () => Math.random().toString(36).slice(2, 10);

export const todayStr = () => new Date().toISOString().slice(0, 10);

export const patternHours = (p: Pattern) => (p.hours || 0) * (p.days || 0);

export const activityHours = (a: Activity) => a.patterns.reduce((s, p) => s + patternHours(p), 0);

export const activityDays = (a: Activity) => a.patterns.reduce((s, p) => s + (p.days || 0), 0);
