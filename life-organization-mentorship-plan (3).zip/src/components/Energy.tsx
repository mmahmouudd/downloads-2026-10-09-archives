import { EnergyLog, todayStr } from '../types';
import { Battery, Moon, Utensils, Footprints, Star } from 'lucide-react';

const rateLabels = ['', 'ضعيف', 'أقل من الوسط', 'وسط', 'جيد', 'ممتاز'];

function Rating({ label, value, onChange, icon }: { label: string; value: number; onChange: (v: number) => void; icon: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1.5 text-xs text-slate-500">{icon}{label}</div>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            onClick={() => onChange(n)}
            className={`flex-1 h-8 rounded-lg text-xs font-bold tabular-nums transition-colors ${
              n <= value ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
            }`}
          >
            {n}
          </button>
        ))}
      </div>
      {value > 0 && <div className="text-[11px] text-indigo-600">{rateLabels[value]}</div>}
    </div>
  );
}

export default function Energy({
  logs,
  setLogs,
}: {
  logs: EnergyLog[];
  setLogs: React.Dispatch<React.SetStateAction<EnergyLog[]>>;
}) {
  const today = todayStr();
  const current: EnergyLog = logs.find((l) => l.date === today) || {
    date: today,
    sleep: 0, sleepHours: 0, food: 0, movement: 0,
    hygiene: false, prayers: 0, socialMinutes: 0, win: '',
  };

  const save = (patch: Partial<EnergyLog>) => {
    const next = { ...current, ...patch };
    setLogs((prev) => {
      const rest = prev.filter((l) => l.date !== today);
      return [...rest, next].sort((a, b) => b.date.localeCompare(a.date));
    });
  };

  const history = logs.filter((l) => l.date !== today).slice(0, 7);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5 md:p-6 space-y-6">
        <div className="flex items-center gap-2">
          <Battery size={18} className="text-indigo-600" />
          <div>
            <h3 className="font-bold text-slate-800">مثلث الطاقة — تسجيل اليوم ({today})</h3>
            <p className="text-xs text-slate-500">ملاحظة وتدرّج فقط — هذه ليست أحكامًا أخلاقية ولا تشخيصًا طبيًا.</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-5">
          <Rating label="النوم (الجودة)" value={current.sleep} onChange={(v) => save({ sleep: v })} icon={<Moon size={13} />} />
          <Rating label="الغذاء والترطيب" value={current.food} onChange={(v) => save({ food: v })} icon={<Utensils size={13} />} />
          <Rating label="الحركة والنشاط" value={current.movement} onChange={(v) => save({ movement: v })} icon={<Footprints size={13} />} />
        </div>

        <div className="grid sm:grid-cols-3 gap-4">
          <label className="space-y-1.5">
            <span className="block text-xs text-slate-500">ساعات النوم الفعلية ليلة أمس</span>
            <input type="number" min={0} max={24} value={current.sleepHours || ''}
              onChange={(e) => save({ sleepHours: Number(e.target.value) || 0 })}
              placeholder="مثال: 9"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none" />
          </label>
          <label className="space-y-1.5">
            <span className="block text-xs text-slate-500">صلوات في وقتها (من 5)</span>
            <input type="number" min={0} max={5} value={current.prayers || ''}
              onChange={(e) => save({ prayers: Math.min(5, Math.max(0, Number(e.target.value) || 0)) })}
              placeholder="0 - 5"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none" />
          </label>
          <label className="space-y-1.5">
            <span className="block text-xs text-slate-500">دقائق سوشيال/ترفيه اليوم</span>
            <input type="number" min={0} value={current.socialMinutes || ''}
              onChange={(e) => save({ socialMinutes: Math.max(0, Number(e.target.value) || 0) })}
              placeholder="مثال: 120"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none" />
          </label>
        </div>

        <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
          <input type="checkbox" checked={current.hygiene} onChange={(e) => save({ hygiene: e.target.checked })} className="accent-indigo-600 rounded" />
          أنجزت عنايتي الشخصية الأساسية اليوم (استحمام / أسنان / ملابس نظيفة)
        </label>

        <label className="space-y-1.5 block">
          <span className="flex items-center gap-1.5 text-xs text-slate-500"><Star size={13} /> إنجاز واحد أساسي تحقق اليوم</span>
          <input value={current.win} onChange={(e) => save({ win: e.target.value })}
            placeholder="مثال: شاهدت محاضرة كاملة / رتبت مكتبي / أصلحت خطأ في المشروع"
            className="w-full rounded-lg border border-slate-300 px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none" />
        </label>
      </div>

      {history.length > 0 && (
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5 md:p-6">
          <h3 className="font-bold text-slate-800 mb-4">آخر الأيام</h3>
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-slate-400 border-b">
                  <th className="text-start py-2 font-medium">التاريخ</th>
                  <th className="py-2 font-medium">النوم</th>
                  <th className="py-2 font-medium">ساعات نوم</th>
                  <th className="py-2 font-medium">غذاء وماء</th>
                  <th className="py-2 font-medium">حركة</th>
                  <th className="py-2 font-medium">صلاة</th>
                  <th className="py-2 font-medium">ترفيه</th>
                  <th className="text-start py-2 font-medium">الإنجاز</th>
                </tr>
              </thead>
              <tbody>
                {history.map((l) => (
                  <tr key={l.date} className="border-b last:border-0 text-center tabular-nums">
                    <td className="text-start py-2 text-slate-600">{l.date}</td>
                    <td className="text-slate-700">{l.sleep}/5</td>
                    <td className="text-slate-700">{l.sleepHours}</td>
                    <td className="text-slate-700">{l.food}/5</td>
                    <td className="text-slate-700">{l.movement}/5</td>
                    <td className="text-slate-700">{l.prayers}/5</td>
                    <td className="text-slate-700">{l.socialMinutes} د</td>
                    <td className="text-start text-slate-600 max-w-[200px] truncate">{l.win}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
