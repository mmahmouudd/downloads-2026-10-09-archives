import { Activity, CATEGORIES, activityHours } from '../types';
import { PieChart, AlertCircle, Lightbulb } from 'lucide-react';

export default function Summary({ activities }: { activities: Activity[] }) {
  const weeklyHours = activities.reduce((s, a) => s + activityHours(a), 0);
  const remaining = 168 - weeklyHours;

  const byCat = CATEGORIES.map((c) => ({
    ...c,
    hours: activities.filter((a) => a.category === c.key).reduce((s, a) => s + activityHours(a), 0),
  })).filter((c) => c.hours > 0);

  const sorted = [...byCat].sort((x, y) => y.hours - x.hours);
  const maxH = sorted.length ? sorted[0].hours : 1;

  const drains = sorted.filter((c) => c.key === 'entertainment');
  const entertainmentH = drains.reduce((s, c) => s + c.hours, 0);

  const deepWorkHours = byCat
    .filter((c) => ['study-required', 'work', 'projects'].includes(c.key))
    .reduce((s, c) => s + c.hours, 0);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5">
          <div className="text-xs text-slate-500 mb-1">إجمالي الموزّع</div>
          <div className="text-3xl font-bold tabular-nums text-slate-800">{weeklyHours.toFixed(1)} <span className="text-base text-slate-400">س</span></div>
        </div>
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5">
          <div className="text-xs text-slate-500 mb-1">غير موزّع (فاضي)</div>
          <div className={`text-3xl font-bold tabular-nums ${remaining < 0 ? 'text-red-500' : 'text-emerald-600'}`}>
            {remaining.toFixed(1)} <span className="text-base text-slate-400">س</span>
          </div>
        </div>
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5">
          <div className="text-xs text-slate-500 mb-1">دراسة + عمل + مشروع محوري</div>
          <div className="text-3xl font-bold tabular-nums text-indigo-600">{deepWorkHours.toFixed(1)} <span className="text-base text-slate-400">س</span></div>
        </div>
      </div>

      <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5 md:p-6">
        <div className="flex items-center gap-2 mb-4">
          <PieChart size={18} className="text-indigo-600" />
          <h3 className="font-bold text-slate-800">توزيع الأسبوع حسب الفئات</h3>
        </div>
        {sorted.length === 0 && (
          <p className="text-slate-400 text-sm">أضف أنشطة في تبويب «ميزانية الأسبوع» لترى الملخص هنا.</p>
        )}
        <div className="space-y-3">
          {sorted.map((c) => (
            <div key={c.key}>
              <div className="flex justify-between text-sm mb-1">
                <span className="font-medium text-slate-700">{c.label}</span>
                <span className="tabular-nums text-slate-500">
                  {c.hours.toFixed(1)} س <span className="text-slate-300">({((c.hours / Math.max(1, weeklyHours)) * 100).toFixed(0)}%)</span>
                </span>
              </div>
              <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${(c.hours / maxH) * 100}%`, background: c.color }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 md:p-6 space-y-3">
        <div className="flex items-center gap-2">
          <Lightbulb size={18} className="text-amber-600" />
          <h3 className="font-bold text-amber-800">قراءة سريعة</h3>
        </div>
        <ul className="space-y-2 text-sm text-amber-900 leading-relaxed">
          {remaining > 40 && (
            <li className="flex gap-2"><AlertCircle size={15} className="shrink-0 mt-0.5" /> لديك {remaining.toFixed(0)} ساعة غير موزّعة. ليست كلها ساعات عمل عميق — اترك جزءًا منها للراحة والمفاجآت، ولا تبنِ خطة على وقت وهمي.</li>
          )}
          {entertainmentH > 14 && (
            <li className="flex gap-2"><AlertCircle size={15} className="shrink-0 mt-0.5" /> الترفيه/السوشيال ≈ {entertainmentH.toFixed(0)} ساعة أسبوعيًا. استهداف خفضه للنصف يكسبك {Math.floor(entertainmentH / 2)} ساعة أسبوعية دون تجريد نفسك تمامًا.</li>
          )}
          {deepWorkHours > 0 && deepWorkHours < 10 && (
            <li className="flex gap-2"><AlertCircle size={15} className="shrink-0 mt-0.5" /> ساعات الدراسة والعمل ({deepWorkHours.toFixed(0)} س) أقل من 10 أسبوعيًا — ابدأ بهدف 10–12 ساعة تركيز حقيقي وزِدها أسبوعًا بعد أسبوع، بدلًا من الوثب مباشرة إلى 20.</li>
          )}
          {remaining < 0 && (
            <li className="flex gap-2"><AlertCircle size={15} className="shrink-0 mt-0.5" /> الجدول متجاوز للأسبوع — لا يمكن تنفيذه فيزيائيًا. خفّض الترفيه أو أنماط النوم المفرطة أولًا.</li>
          )}
          {sorted.length > 0 && remaining >= 0 && (
            <li className="flex gap-2"><span className="shrink-0 mt-1 h-1.5 w-1.5 rounded-full bg-amber-500" /><span>تذكّر قاعدة «الحد الأدنى اليومي»: حتى في أسوأ يوم، نفّذ 3 أشياء فقط — صلواتك في وقتها ما استطعت، 30 دقيقة دراسة لتراكم واحد، و10 دقائق عناية شخصية.</span></li>
          )}
        </ul>
      </div>
    </div>
  );
}
