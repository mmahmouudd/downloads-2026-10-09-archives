import { Activity, CATEGORIES, Pattern, activityDays, activityHours, uid } from '../types';
import { Plus, Trash2, AlertTriangle } from 'lucide-react';

type Props = {
  activities: Activity[];
  setActivities: React.Dispatch<React.SetStateAction<Activity[]>>;
};

export default function Budget({ activities, setActivities }: Props) {
  const weeklyHours = activities.reduce((s, a) => s + activityHours(a), 0);
  const remaining = 168 - weeklyHours;

  const addActivity = (catKey: string) => {
    const cat = CATEGORIES.find((c) => c.key === catKey);
    setActivities((prev) => [
      ...prev,
      {
        id: uid(),
        name: cat ? cat.label : 'نشاط جديد',
        category: catKey,
        patterns: [{ id: uid(), hours: 1, days: 1 }],
      },
    ]);
  };

  const updateActivity = (id: string, patch: Partial<Activity>) => {
    setActivities((prev) => prev.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  };

  const removeActivity = (id: string) => {
    setActivities((prev) => prev.filter((a) => a.id !== id));
  };

  const addPattern = (actId: string) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === actId ? { ...a, patterns: [...a.patterns, { id: uid(), hours: 1, days: 1 }] } : a
      )
    );
  };

  const updatePattern = (actId: string, patId: string, patch: Partial<Pattern>) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === actId
          ? { ...a, patterns: a.patterns.map((p) => (p.id === patId ? { ...p, ...patch } : p)) }
          : a
      )
    );
  };

  const removePattern = (actId: string, patId: string) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === actId ? { ...a, patterns: a.patterns.filter((p) => p.id !== patId) } : a
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* الشريط العلوي للمجموع */}
      <div className="sticky top-2 z-10">
        <div className="rounded-2xl bg-slate-900 text-white shadow-lg px-5 py-4 flex flex-wrap items-center gap-x-8 gap-y-3">
          <div>
            <div className="text-xs text-slate-300">موزّع من الأسبوع</div>
            <div className="text-2xl font-bold tabular-nums">
              {weeklyHours.toFixed(1)} <span className="text-sm text-slate-400">/ 168 ساعة</span>
            </div>
          </div>
          <div className="flex-1 min-w-[140px] h-3 rounded-full bg-slate-700 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${weeklyHours > 168 ? 'bg-red-500' : 'bg-emerald-400'}`}
              style={{ width: `${Math.min(100, (weeklyHours / 168) * 100)}%` }}
            />
          </div>
          <div>
            <div className="text-xs text-slate-300">المتبقي</div>
            <div
              className={`text-2xl font-bold tabular-nums ${remaining < 0 ? 'text-red-400' : 'text-emerald-300'}`}
            >
              {remaining.toFixed(1)} س
            </div>
          </div>
        </div>
        {weeklyHours > 168 && (
          <div className="mt-2 flex items-center gap-2 rounded-xl bg-red-50 border border-red-200 text-red-700 px-4 py-2 text-sm">
            <AlertTriangle size={16} />
            تجاوزت 168 ساعة بمقدار {Math.abs(remaining).toFixed(1)} ساعة — قلّل بعض الأنشطة.
          </div>
        )}
      </div>

      <p className="text-sm text-slate-500 leading-relaxed">
        أضف أنشطة أسبوعك ووزّعها بصيغة «ساعات × أيام». مثال: النوم = 7 ساعات في 5 أيام + 10 ساعات
        في يومين. الموقع يحسب المجموع تلقائيًا ويمنعك من توزيع أكثر من 7 أيام للنشاط الواحد.
      </p>

      {/* زر إضافة سريع */}
      <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-4">
        <div className="text-sm font-semibold text-slate-700 mb-3">إضافة نشاط من فئة:</div>
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              onClick={() => addActivity(c.key)}
              className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm hover:bg-slate-50 transition-colors"
              style={{ borderColor: c.color + '55', color: c.color }}
              title={c.hint}
            >
              <Plus size={14} />
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* بطاقات الأنشطة */}
      <div className="grid gap-4 md:grid-cols-2">
        {activities.map((a) => {
          const cat = CATEGORIES.find((c) => c.key === a.category) || CATEGORIES[0];
          const days = activityDays(a);
          const hours = activityHours(a);
          return (
            <div
              key={a.id}
              className="rounded-2xl bg-white shadow-sm border border-slate-200 overflow-hidden"
            >
              <div
                className="px-4 py-3 flex items-center gap-3 border-b"
                style={{ backgroundColor: cat.color + '12', borderColor: cat.color + '30' }}
              >
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: cat.color }} />
                <input
                  value={a.name}
                  onChange={(e) => updateActivity(a.id, { name: e.target.value })}
                  className="flex-1 bg-transparent font-semibold text-slate-800 outline-none min-w-0"
                />
                <span className="text-xs font-bold tabular-nums" style={{ color: cat.color }}>
                  {hours.toFixed(1)} س/أسبوع
                </span>
                <button
                  onClick={() => removeActivity(a.id)}
                  className="text-slate-400 hover:text-red-500 transition-colors"
                  title="حذف النشاط"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="p-4 space-y-2">
                {a.patterns.map((p) => (
                  <div key={p.id} className="flex items-center gap-2 flex-wrap">
                    <input
                      type="number"
                      min={0}
                      max={24}
                      value={p.hours}
                      onChange={(e) =>
                        updatePattern(a.id, p.id, { hours: Math.max(0, Math.min(24, Number(e.target.value) || 0)) })
                      }
                      className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-center tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none"
                    />
                    <span className="text-xs text-slate-500">ساعة في اليوم</span>
                    <span className="text-slate-400">×</span>
                    <input
                      type="number"
                      min={0}
                      max={7}
                      value={p.days}
                      onChange={(e) =>
                        updatePattern(a.id, p.id, { days: Math.max(0, Math.min(7, Number(e.target.value) || 0)) })
                      }
                      className="w-16 rounded-lg border border-slate-300 px-2 py-1.5 text-center tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none"
                    />
                    <span className="text-xs text-slate-500">أيام</span>
                    <span className="text-xs text-slate-400 tabular-nums">
                      = {(p.hours * p.days).toFixed(1)} س
                    </span>
                    <button
                      onClick={() => removePattern(a.id, p.id)}
                      className="ms-auto text-slate-300 hover:text-red-500 transition-colors"
                      title="حذف النمط"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}

                <button
                  onClick={() => addPattern(a.id)}
                  disabled={days >= 7}
                  className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:text-indigo-800 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Plus size={14} /> أضف نمطًا آخر (مدة مختلفة في أيام أخرى)
                </button>

                {days > 7 && (
                  <div className="flex items-center gap-1.5 text-xs text-red-600 bg-red-50 rounded-lg px-2.5 py-1.5">
                    <AlertTriangle size={13} />
                    مجموع الأيام ({days}) أكبر من 7 — انقّح الأنماط.
                  </div>
                )}
                {days < 7 && days > 0 && (
                  <div className="text-xs text-slate-400">
                    موزّع على {days} أيام — متبقٍ من الأسبوع {7 - days} أيام خارج هذا النشاط.
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {activities.length === 0 && (
          <div className="md:col-span-2 rounded-2xl border-2 border-dashed border-slate-200 bg-white/60 p-10 text-center text-slate-400">
            لا توجد أنشطة بعد. ابدأ بإضافة «النوم والراحة» و«دراسة إلزامية» من الأزرار بالأعلى.
          </div>
        )}
      </div>
    </div>
  );
}
