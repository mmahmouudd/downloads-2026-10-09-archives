import { BacklogItem, uid } from '../types';
import { GraduationCap, Plus, Trash2, Film, Clock } from 'lucide-react';

const STATUS_LABELS: Record<BacklogItem['status'], string> = {
  'not-started': 'لم تبدأ',
  'in-progress': 'قيد التنفيذ',
  done: 'مكتملة',
};

const STATUS_COLORS: Record<BacklogItem['status'], string> = {
  'not-started': 'bg-slate-100 text-slate-600',
  'in-progress': 'bg-blue-100 text-blue-700',
  done: 'bg-emerald-100 text-emerald-700',
};

export default function Backlog({
  items,
  setItems,
}: {
  items: BacklogItem[];
  setItems: React.Dispatch<React.SetStateAction<BacklogItem[]>>;
}) {
  const addItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: uid(),
        institution: 'الكلية',
        subject: '',
        totalLectures: 0,
        doneLectures: 0,
        avgMinutes: 60,
        needsPractice: false,
        deadline: '',
        status: 'not-started',
      },
    ]);
  };

  const update = (id: string, patch: Partial<BacklogItem>) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));

  const remove = (id: string) => setItems((prev) => prev.filter((i) => i.id !== id));

  const totalRemainingMin = items.reduce((s, i) => {
    const remain = Math.max(0, (i.totalLectures || 0) - (i.doneLectures || 0));
    const mult = i.needsPractice ? 1.5 : 1;
    return s + remain * (i.avgMinutes || 60) * mult;
  }, 0);

  const knownCount = items.filter((i) => i.totalLectures > 0).length;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-l from-indigo-600 to-sky-600 text-white p-5 md:p-6 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <GraduationCap size={26} />
          <div>
            <h3 className="font-bold text-lg">لوحة التراكم الدراسي</h3>
            <p className="text-indigo-100 text-sm">حصِّ كل محاضرة، ولا تختلق عددًا لا تعرفه — اترك الصفر حتى تتحقق.</p>
          </div>
        </div>
        {knownCount > 0 && (
          <div className="text-center bg-white/15 rounded-xl px-5 py-2">
            <div className="text-2xl font-bold tabular-nums">{(totalRemainingMin / 60).toFixed(1)}</div>
            <div className="text-xs text-indigo-100">ساعة تعويض مطلوبة (تقدير)</div>
          </div>
        )}
      </div>

      <button
        onClick={addItem}
        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 text-white px-4 py-2.5 text-sm font-medium hover:bg-slate-700 transition-colors"
      >
        <Plus size={16} /> إضافة مادة / مساق
      </button>

      <div className="grid gap-4 lg:grid-cols-2">
        {items.map((i) => {
          const remain = Math.max(0, i.totalLectures - i.doneLectures);
          const pct = i.totalLectures > 0 ? Math.min(100, (i.doneLectures / i.totalLectures) * 100) : 0;
          return (
            <div key={i.id} className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <select
                      value={i.institution}
                      onChange={(e) => update(i.id, { institution: e.target.value })}
                      className="rounded-lg border border-slate-300 px-2 py-1 text-sm bg-white focus:ring-2 focus:ring-indigo-300 outline-none"
                    >
                      <option>الكلية</option>
                      <option>أكاديمية زاد</option>
                      <option>أوزون برو ماكس</option>
                      <option>ماكنزي</option>
                      <option>2B</option>
                      <option>أخرى</option>
                    </select>
                    <input
                      value={i.subject}
                      onChange={(e) => update(i.id, { subject: e.target.value })}
                      placeholder="اسم المادة أو المساق"
                      className="flex-1 min-w-[140px] rounded-lg border border-slate-300 px-3 py-1 text-sm focus:ring-2 focus:ring-indigo-300 outline-none"
                    />
                  </div>
                  <span className={`inline-block text-xs font-medium rounded-full px-2.5 py-0.5 ${STATUS_COLORS[i.status]}`}>
                    {STATUS_LABELS[i.status]}
                  </span>
                </div>
                <button onClick={() => remove(i.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <label className="space-y-1">
                  <span className="block text-[11px] text-slate-500">محاضرات منجزة</span>
                  <input
                    type="number" min={0} value={i.doneLectures}
                    onChange={(e) => update(i.id, { doneLectures: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-full rounded-lg border border-slate-300 px-2 py-1.5 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none"
                  />
                </label>
                <label className="space-y-1">
                  <span className="block text-[11px] text-slate-500">الإجمالي (0 = مجهول)</span>
                  <input
                    type="number" min={0} value={i.totalLectures}
                    onChange={(e) => update(i.id, { totalLectures: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-full rounded-lg border border-slate-300 px-2 py-1.5 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none"
                  />
                </label>
                <label className="space-y-1">
                  <span className="block text-[11px] text-slate-500">متوسط الدقائق</span>
                  <input
                    type="number" min={1} value={i.avgMinutes}
                    onChange={(e) => update(i.id, { avgMinutes: Math.max(1, Number(e.target.value) || 1) })}
                    className="w-full rounded-lg border border-slate-300 px-2 py-1.5 tabular-nums focus:ring-2 focus:ring-indigo-300 outline-none"
                  />
                </label>
                <label className="space-y-1">
                  <span className="block text-[11px] text-slate-500">الموعد النهائي</span>
                  <input
                    type="date" value={i.deadline}
                    onChange={(e) => update(i.id, { deadline: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs focus:ring-2 focus:ring-indigo-300 outline-none"
                  />
                </label>
              </div>

              {i.totalLectures > 0 && (
                <div>
                  <div className="flex justify-between text-xs text-slate-500 mb-1">
                    <span className="flex items-center gap-1"><Film size={12} /> متبقٍ {remain} محاضرة</span>
                    <span className="flex items-center gap-1 tabular-nums">
                      <Clock size={12} /> ≈ {((remain * i.avgMinutes * (i.needsPractice ? 1.5 : 1)) / 60).toFixed(1)} ساعة تعويض
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full bg-indigo-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-4 text-sm">
                <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
                  <input
                    type="checkbox" checked={i.needsPractice}
                    onChange={(e) => update(i.id, { needsPractice: e.target.checked })}
                    className="rounded accent-indigo-600"
                  />
                  مشاهدة + حل وتطبيق (وقت ×1.5)
                </label>
                <select
                  value={i.status}
                  onChange={(e) => update(i.id, { status: e.target.value as BacklogItem['status'] })}
                  className="ms-auto rounded-lg border border-slate-300 px-2 py-1 text-xs bg-white outline-none"
                >
                  {Object.entries(STATUS_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>
            </div>
          );
        })}

        {items.length === 0 && (
          <div className="lg:col-span-2 rounded-2xl border-2 border-dashed border-slate-200 bg-white/60 p-10 text-center text-slate-400 leading-relaxed">
            أول خطوة (10 دقائق فقط): افتح منصاتك الخمس وسجّل هنا كل مادة تعرفها.<br />
            لا تعرف عدد المحاضرات؟ اترك الإجمالي = 0 حتى تتحقق من المنصة نفسها.
          </div>
        )}
      </div>
    </div>
  );
}
