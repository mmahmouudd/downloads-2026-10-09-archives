import { ProjectItem, uid } from '../types';
import { Rocket, Plus, Trash2, Archive, Pause, Star } from 'lucide-react';

const STATUS_META = {
  active: { label: 'المشروع المحوري', cls: 'bg-emerald-100 text-emerald-700 border-emerald-200', icon: Star },
  queued: { label: 'قائمة الانتظار', cls: 'bg-amber-100 text-amber-700 border-amber-200', icon: Pause },
  archived: { label: 'مؤرشف', cls: 'bg-slate-100 text-slate-500 border-slate-200', icon: Archive },
} as const;

export default function Projects({
  items,
  setItems,
}: {
  items: ProjectItem[];
  setItems: React.Dispatch<React.SetStateAction<ProjectItem[]>>;
}) {
  const addItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: uid(),
        name: '',
        idea: '',
        state: '',
        works: '',
        missing: '',
        fixHours: 2,
        potential: 3,
        nextStep: '',
        status: 'queued',
      },
    ]);
  };

  const update = (id: string, patch: Partial<ProjectItem>) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));

  const remove = (id: string) => setItems((prev) => prev.filter((i) => i.id !== id));

  const setActive = (id: string) =>
    setItems((prev) => prev.map((i) => ({ ...i, status: i.id === id ? 'active' : i.status === 'active' ? 'queued' : i.status })));

  const active = items.find((i) => i.status === 'active');

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-white border border-slate-200 shadow-sm p-5 md:p-6">
        <div className="flex items-center gap-2 mb-2">
          <Rocket size={18} className="text-emerald-600" />
          <h3 className="font-bold text-slate-800">جرد المشاريع — مشروع واحد فقط يعمل الآن</h3>
        </div>
        <p className="text-sm text-slate-500 leading-relaxed">
          عند مئات النسخ والتجارب، المشكلة ليست قلة الأفكار بل غياب الإتمام. سجّل كل فكرة هنا بدل
          فتحها فورًا. <b>مشروع محوري واحد فقط</b> يُسمح له بحالة «يعمل الآن»، والباقي ينتظر دوره —
          وهذه هي القاعدة، ليست حكمًا على قيمة الأفكار.
        </p>
        {active ? (
          <div className="mt-3 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-800">
            <b>المشروع المحوري الحالي:</b> {active.name || 'بلا اسم'}
            {active.nextStep && <> — الخطوة التالية: {active.nextStep}</>}
          </div>
        ) : (
          <div className="mt-3 rounded-xl bg-slate-50 border border-slate-200 px-4 py-3 text-sm text-slate-500">
            لم تختر مشروعًا محوريًا بعد. انتهِ من تقليل التراكم الدراسي أولًا، ثم اختر مشروعًا واحدًا.
          </div>
        )}
      </div>

      <button
        onClick={addItem}
        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 text-white px-4 py-2.5 text-sm font-medium hover:bg-slate-700 transition-colors"
      >
        <Plus size={16} /> تسجيل مشروع / فكرة
      </button>

      <div className="grid gap-4 lg:grid-cols-2">
        {items.map((i) => {
          const meta = STATUS_META[i.status];
          const Icon = meta.icon;
          return (
            <div key={i.id} className={`rounded-2xl bg-white border shadow-sm p-5 space-y-3 ${i.status === 'active' ? 'border-emerald-300 ring-1 ring-emerald-200' : 'border-slate-200'}`}>
              <div className="flex items-center gap-2">
                <Icon size={15} className="shrink-0 text-slate-500" />
                <input
                  value={i.name}
                  onChange={(e) => update(i.id, { name: e.target.value })}
                  placeholder="اسم المشروع"
                  className="flex-1 min-w-0 bg-transparent font-semibold text-slate-800 outline-none"
                />
                <span className={`text-[11px] font-medium rounded-full border px-2.5 py-0.5 ${meta.cls}`}>{meta.label}</span>
                <button onClick={() => remove(i.id)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={15} /></button>
              </div>

              <textarea
                value={i.idea}
                onChange={(e) => update(i.id, { idea: e.target.value })}
                placeholder="الفكرة في سطر أو سطرين"
                rows={2}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-300 outline-none resize-none"
              />

              <div className="grid sm:grid-cols-2 gap-2 text-sm">
                <input value={i.state} onChange={(e) => update(i.id, { state: e.target.value })} placeholder="الحالة الحالية"
                  className="rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-emerald-300 outline-none" />
                <input value={i.works} onChange={(e) => update(i.id, { works: e.target.value })} placeholder="ما الذي يعمل؟"
                  className="rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-emerald-300 outline-none" />
                <input value={i.missing} onChange={(e) => update(i.id, { missing: e.target.value })} placeholder="ما الذي ينقصه؟"
                  className="rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-emerald-300 outline-none" />
                <input value={i.nextStep} onChange={(e) => update(i.id, { nextStep: e.target.value })} placeholder="الخطوة التالية (10–20 دقيقة)"
                  className="rounded-lg border border-slate-200 px-3 py-2 focus:ring-2 focus:ring-emerald-300 outline-none" />
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                <label className="flex items-center gap-2">
                  وقت الإصلاح:
                  <input type="number" min={0} value={i.fixHours}
                    onChange={(e) => update(i.id, { fixHours: Math.max(0, Number(e.target.value) || 0) })}
                    className="w-16 rounded-lg border border-slate-200 px-2 py-1 text-center tabular-nums" />
                  ساعة
                </label>
                <label className="flex items-center gap-2">
                  القيمة المحتملة:
                  <input type="range" min={1} max={5} value={i.potential}
                    onChange={(e) => update(i.id, { potential: Number(e.target.value) })}
                    className="accent-emerald-600" />
                  <span className="tabular-nums font-semibold">{i.potential}/5</span>
                </label>
                <select
                  value={i.status}
                  onChange={(e) => {
                    const v = e.target.value as ProjectItem['status'];
                    if (v === 'active') setActive(i.id);
                    else update(i.id, { status: v });
                  }}
                  className="ms-auto rounded-lg border border-slate-200 px-2 py-1.5 bg-white outline-none"
                >
                  <option value="active">المشروع المحوري</option>
                  <option value="queued">قائمة الانتظار</option>
                  <option value="archived">أرشفة</option>
                </select>
              </div>
            </div>
          );
        })}

        {items.length === 0 && (
          <div className="lg:col-span-2 rounded-2xl border-2 border-dashed border-slate-200 bg-white/60 p-10 text-center text-slate-400">
            كل فكرة تجيئ في بالك وأنت مخلّص حاجة؟ سجّلها هنا وارجع لمهمتك. الفكرة مسجلة وآمنة — مش محتاجة تتنفذ اليوم.
          </div>
        )}
      </div>
    </div>
  );
}
