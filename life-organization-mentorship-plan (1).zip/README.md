# Week168 Planner

Arabic-first weekly planning application built with React, TypeScript, Vite,
and Tailwind CSS. It runs without a server, account, or external AI API.

## Run Locally

Requires Node.js 22.12 or later.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. Run these commands from the application
folder, not from the parent repository when it contains multiple projects.

## Production

```sh
npm run build
npm run preview
```

The current Vite configuration produces a single-file build at
`dist/index.html`. The Arabic web font needs an internet connection; a
system-font fallback is available. Do not commit `node_modules` or `dist`.

## Data And Browser Features

- Application data is saved to this browser's `localStorage` only.
- Backup/import is available in the Plan tab.
- Natural-language entry uses local parsing rules, not an AI service.
- Browser speech recognition requires browser support and permission. The
  browser or its provider may process speech remotely; it is not guaranteed
  offline. Typed input remains available.

## Upload Without Affecting Other Agents

Follow `GITHUB_UPLOAD.md`. The uploader creates one uniquely named folder at
the repository root and keeps every application file inside that folder.
It does not modify other root entries or force-update a branch.

No GitHub credentials belong in this project or in the browser application.