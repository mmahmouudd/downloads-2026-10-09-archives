import assert from 'node:assert/strict';
import test from 'node:test';
import {
  checkForSecrets,
  collectProject,
  makeFolder,
  parseRepository,
  publishIsolatedFolder,
  shouldExclude,
  validateFolder,
} from '../scripts/publish-folder.mjs';

test('folder names are unique and cannot escape the root folder', () => {
  const a = makeFolder(new Date('2026-01-01T00:00:00Z'), 'aaaaaaaa-1111-2222-3333-444444444444');
  const b = makeFolder(new Date('2026-01-01T00:00:00Z'), 'bbbbbbbb-1111-2222-3333-444444444444');
  assert.notEqual(a, b);
  assert.equal(validateFolder(a), a);
  for (const unsafe of ['../other', 'src/new-folder', '.', '..', '/root', '.git']) {
    assert.throws(() => validateFolder(unsafe));
  }
});

test('repository URLs must not contain credentials or use another host', () => {
  assert.equal(parseRepository('example/week168'), 'example/week168');
  assert.equal(parseRepository('https://github.com/example/week168.git'), 'example/week168');
  assert.throws(() => parseRepository('https://token@github.com/example/week168'));
  assert.throws(() => parseRepository('https://example.org/example/week168'));
  assert.throws(() => parseRepository('example/week168/tree/main'));
});

test('sensitive and generated files are excluded', () => {
  for (const name of ['node_modules', '.git', 'dist', '.env.local', '.npmrc', 'private.pem', 'secrets.json']) {
    assert.equal(shouldExclude(name), true);
  }
  assert.equal(shouldExclude('App.tsx'), false);
  assert.equal(shouldExclude('index.html'), false);
});

test('secret checks fail without printing the secret', () => {
  const secret = 'github' + '_pat_' + 'x'.repeat(60);
  assert.throws(() => checkForSecrets(Buffer.from(secret), 'unsafe.txt'), /unsafe\.txt/);
  assert.throws(() => checkForSecrets(Buffer.from('hidden-value'), 'unsafe.txt', 'hidden-value'));
  assert.doesNotThrow(() => checkForSecrets(Buffer.from('ordinary project content'), 'safe.txt'));
});

test('the project manifest includes source and configuration, but not credentials', async () => {
  const files = await collectProject();
  assert.ok(files.some((file) => file.path === 'src/App.tsx'));
  assert.ok(files.some((file) => file.path === 'vite.config.ts'));
  assert.ok(files.some((file) => file.path === 'package.json'));
  assert.ok(files.every((file) => !file.path.startsWith('node_modules/')));
  assert.ok(files.every((file) => !file.path.startsWith('.env')));
});

function mockGitHub({ concurrent = false, occupied = false, protectedBranch = false } = {}) {
  let head = 'head-original';
  const calls = [];
  const commits = new Map();
  const roots = new Map();
  let patchCount = 0;

  async function api(method, route, body) {
    calls.push({ method, route, body });
    if (method === 'GET' && route.startsWith('/git/ref/heads/')) return { object: { sha: head } };
    if (method === 'GET' && route.startsWith('/git/commits/')) {
      const sha = route.split('/').pop();
      return { tree: { sha: sha === 'head-other-agent' ? 'tree-other-agent' : 'tree-original' } };
    }
    if (method === 'GET' && route.startsWith('/git/trees/')) {
      const sha = route.split('/').pop();
      if (roots.has(sha)) return { tree: roots.get(sha), truncated: false };
      return {
        truncated: false,
        tree: [
          { path: 'another-agent-project', type: 'tree', sha: 'existing-project' },
          ...(occupied ? [{ path: 'week168-codex-test', type: 'tree', sha: 'existing-folder' }] : []),
          ...(sha === 'tree-other-agent' ? [{ path: 'another-agent-new-file', type: 'blob', sha: 'new-file' }] : []),
        ],
      };
    }
    if (method === 'POST' && route === '/git/trees') {
      if (!body.base_tree) return { sha: 'new-project-tree' };
      const sha = `new-root-${roots.size}`;
      roots.set(sha, body.tree);
      return { sha };
    }
    if (method === 'POST' && route === '/git/commits') {
      const sha = `new-commit-${commits.size}`;
      commits.set(sha, body);
      return { sha };
    }
    if (method === 'PATCH' && route.startsWith('/git/refs/heads/')) {
      assert.equal(body.force, false);
      patchCount++;
      if (concurrent && patchCount === 1) head = 'head-other-agent';
      if (protectedBranch || commits.get(body.sha).parents[0] !== head) {
        const error = new Error('Reference update rejected');
        error.status = 422;
        throw error;
      }
      head = body.sha;
      return { object: { sha: head } };
    }
    throw new Error(`Unexpected request: ${method} ${route}`);
  }
  return { api, calls };
}

const input = {
  files: [{ path: 'src/App.tsx', bytes: Buffer.from('export default function App() {}') }],
  folder: 'week168-codex-test',
  branch: 'main',
};

test('only one new folder is added to a base tree; no root files are changed', async () => {
  const mock = mockGitHub();
  const result = await publishIsolatedFolder({ ...input, api: mock.api });
  const rootWrites = mock.calls.filter((call) => call.method === 'POST' && call.route === '/git/trees' && call.body.base_tree);
  assert.equal(rootWrites.length, 1);
  assert.deepEqual(rootWrites[0].body.tree, [
    { path: input.folder, mode: '040000', type: 'tree', sha: 'new-project-tree' },
  ]);
  assert.equal(rootWrites[0].body.base_tree, 'tree-original');
  assert.equal(result.files, 1);
});

test('a concurrent agent commit is kept when retrying', async () => {
  const mock = mockGitHub({ concurrent: true });
  let retries = 0;
  await publishIsolatedFolder({ ...input, api: mock.api, onRetry: () => retries++ });
  const rootWrites = mock.calls.filter((call) => call.method === 'POST' && call.route === '/git/trees' && call.body.base_tree);
  const commitWrites = mock.calls.filter((call) => call.method === 'POST' && call.route === '/git/commits');
  assert.equal(retries, 1);
  assert.equal(rootWrites[1].body.base_tree, 'tree-other-agent');
  assert.deepEqual(commitWrites[1].body.parents, ['head-other-agent']);
  assert.ok(mock.calls.filter((call) => call.method === 'PATCH').every((call) => call.body.force === false));
});

test('an existing folder is never overwritten', async () => {
  const mock = mockGitHub({ occupied: true });
  await assert.rejects(publishIsolatedFolder({ ...input, api: mock.api }), /already exists/);
  assert.equal(mock.calls.filter((call) => call.method === 'POST' || call.method === 'PATCH').length, 0);
});

test('a protected branch fails without forcing or repeated retries', async () => {
  const mock = mockGitHub({ protectedBranch: true });
  await assert.rejects(publishIsolatedFolder({ ...input, api: mock.api }), /rejected/);
  assert.equal(mock.calls.filter((call) => call.method === 'PATCH').length, 1);
});