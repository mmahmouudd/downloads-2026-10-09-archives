import { randomUUID } from 'node:crypto';
import { lstat, readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PROJECT_ROOT = fileURLToPath(new URL('../', import.meta.url));
const ROOT_FILES = [
  '.gitignore',
  'README.md',
  'GITHUB_UPLOAD.md',
  'index.html',
  'package.json',
  'package-lock.json',
  'npm-shrinkwrap.json',
  'tsconfig.json',
  'vite.config.ts',
];
const PROJECT_DIRECTORIES = ['src', 'public', 'scripts', 'tests', 'docs'];
const EXCLUDED = new Set(['.git', 'node_modules', 'dist', '.npmrc', '.DS_Store']);
const MAX_BYTES = 20 * 1024 * 1024;
const API_VERSION = '2022-11-28';

export function makeFolder(now = new Date(), uuid = randomUUID()) {
  const timestamp = now.toISOString().replace(/[-:.]/g, '').replace('Z', '');
  return `week168-codex-${timestamp}-${uuid.replaceAll('-', '').slice(0, 12)}`;
}

export function validateFolder(folder) {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(folder)) {
    throw new Error('The destination must be one folder name, not a path.');
  }
  return folder;
}

export function parseRepository(value) {
  let repository = String(value || '').trim();
  if (/^https:\/\//i.test(repository)) {
    const url = new URL(repository);
    if (url.hostname !== 'github.com' || url.username || url.password) {
      throw new Error('Use a github.com repository URL without credentials.');
    }
    repository = url.pathname.replace(/^\/+|\/+$/g, '');
  }
  repository = repository.replace(/\.git$/, '');
  if (!/^[A-Za-z0-9-]+\/[A-Za-z0-9_.-]+$/.test(repository)) {
    throw new Error('Specify the repository as OWNER/REPO or its GitHub URL.');
  }
  return repository;
}

export function shouldExclude(name) {
  return (
    EXCLUDED.has(name) ||
    name.startsWith('.env') ||
    /\.(?:pem|key|p12|pfx|log)$/i.test(name) ||
    /^(?:credentials|secrets)(?:\.|$)/i.test(name)
  );
}

export function checkForSecrets(bytes, name, token = '') {
  const text = bytes.toString('utf8');
  if (
    (token && text.includes(token)) ||
    /\bgithub_pat_[A-Za-z0-9_]{30,}\b/.test(text) ||
    /\bgh[pousr]_[A-Za-z0-9]{30,}\b/.test(text) ||
    /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/.test(text)
  ) {
    throw new Error(`Possible credential in ${name}. Upload stopped before publishing.`);
  }
}

export async function collectProject(root = PROJECT_ROOT, token = '') {
  const files = [];
  let totalBytes = 0;

  async function collect(relativePath, optional = false) {
    const absolutePath = path.join(root, relativePath);
    let stat;
    try {
      stat = await lstat(absolutePath);
    } catch (error) {
      if (optional && error.code === 'ENOENT') return;
      throw error;
    }
    if (stat.isSymbolicLink()) {
      throw new Error(`Refusing symbolic link: ${relativePath}`);
    }
    if (stat.isDirectory()) {
      const entries = await readdir(absolutePath, { withFileTypes: true });
      entries.sort((a, b) => a.name.localeCompare(b.name));
      for (const entry of entries) {
        if (!shouldExclude(entry.name)) {
          await collect(path.join(relativePath, entry.name));
        }
      }
      return;
    }
    if (!stat.isFile()) return;
    if (stat.size > MAX_BYTES || totalBytes + stat.size > MAX_BYTES) {
      throw new Error('Project exceeds the 20 MB safety limit. Review large files first.');
    }
    const bytes = await readFile(absolutePath);
    checkForSecrets(bytes, relativePath, token);
    totalBytes += bytes.length;
    if (totalBytes > MAX_BYTES) throw new Error('Project exceeds the 20 MB safety limit.');
    files.push({ path: relativePath.split(path.sep).join('/'), bytes });
  }

  for (const name of ROOT_FILES) await collect(name, true);
  for (const name of PROJECT_DIRECTORIES) await collect(name, true);
  for (const required of ['package.json', 'src/App.tsx', 'index.html']) {
    if (!files.some((file) => file.path === required)) {
      throw new Error(`Missing required project file: ${required}`);
    }
  }
  return files;
}

function githubClient(token, repository) {
  return async (method, route, body) => {
    const response = await fetch(`https://api.github.com/repos/${repository}${route}`, {
      method,
      headers: {
        Accept: 'application/vnd.github+json',
        Authorization: `Bearer ${token}`,
        'X-GitHub-Api-Version': API_VERSION,
        'Content-Type': 'application/json',
        'User-Agent': 'week168-isolated-folder-uploader',
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'error',
      signal: AbortSignal.timeout(60_000),
    });
    const raw = await response.text();
    let data;
    try {
      data = raw ? JSON.parse(raw) : {};
    } catch {
      data = {};
    }
    if (!response.ok) {
      const detail = typeof data.message === 'string' ? data.message : 'Request failed';
      const error = new Error(`GitHub ${response.status}: ${detail.replaceAll(token, '[REDACTED]')}`);
      error.status = response.status;
      throw error;
    }
    return data;
  };
}

async function readHead(api, refPath) {
  const ref = await api('GET', `/git/ref/heads/${refPath}`);
  const commit = await api('GET', `/git/commits/${ref.object.sha}`);
  const root = await api('GET', `/git/trees/${commit.tree.sha}`);
  if (root.truncated) throw new Error('Cannot safely inspect this repository root: tree is truncated.');
  return { sha: ref.object.sha, treeSha: commit.tree.sha, entries: root.tree };
}

// Build on the latest tree and require a fast-forward update. A concurrent
// commit is re-read and retained instead of being overwritten.
export async function publishIsolatedFolder({ api, files, folder, branch, onRetry = () => {} }) {
  validateFolder(folder);
  const refPath = branch.split('/').map(encodeURIComponent).join('/');
  let head = await readHead(api, refPath);
  if (head.entries.some((entry) => entry.path === folder)) {
    throw new Error(`Folder already exists: ${folder}. Choose a new name; nothing was replaced.`);
  }

  const decoder = new TextDecoder('utf-8', { fatal: true });
  const entries = [];
  for (const file of files) {
    let content;
    try {
      content = decoder.decode(file.bytes);
    } catch {
      content = null;
    }
    if (content !== null && !content.includes('\0')) {
      entries.push({ path: file.path, mode: '100644', type: 'blob', content });
    } else {
      const blob = await api('POST', '/git/blobs', {
        encoding: 'base64',
        content: file.bytes.toString('base64'),
      });
      entries.push({ path: file.path, mode: '100644', type: 'blob', sha: blob.sha });
    }
  }
  const projectTree = await api('POST', '/git/trees', { tree: entries });

  for (let attempt = 0; attempt < 5; attempt++) {
    if (attempt > 0) head = await readHead(api, refPath);
    if (head.entries.some((entry) => entry.path === folder)) {
      throw new Error(`Folder appeared during upload: ${folder}. No existing files were replaced.`);
    }
    const rootTree = await api('POST', '/git/trees', {
      base_tree: head.treeSha,
      tree: [{ path: folder, mode: '040000', type: 'tree', sha: projectTree.sha }],
    });
    const commit = await api('POST', '/git/commits', {
      message: `Add Week168 application inside ${folder}`,
      tree: rootTree.sha,
      parents: [head.sha],
    });

    try {
      await api('PATCH', `/git/refs/heads/${refPath}`, { sha: commit.sha, force: false });
    } catch (error) {
      if (![409, 422].includes(error.status)) throw error;
      const latest = await api('GET', `/git/ref/heads/${refPath}`);
      if (latest.object.sha === head.sha) throw error;
      onRetry(attempt + 1);
      continue;
    }

    const verifiedTree = await api('GET', `/git/trees/${rootTree.sha}`);
    const savedFolder = verifiedTree.tree.find((entry) => entry.path === folder);
    if (savedFolder?.sha !== projectTree.sha) {
      throw new Error('The branch was updated but folder verification failed. Inspect the commit before retrying.');
    }
    return { commitSha: commit.sha, folder, files: files.length };
  }
  throw new Error('Branch kept changing. No force update was made; retry after the other upload finishes.');
}

async function askForToken() {
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
    throw new Error('Set GITHUB_TOKEN securely in the process environment or run in an interactive terminal.');
  }
  process.stdout.write('New GitHub token (hidden; never saved): ');
  const stdin = process.stdin;
  const wasRaw = Boolean(stdin.isRaw);
  stdin.setRawMode(true);
  stdin.resume();
  return new Promise((resolve, reject) => {
    let token = '';
    function finish(error) {
      stdin.off('data', onData);
      stdin.setRawMode(wasRaw);
      stdin.pause();
      process.stdout.write('\n');
      if (error) reject(error);
      else resolve(token.trim());
    }
    function onData(chunk) {
      for (const char of chunk.toString()) {
        if (char === '\u0003') return finish(new Error('Cancelled.'));
        if (char === '\r' || char === '\n') return finish();
        if (char === '\u007f' || char === '\b') token = token.slice(0, -1);
        else if (char >= ' ') token += char;
      }
    }
    stdin.on('data', onData);
  });
}

function parseArgs(args) {
  const options = {};
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--help' || arg === '--dry-run') options[arg.slice(2)] = true;
    else if (['--repo', '--branch', '--folder'].includes(arg) && args[i + 1] && !args[i + 1].startsWith('--')) {
      options[arg.slice(2)] = args[++i];
    } else throw new Error(`Unknown option or missing value: ${arg}`);
  }
  return options;
}

export async function main(args = process.argv.slice(2)) {
  const options = parseArgs(args);
  if (options.help) {
    console.log('Usage: node scripts/publish-folder.mjs --repo OWNER/REPO [--branch main] [--folder UNIQUE_NAME] [--dry-run]');
    console.log('The token is read from GITHUB_TOKEN/GH_TOKEN or a hidden terminal prompt.');
    return;
  }
  const folder = validateFolder(options.folder || makeFolder());
  const files = await collectProject();
  console.log(`Destination folder: ${folder}`);
  console.log(`Project files: ${files.length}. Root files and other projects will not be modified.`);
  if (options['dry-run']) {
    for (const file of files) console.log(`  ${folder}/${file.path}`);
    console.log('Dry run only. No GitHub requests or writes were made.');
    return;
  }

  const repository = parseRepository(options.repo || process.env.GITHUB_REPOSITORY);
  let token = (process.env.GITHUB_TOKEN || process.env.GH_TOKEN || '').trim();
  if (!token) token = await askForToken();
  if (!token) throw new Error('No token supplied.');
  for (const file of files) checkForSecrets(file.bytes, file.path, token);
  const api = githubClient(token, repository);
  const meta = await api('GET', '');
  if (meta.size === 0 && !meta.default_branch) {
    throw new Error('Initialize the repository with a first commit, then retry.');
  }
  const branch = options.branch || meta.default_branch;
  if (!branch) throw new Error('No branch found. Initialize the repository with a first commit.');
  const result = await publishIsolatedFolder({
    api,
    files,
    folder,
    branch,
    onRetry: (attempt) => console.log(`Concurrent commit detected. Keeping it and retrying (${attempt}/5).`),
  });
  console.log(`Verified commit: ${result.commitSha}`);
  console.log(`Project folder: https://github.com/${repository}/tree/${result.commitSha}/${folder}`);
  console.log('All project files are inside that folder. No force push was used.');
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    const token = process.env.GITHUB_TOKEN || process.env.GH_TOKEN;
    const message = token ? String(error.message).replaceAll(token, '[REDACTED]') : error.message;
    console.error(`Upload stopped: ${message}`);
    process.exitCode = 1;
  });
}