import { pgTable, text, serial, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";

export const budgetItems = pgTable("budget_items", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  // Array of patterns: [{ days: number, hoursPerDay: number }]
  patterns: jsonb("patterns").notNull().$type<Array<{ id: string; days: number; hoursPerDay: number }>>(),
  totalHours: integer("total_hours").notNull().default(0),
  color: text("color").notNull().default("emerald"),
  icon: text("icon").notNull().default("clock"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const academicItems = pgTable("academic_items", {
  id: serial("id").primaryKey(),
  institution: text("institution").notNull(), // الكلية, زاد, أوزون برو ماكس, ماكنزي, 2B
  courseName: text("course_name").notNull(),
  totalLectures: integer("total_lectures"),
  pendingLectures: integer("pending_lectures").default(0),
  completedLectures: integer("completed_lectures").default(0),
  durationPerLectureMins: integer("duration_per_lecture_mins").default(60),
  requirementType: text("requirement_type").notNull().default("watch_and_solve"), // watch_only, watch_and_solve, review
  status: text("status").notNull().default("pending"), // not_started, in_progress, completed
  missingInfoStep: text("missing_info_step"),
  notes: text("notes"),
  priority: text("priority").default("high"), // urgent, high, medium, parked
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const projectItems = pgTable("project_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // code, business_book, content, comics, vibe_iterations
  description: text("description"),
  workingState: text("working_state"), // ما يعمل فعلياً
  missingParts: text("missing_parts"), // ما ينقصه
  fixTimeEstHours: integer("fix_time_est_hours"),
  potentialValue: text("potential_value"),
  triageStatus: text("triage_status").notNull().default("parked"), // pivot, parked, archived
  nextTinyStep: text("next_tiny_step"),
  isPrimaryPivot: boolean("is_primary_pivot").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dailyLogs = pgTable("daily_logs", {
  id: serial("id").primaryKey(),
  logDate: text("log_date").notNull(), // YYYY-MM-DD
  sleepHours: integer("sleep_hours").default(7),
  sleepRating: integer("sleep_rating").default(3), // 1-5
  nutritionRating: integer("nutrition_rating").default(3), // 1-5
  waterCups: integer("water_cups").default(4),
  movementRating: integer("movement_rating").default(2), // 1-5
  movementMins: integer("movement_mins").default(15),
  prayersCount: integer("prayers_count").default(3), // 0-5
  hygieneDone: boolean("hygiene_done").default(false),
  screenDistractionHours: integer("screen_distraction_hours").default(3),
  dailyWin: text("daily_win"),
  reflection: text("reflection"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const ideaInbox = pgTable("idea_inbox", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  details: text("details"),
  category: text("category").default("general"),
  status: text("status").notNull().default("parked"), // parked, reviewed, rejected, promoted
  createdAt: timestamp("created_at").defaultNow(),
});
