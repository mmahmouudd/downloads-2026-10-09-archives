"use client";

import React, { useState } from "react";
import {
  BookOpen,
  GraduationCap,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  Eye,
  HelpCircle,
  ArrowRight,
  ExternalLink,
  Filter,
} from "lucide-react";

export interface AcademicItem {
  id: number;
  institution: string;
  courseName: string;
  totalLectures: number | null;
  pendingLectures: number;
  completedLectures: number;
  durationPerLectureMins: number;
  requirementType: string;
  status: string;
  missingInfoStep?: string | null;
  notes?: string | null;
  priority: string;
}

interface Props {
  items: AcademicItem[];
  onUpdate: () => void;
}

export default function AcademicBacklogSection({ items, onUpdate }: Props) {
  const [selectedFilter, setSelectedFilter] = useState<string>("all");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<AcademicItem | null>(null);

  // New item form
  const [newInstitution, setNewInstitution] = useState("الكلية");
  const [newCourseName, setNewCourseName] = useState("");
  const [newTotalLectures, setNewTotalLectures] = useState<number | "">("");
  const [newPendingLectures, setNewPendingLectures] = useState<number>(1);
  const [newDuration, setNewDuration] = useState<number>(60);
  const [newRequirement, setNewRequirement] = useState("watch_and_solve");
  const [newMissingStep, setNewMissingStep] = useState("");
  const [newNotes, setNewNotes] = useState("");
  const [newPriority, setNewPriority] = useState("urgent");

  const filteredItems = items.filter((item) => {
    if (selectedFilter === "all") return true;
    if (selectedFilter === "urgent") return item.priority === "urgent";
    if (selectedFilter === "college") return item.institution === "الكلية";
    if (selectedFilter === "zad") return item.institution.includes("زاد");
    if (selectedFilter === "parked") return item.priority === "parked" || item.status === "not_started";
    return true;
  });

  const totalPendingLectures = items.reduce((acc, it) => acc + (it.pendingLectures || 0), 0);
  const totalCompletedLectures = items.reduce((acc, it) => acc + (it.completedLectures || 0), 0);
  const estimatedHoursLeft = items.reduce((acc, it) => {
    const mins = (it.pendingLectures || 0) * (it.durationPerLectureMins || 60);
    return acc + mins / 60;
  }, 0);

  const handleUpdateStatus = async (item: AcademicItem, newStatus: string) => {
    try {
      await fetch("/api/academic", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: item.id, status: newStatus }),
      });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleIncrementCompleted = async (item: AcademicItem) => {
    const newCompleted = (item.completedLectures || 0) + 1;
    const newPending = Math.max(0, (item.pendingLectures || 0) - 1);
    const newStatus = newPending === 0 ? "completed" : "in_progress";

    try {
      await fetch("/api/academic", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: item.id,
          completedLectures: newCompleted,
          pendingLectures: newPending,
          status: newStatus,
        }),
      });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteItem = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا السجل الدراسي؟")) return;
    try {
      await fetch(`/api/academic?id=${id}`, { method: "DELETE" });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateCourse = async () => {
    if (!newCourseName.trim()) return;
    try {
      await fetch("/api/academic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          institution: newInstitution,
          courseName: newCourseName,
          totalLectures: newTotalLectures ? Number(newTotalLectures) : null,
          pendingLectures: Number(newPendingLectures) || 0,
          completedLectures: 0,
          durationPerLectureMins: Number(newDuration) || 60,
          requirementType: newRequirement,
          missingInfoStep: newMissingStep,
          notes: newNotes,
          priority: newPriority,
          status: "not_started",
        }),
      });
      setShowAddModal(false);
      setNewCourseName("");
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المحاضرات المتراكمة الإجمالية</span>
            <AlertCircle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-2">
            {totalPendingLectures} <span className="text-sm font-normal text-slate-400">محاضرة</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">تراكم أسبوعين بالكلية + 8-9 أسابيع بزاد</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>الوقت التقديري للتعويض</span>
            <Clock className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 mt-2">
            ~{Math.round(estimatedHoursLeft)} <span className="text-sm font-normal text-slate-400">ساعة</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">بمعدل 1.5 - 2 ساعة يومياً = تنتهي في شهر</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المحاضرات المنجزة حتى الآن</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-2">
            {totalCompletedLectures} <span className="text-sm font-normal text-slate-400">محاضرة</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">كل خطوة تتقدم بها تقلل الضغط</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>القاعدة الذهبية للدراسة</span>
            <GraduationCap className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-sm font-bold text-white mt-2 leading-relaxed">
            الكلية أولاً ثم زاد، وتجميد الباقي
          </div>
          <p className="text-[11px] text-slate-500 mt-1">فصل الإلزامي عن الطموح الاختياري</p>
        </div>
      </div>

      {/* Filter and Action bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <button
            onClick={() => setSelectedFilter("all")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              selectedFilter === "all"
                ? "bg-emerald-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            الكل ({items.length})
          </button>
          <button
            onClick={() => setSelectedFilter("college")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              selectedFilter === "college"
                ? "bg-blue-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            الكلية (عاجل)
          </button>
          <button
            onClick={() => setSelectedFilter("zad")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              selectedFilter === "zad"
                ? "bg-sky-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            أكاديمية زاد
          </button>
          <button
            onClick={() => setSelectedFilter("parked")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              selectedFilter === "parked"
                ? "bg-amber-600 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            المجمدة / قيد التحقق (ماكنزي، 2B)
          </button>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition self-start sm:self-auto shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة مادة أو التزام دراسي</span>
        </button>
      </div>

      {/* Courses Cards */}
      <div className="space-y-4">
        {filteredItems.map((item) => {
          const isUrgent = item.priority === "urgent";
          const isParked = item.priority === "parked";
          const progress =
            item.totalLectures && item.totalLectures > 0
              ? Math.min(100, Math.round((item.completedLectures / item.totalLectures) * 100))
              : 0;

          return (
            <div
              key={item.id}
              className={`bg-slate-900 border rounded-2xl p-5 shadow-md transition-all ${
                isUrgent
                  ? "border-blue-700/60 bg-gradient-to-r from-blue-950/20 to-slate-900"
                  : isParked
                  ? "border-slate-800/80 opacity-90"
                  : "border-slate-800"
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                        item.institution === "الكلية"
                          ? "bg-blue-950 text-blue-300 border-blue-800"
                          : item.institution.includes("زاد")
                          ? "bg-sky-950 text-sky-300 border-sky-800"
                          : item.institution.includes("أوزون")
                          ? "bg-emerald-950 text-emerald-300 border-emerald-800"
                          : "bg-slate-800 text-slate-300 border-slate-700"
                      }`}
                    >
                      {item.institution}
                    </span>

                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded-md ${
                        item.priority === "urgent"
                          ? "bg-rose-950 text-rose-300 border border-rose-800/60"
                          : item.priority === "high"
                          ? "bg-amber-950 text-amber-300 border border-amber-800/60"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {item.priority === "urgent"
                        ? "أولوية قصوى عاجلة"
                        : item.priority === "high"
                        ? "أولوية ثانوية"
                        : "مؤجل حالياً لحين التفرغ"}
                    </span>

                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {item.durationPerLectureMins} دقيقة للمحاضرة
                    </span>

                    <span className="text-[11px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {item.requirementType === "watch_and_solve"
                        ? "مشاهدة + حل وتطبيق"
                        : item.requirementType === "watch_only"
                        ? "مشاهدة فقط"
                        : "مراجعة تلخيص"}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white pt-1">{item.courseName}</h3>

                  {item.notes && <p className="text-xs text-slate-300 leading-relaxed">{item.notes}</p>}
                </div>

                {/* Counter & Action */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between gap-3 shrink-0 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  <div className="text-right">
                    <div className="text-xs text-slate-400">المحاضرات المتراكمة:</div>
                    <div className="text-xl font-black text-amber-400">
                      {item.pendingLectures}{" "}
                      <span className="text-xs font-normal text-slate-400">
                        {item.totalLectures ? `من أصل ${item.totalLectures}` : "غير محدد بدقة"}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleIncrementCompleted(item)}
                      disabled={item.pendingLectures <= 0}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition shadow-sm"
                      title="تسجيل إنهاء محاضرة واحدة الآن"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>أنهيت محاضرة (+1)</span>
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-slate-500 hover:text-rose-400 p-1.5 transition"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Progress bar if total is known */}
              {item.totalLectures && item.totalLectures > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>نسبة الإنجاز:</span>
                    <span>
                      {item.completedLectures} من {item.totalLectures} ({progress}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      style={{ width: `${progress}%` }}
                      className="h-full bg-emerald-500 transition-all duration-300"
                    />
                  </div>
                </div>
              )}

              {/* Missing Info Next Action Card */}
              {item.missingInfoStep && (
                <div className="mt-4 bg-slate-950/80 border border-amber-900/30 rounded-xl p-3 flex items-start gap-2.5 text-xs">
                  <HelpCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="font-bold text-amber-300">الخطوة الأولى الميكروية لكشف المجهول:</span>
                    <p className="text-slate-300">{item.missingInfoStep}</p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Course Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-lg">إضافة مادة أو مسار تعليمي</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">الجهة الدراسية</label>
                  <select
                    value={newInstitution}
                    onChange={(e) => setNewInstitution(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                  >
                    <option value="الكلية">الكلية</option>
                    <option value="أكاديمية زاد">أكاديمية زاد</option>
                    <option value="معهد أوزون برو ماكس">معهد أوزون برو ماكس</option>
                    <option value="ماكنزي / McKinsey">ماكنزي / McKinsey</option>
                    <option value="برنامج 2B">برنامج 2B</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">مستوى الأولوية</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                  >
                    <option value="urgent">أولوية عاجلة (الكلية الآن)</option>
                    <option value="high">أولوية متوسطة (زاد)</option>
                    <option value="medium">استماع مساند (أوزون)</option>
                    <option value="parked">مؤجل / قيد التحقق (ماكنزي، 2B)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">اسم المادة / المساق</label>
                <input
                  type="text"
                  value={newCourseName}
                  onChange={(e) => setNewCourseName(e.target.value)}
                  placeholder="مثال: مادة الاقتصاد، مادة الفقه، برمجة..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">المحاضرات المتراكمة</label>
                  <input
                    type="number"
                    min={0}
                    value={newPendingLectures}
                    onChange={(e) => setNewPendingLectures(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">الإجمالي (إن عُرف)</label>
                  <input
                    type="number"
                    min={0}
                    value={newTotalLectures}
                    onChange={(e) =>
                      setNewTotalLectures(e.target.value ? parseInt(e.target.value) : "")
                    }
                    placeholder="فارغ لو مجهول"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">مدة المحاضرة (دقيقة)</label>
                  <input
                    type="number"
                    min={15}
                    value={newDuration}
                    onChange={(e) => setNewDuration(parseInt(e.target.value) || 60)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">الخطوة التالية لكشف المجهول</label>
                <input
                  type="text"
                  value={newMissingStep}
                  onChange={(e) => setNewMissingStep(e.target.value)}
                  placeholder="مثال: فتح حساب المنصة وحصر الأسابيع الـ 8 بدقة"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">ملاحظات توجيهية</label>
                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  rows={2}
                  placeholder="ملاحظات حول المنهج..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                onClick={handleCreateCourse}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
              >
                حفظ المقرر
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
