"use client";

import React, { useState } from "react";
import {
  Calendar,
  Clock,
  Compass,
  CheckCircle2,
  Moon,
  Sparkles,
  BookOpen,
  Coffee,
  Sun,
  Shield,
  Layers,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

interface DayPlan {
  dayName: string;
  dayType: "college_campus" | "college_online" | "study_catchup" | "spiritual_rest" | "focus_sprint";
  theme: string;
  sleepTarget: string; // e.g. "8-9 ساعات"
  collegeTime: string;
  studyFocus: string;
  pivotProjectTime: string;
  anchors: string[];
  firstTinyStep: string;
  notes: string;
}

const WEEK_DAYS: DayPlan[] = [
  {
    dayName: "السبت",
    dayType: "study_catchup",
    theme: "انطلاقة الأسبوع والسيطرة على تراكم الكلية الأول",
    sleepTarget: "8 - 9 ساعات (استيقاظ هادئ دون فتح السوشيال)",
    collegeTime: "2 ساعة مذاكرة مادة كليّة واحدة متراكمة",
    studyFocus: "إنهاء وحل أول محاضرة متراكمة من مواد الكلية التسع",
    pivotProjectTime: "45 دقيقة فرز مجلد Vibe Coding واختيار المشروع",
    anchors: ["ترتيب السرير والغرفة فور الاستيقاظ", "المشي لمسجد الحي (100م) لصلاة الظهر والعصر", "شرب 4 أكواب ماء على مدار اليوم", "استحمام وتغيير الملابس بالكامل"],
    firstTinyStep: "فتح ملخص أول مادة بالكلية وقراءة أول 5 صفحات فقط لمدة 15 دقيقة.",
    notes: "لا تبدأ اليوم بتصفح الهاتف في السرير. انهض واغسل وجهك واشرب كوب ماء.",
  },
  {
    dayName: "الأحد",
    dayType: "college_campus",
    theme: "يوم الحضور بالجامعة والاحتكاك بالواقع",
    sleepTarget: "7 - 8 ساعات (نوم مبكر نسبياً للحاق بالجامعة)",
    collegeTime: "6 - 7 ساعات (حضور المحاضرات والتنقل والتواصل)",
    studyFocus: "حضور المحاضرات وسؤال الزملاء عن ملفات الـ 18 محاضرة المتراكمة",
    pivotProjectTime: "راحة اليوم من البرمجة (عدم الضغط)",
    anchors: ["الخروج من الغرفة وتغيير البيئة", "أداء الصلوات بالجامعة", "تناول وجبة إفطار خفيفة قبل الخروج", "شرب لتر ونصف ماء أثناء اليوم"],
    firstTinyStep: "الجلوس في أول صف بالجامعة وتدوين 3 نقاط رئيسية وراء الدكتور.",
    notes: "يوم الحضور فرصة ذهبية لكسر العزلة وسؤال ممثل الدفعة عن تحديدات المواد.",
  },
  {
    dayName: "الإثنين",
    dayType: "college_online",
    theme: "يوم الأونلاين الجامعي والتركيز المنزلي الهادئ",
    sleepTarget: "8 ساعات",
    collegeTime: "4 ساعات (محاضرات الأونلاين الرسمية وتلخيصها)",
    studyFocus: "حضور جلسات الأونلاين بتركيز مع إغلاق كل التبويبات الأخرى",
    pivotProjectTime: "1 ساعة لمشروع الـ Vibe Coding (تنظيف كود الصفحة الرئيسية)",
    anchors: ["النزول لصلاة الظهر بالمسجد (100م) لكسر شاشة الجهاز", "أكل وجبة غداء محضرة بالمنزل", "شرب الماء المنظم"],
    firstTinyStep: "فتح رابط الأونلاين قبل الموعد بـ 5 دقائق وتجهيز ورقة وقلم.",
    notes: "لا تشغل الأونلاين في الخلفية وأنت تتصفح TikTok أو المانجا. كن حاضراً ذهنياً.",
  },
  {
    dayName: "الثلاثاء",
    dayType: "focus_sprint",
    theme: "جلسة تعويض زاد ومذاكرة مركزة",
    sleepTarget: "8 ساعات",
    collegeTime: "1.5 ساعة (حل وتطبيق على مادة كلية ثانية)",
    studyFocus: "فتح منصة زاد وحصر الأسابيع الـ 8 وسماع محاضرة واحدة فقط",
    pivotProjectTime: "1 ساعة برمجة (إصلاح مشكلة واحدة فقط في المشروع المحوري)",
    anchors: ["صلاة العصر والمغرب بالمسجد جماعة", "تمرين مشي خفيف 20 دقيقة بالشارع", "وجبة عشاء خفيفة"],
    firstTinyStep: "تسجيل الدخول على منصة زاد وتدوين عدد المحاضرات في ورقة لمدة 10 دقائق.",
    notes: "محاضرة واحدة من زاد تكفي اليوم. لا تحاول تعويض 8 أسابيع في ليلة واحدة!",
  },
  {
    dayName: "الأربعاء",
    dayType: "study_catchup",
    theme: "يوم إسناد الكلية ومحاضرة د. حازم شومان",
    sleepTarget: "8 ساعات",
    collegeTime: "2 ساعة لمادة كلية ثالثة",
    studyFocus: "استماع لمحاضرة أوزون برو ماكس (د. حازم شومان) أثناء المشي",
    pivotProjectTime: "45 دقيقة إعداد الواجهة الأمامية النظيفة (بدون نيون)",
    anchors: ["المشي 30 دقيقة أثناء الاستماع للدرس الإيماني", "ترتيب طاولة العمل والغرفة", "جلسة حديث مع الوالدين"],
    firstTinyStep: "تشغيل التسجيل الصوتي في السماعات والبدء بالمشي فوراً.",
    notes: "استغل الاستماع للأمور الإيمانية أثناء الحركة لتضرب عصفورين بحجر واحد.",
  },
  {
    dayName: "الخميس",
    dayType: "focus_sprint",
    theme: "يوم حسم الإنجاز الأسبوعي واختبار المشروع",
    sleepTarget: "8 ساعات",
    collegeTime: "1.5 ساعة مراجعة ما تم إنجازه بالكلية طوال الأسبوع",
    studyFocus: "حل شيت أو أسئلة على ما تم تعويضه في المواد الثلاث السابقة",
    pivotProjectTime: "1.5 ساعة (تجهيز الرابط التجريبي للمشروع ورفعه على Vercel/GitHub)",
    anchors: ["صلاة المغرب والعشاء بالمسجد", "شرب ماء كافي", "حمام دافئ وغسيل الشعر والعناية بالبشرة"],
    firstTinyStep: "فتح مشروع الكود واختبار أمر التشغيل npm run build لمدة 15 دقيقة.",
    notes: "نهاية أسبوع عملي مبهج: لديك 3 محاضرات كلية معوضة + تقدم في المشروع المحوري.",
  },
  {
    dayName: "الجمعة",
    dayType: "spiritual_rest",
    theme: "يوم الجمعة والعبادة والأسرة والراحة الواعية",
    sleepTarget: "8 - 10 ساعات (نوم مريح واستشفاء عصبي)",
    collegeTime: "راحة تامة من مذاكرة الكلية الإلزامية",
    studyFocus: "سورة الكهف، صلاة الجمعة في المسجد، الصلاة على النبي ﷺ",
    pivotProjectTime: "اختياري خفيف: تدوين أي فكرة جديدة في صندوق الأفكار",
    anchors: ["التبكير لصلاة الجمعة بالمسجد بلباس نظيف ورائحة طيبة", "غداء الأسرة والجلوس مع الوالدين ومساعدتهما", "تقييم أسبوع الـ 168 ساعة عبر الأداة والتجهيز للأسبوع التالي"],
    firstTinyStep: "الاستحمام وارتداء أفضل ثوب والنزول للمسجد قبل الأذان بنصف ساعة.",
    notes: "راحة حقيقية خالية من الشعور بالذنب، لأنك التزمت خلال الأسبوع بخطوات واقعية.",
  },
];

export default function WeekScheduleSection() {
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);
  const currentDay = WEEK_DAYS[selectedDayIndex];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-400" />
              <span>الجدول الأسبوعي الواقعي (يومًا بيوم)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              الأيام ليست نسخاً متطابقة! يوم الحضور يختلف عن يوم الأونلاين وعن الجمعة. لا نطلب 20 ساعة عميقة من البداية، بل 1.5 - 2 ساعة موزعة تحميك من الانهيار.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            {WEEK_DAYS.map((d, idx) => (
              <button
                key={d.dayName}
                onClick={() => setSelectedDayIndex(idx)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  selectedDayIndex === idx
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white hover:bg-slate-900"
                }`}
              >
                {d.dayName}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Day Detailed Card */}
        <div className="mt-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
            <div>
              <span className="text-xs text-emerald-400 font-bold block mb-0.5">
                خطة يوم {currentDay.dayName}
              </span>
              <h3 className="text-lg font-black text-white">{currentDay.theme}</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  setSelectedDayIndex((prev) => (prev > 0 ? prev - 1 : WEEK_DAYS.length - 1))
                }
                className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 text-xs flex items-center gap-1"
              >
                <ChevronRight className="w-4 h-4" />
                <span>اليوم السابق</span>
              </button>
              <button
                onClick={() =>
                  setSelectedDayIndex((prev) => (prev < WEEK_DAYS.length - 1 ? prev + 1 : 0))
                }
                className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 text-xs flex items-center gap-1"
              >
                <span>اليوم التالي</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Daily 4 Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Sleep Target */}
            <div className="bg-slate-950/80 border border-indigo-900/40 rounded-xl p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold">
                <Moon className="w-4 h-4" />
                <span>النوم والاستشفاء</span>
              </div>
              <div className="text-sm font-bold text-white">{currentDay.sleepTarget}</div>
              <p className="text-[11px] text-slate-400">
                لا نطلب 4 ساعات ولا حرمان. استيقاظ تدريجي دون صدمة المنبه والسوشيال.
              </p>
            </div>

            {/* Study Target */}
            <div className="bg-slate-950/80 border border-blue-900/40 rounded-xl p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-blue-400 text-xs font-semibold">
                <BookOpen className="w-4 h-4" />
                <span>الكلية والالتزام الأكاديمي</span>
              </div>
              <div className="text-sm font-bold text-white">{currentDay.collegeTime}</div>
              <p className="text-[11px] text-slate-400">{currentDay.studyFocus}</p>
            </div>

            {/* Pivot Project */}
            <div className="bg-slate-950/80 border border-emerald-900/40 rounded-xl p-4 space-y-1.5">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                <Sparkles className="w-4 h-4" />
                <span>المشروع المحوري (Vibe Coding)</span>
              </div>
              <div className="text-sm font-bold text-white">{currentDay.pivotProjectTime}</div>
              <p className="text-[11px] text-slate-400">
                ساعة واحدة فقط مركزة كافية جداً لإنجاز المشروع دون تشتيت الكلية.
              </p>
            </div>
          </div>

          {/* First Tiny Step Callout */}
          <div className="bg-gradient-to-r from-emerald-950/60 to-slate-950 border border-emerald-500/50 rounded-xl p-4 flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">
              ابدأ هنا
            </div>
            <div className="space-y-1 flex-1">
              <span className="text-xs font-bold text-emerald-300">
                الخطوة الأولى الميكروية لهذا اليوم (10 - 15 دقيقة فقط):
              </span>
              <p className="text-sm font-medium text-white leading-relaxed">
                {currentDay.firstTinyStep}
              </p>
            </div>
          </div>

          {/* Anchors of the day */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>مراسي اليوم الثابتة (العناية، الصلاة، الحركة، الصحة):</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentDay.anchors.map((anchor, aIdx) => (
                <div
                  key={aIdx}
                  className="flex items-center gap-2 text-xs text-slate-300 bg-slate-900/80 px-3 py-2 rounded-lg border border-slate-800"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{anchor}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Insight Note */}
          <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800/60 text-xs text-slate-400 flex items-center gap-2">
            <Shield className="w-4 h-4 text-sky-400 shrink-0" />
            <span><strong className="text-slate-300">توجيه عملي:</strong> {currentDay.notes}</span>
          </div>
        </div>
      </div>

      {/* Overview Table of the 7 Days */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-md">
        <h3 className="text-base font-bold text-white">نظرة عامة على الأسبوع بالكامل (168 ساعة)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                <th className="py-2.5 px-3">اليوم</th>
                <th className="py-2.5 px-3">طبيعة اليوم</th>
                <th className="py-2.5 px-3">النوم المقترح</th>
                <th className="py-2.5 px-3">الكلية والدراسة</th>
                <th className="py-2.5 px-3">المشروع المحوري</th>
                <th className="py-2.5 px-3">الخطوة الأولى</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {WEEK_DAYS.map((d, i) => (
                <tr
                  key={d.dayName}
                  className={`hover:bg-slate-800/40 cursor-pointer transition ${
                    selectedDayIndex === i ? "bg-slate-800/60 font-medium" : ""
                  }`}
                  onClick={() => setSelectedDayIndex(i)}
                >
                  <td className="py-3 px-3 font-bold text-white">{d.dayName}</td>
                  <td className="py-3 px-3">
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                      {d.theme}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-indigo-300">{d.sleepTarget}</td>
                  <td className="py-3 px-3 text-sky-300">{d.collegeTime}</td>
                  <td className="py-3 px-3 text-emerald-300">{d.pivotProjectTime}</td>
                  <td className="py-3 px-3 text-slate-400 max-w-xs truncate">{d.firstTinyStep}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
