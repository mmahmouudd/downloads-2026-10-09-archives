"use client";

import React, { useState } from "react";
import {
  Activity,
  Moon,
  Droplets,
  Heart,
  CheckCircle2,
  Calendar,
  Sparkles,
  Trophy,
  Coffee,
  Smile,
  ShieldAlert,
} from "lucide-react";

export interface DailyLogItem {
  id: number;
  logDate: string;
  sleepHours: number;
  sleepRating: number;
  nutritionRating: number;
  waterCups: number;
  movementRating: number;
  movementMins: number;
  prayersCount: number;
  hygieneDone: boolean;
  screenDistractionHours: number;
  dailyWin?: string | null;
  reflection?: string | null;
}

interface Props {
  logs: DailyLogItem[];
  onUpdate: () => void;
}

export default function EnergyCheckinSection({ logs, onUpdate }: Props) {
  const todayStr = new Date().toISOString().split("T")[0];
  const todayLog = logs.find((l) => l.logDate === todayStr) || logs[0];

  const [date, setDate] = useState(todayStr);
  const [sleepHours, setSleepHours] = useState(todayLog?.sleepHours || 8);
  const [sleepRating, setSleepRating] = useState(todayLog?.sleepRating || 3);
  const [nutritionRating, setNutritionRating] = useState(todayLog?.nutritionRating || 3);
  const [waterCups, setWaterCups] = useState(todayLog?.waterCups || 4);
  const [movementRating, setMovementRating] = useState(todayLog?.movementRating || 2);
  const [movementMins, setMovementMins] = useState(todayLog?.movementMins || 15);
  const [prayersCount, setPrayersCount] = useState(todayLog?.prayersCount || 3);
  const [hygieneDone, setHygieneDone] = useState(todayLog?.hygieneDone ?? true);
  const [distractionHours, setDistractionHours] = useState(todayLog?.screenDistractionHours || 3);
  const [dailyWin, setDailyWin] = useState(todayLog?.dailyWin || "");
  const [reflection, setReflection] = useState(todayLog?.reflection || "");
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveCheckin = async () => {
    setIsSaving(true);
    setSavedSuccess(false);
    try {
      await fetch("/api/logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          logDate: date,
          sleepHours,
          sleepRating,
          nutritionRating,
          waterCups,
          movementRating,
          movementMins,
          prayersCount,
          hygieneDone,
          screenDistractionHours: distractionHours,
          dailyWin,
          reflection,
        }),
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
      onUpdate();
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  // Helper rating star/number selector
  const renderScaleButtons = (
    currentVal: number,
    onChange: (val: number) => void,
    color: string
  ) => {
    return (
      <div className="flex items-center gap-1.5">
        {[1, 2, 3, 4, 5].map((val) => (
          <button
            key={val}
            type="button"
            onClick={() => onChange(val)}
            className={`w-9 h-8 rounded-lg text-xs font-bold transition ${
              currentVal === val
                ? `${color} text-white shadow-sm`
                : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
            }`}
          >
            {val}
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Important Compassionate Rule */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-rose-400" />
              <span>مثلث الطاقة والتسجيل اليومي غير المشروط</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              مراقبة يومية لطاقتك من دون أحكام أخلاقية ولا جلد للذات. الأرقام (1-5) مجرد مرآة للملاحظة لتعديل المسار برفق.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">تاريخ التسجيل:</span>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
            />
          </div>
        </div>

        {/* 3 Pillars of Energy Triangle */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Pillar 1: Sleep */}
          <div className="bg-slate-950/70 border border-indigo-900/40 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-400 flex items-center gap-1.5">
                <Moon className="w-4 h-4" />
                <span>1. النوم والاستشفاء (1-5)</span>
              </span>
              <span className="text-xs text-white font-mono bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800/50">
                {sleepHours} ساعات
              </span>
            </div>

            {renderScaleButtons(sleepRating, setSleepRating, "bg-indigo-600")}

            <div className="pt-1">
              <label className="text-[11px] text-slate-400 block mb-1">عدد ساعات النوم الفعلي اليوم:</label>
              <input
                type="number"
                min={2}
                max={16}
                step={0.5}
                value={sleepHours}
                onChange={(e) => setSleepHours(parseFloat(e.target.value) || 7)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono"
              />
            </div>
          </div>

          {/* Pillar 2: Nutrition & Hydration */}
          <div className="bg-slate-950/70 border border-amber-900/40 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Droplets className="w-4 h-4" />
                <span>2. التغذية والترطيب (1-5)</span>
              </span>
              <span className="text-xs text-white font-mono bg-amber-950 px-2 py-0.5 rounded border border-amber-800/50">
                {waterCups} أكواب ماء
              </span>
            </div>

            {renderScaleButtons(nutritionRating, setNutritionRating, "bg-amber-600")}

            <div className="pt-1">
              <label className="text-[11px] text-slate-400 block mb-1">أكواب الماء المستهلكة اليوم:</label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={waterCups}
                  onChange={(e) => setWaterCups(parseInt(e.target.value) || 1)}
                  className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                />
                <span className="text-xs font-bold text-white font-mono w-6 text-center">{waterCups}</span>
              </div>
            </div>
          </div>

          {/* Pillar 3: Movement & Activity */}
          <div className="bg-slate-950/70 border border-rose-900/40 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <Heart className="w-4 h-4" />
                <span>3. الحركة وتفريغ التوتر (1-5)</span>
              </span>
              <span className="text-xs text-white font-mono bg-rose-950 px-2 py-0.5 rounded border border-rose-800/50">
                {movementMins} دقيقة
              </span>
            </div>

            {renderScaleButtons(movementRating, setMovementRating, "bg-rose-600")}

            <div className="pt-1">
              <label className="text-[11px] text-slate-400 block mb-1">دقائق الحركة/المشي للمسجد أو الشارع:</label>
              <input
                type="number"
                min={0}
                max={120}
                step={5}
                value={movementMins}
                onChange={(e) => setMovementMins(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono"
              />
            </div>
          </div>
        </div>

        {/* Habits Anchors: Prayers & Personal Hygiene */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Prayers */}
          <div className="bg-slate-950/70 border border-emerald-900/40 rounded-xl p-4 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-400">الصلوات المكتملة في أوقاتها:</span>
              <span className="font-mono text-white font-bold">{prayersCount} من 5</span>
            </div>
            <div className="flex gap-1.5">
              {[1, 2, 3, 4, 5].map((pNum) => (
                <button
                  key={pNum}
                  type="button"
                  onClick={() => setPrayersCount(pNum)}
                  className={`flex-1 py-1 rounded text-xs font-bold transition ${
                    prayersCount >= pNum
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-900 text-slate-500 border border-slate-800"
                  }`}
                >
                  {pNum === 1 ? "فجر" : pNum === 2 ? "ظهر" : pNum === 3 ? "عصر" : pNum === 4 ? "مغرب" : "عشاء"}
                </button>
              ))}
            </div>
            <span className="text-[10px] text-slate-500 block">المسجد يبعد 100م، فرصة ذهبية للحركة والتنفس.</span>
          </div>

          {/* Personal Hygiene */}
          <div className="bg-slate-950/70 border border-teal-900/40 rounded-xl p-4 space-y-2">
            <span className="text-xs font-bold text-teal-400 block">العناية الشخصية اليوم:</span>
            <label className="flex items-center gap-2 cursor-pointer bg-slate-900/80 p-2 rounded-lg border border-slate-800">
              <input
                type="checkbox"
                checked={hygieneDone}
                onChange={(e) => setHygieneDone(e.target.checked)}
                className="w-4 h-4 rounded text-teal-500 accent-teal-500"
              />
              <span className="text-xs text-slate-200">
                استحمام أو غسيل وجه/شعر وتغيير ملابس نظيفة
              </span>
            </label>
            <span className="text-[10px] text-slate-500 block">تغيير الملابس يرتبط مباشرة بنقاء الذهن والانتعاش.</span>
          </div>

          {/* Screen Distraction */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-300">ساعات السوشيال/التشتت اليوم:</span>
              <span className="font-mono text-amber-400 font-bold">{distractionHours} ساعات</span>
            </div>
            <input
              type="number"
              min={0}
              max={16}
              value={distractionHours}
              onChange={(e) => setDistractionHours(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono"
            />
            <span className="text-[10px] text-slate-500 block">اعتراف واقعي بدون ذنب. الهدف تقليصها نصف ساعة يومياً.</span>
          </div>
        </div>

        {/* ONE DAILY WIN (Crucial Behavioral Psychology) */}
        <div className="bg-gradient-to-r from-amber-950/40 to-slate-950 border border-amber-600/40 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>إنجاز واحد أساسي لليوم (One Daily Win):</span>
          </div>
          <input
            type="text"
            value={dailyWin}
            onChange={(e) => setDailyWin(e.target.value)}
            placeholder="مثال: رتبت سريري، سمعت نصف محاضرة بالكلية، شربت 4 أكواب ماء، صليت في المسجد..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
          />
          <p className="text-[11px] text-slate-400">
            العقل يحتاج لتثبيت النجاحات الصغيرة حتى يستعيد الثقة التنفيذية، كما فعلت في ترتيب السرير.
          </p>
        </div>

        {/* Daily Reflection */}
        <div>
          <label className="text-xs text-slate-400 block mb-1">ملاحظة أو تفريغ مشاعر لليوم:</label>
          <input
            type="text"
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="كيف تشعر اليوم؟ هل واجهت صعوبة؟"
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs text-white"
          />
        </div>

        {/* Save Button */}
        <div className="flex items-center justify-between pt-2">
          {savedSuccess ? (
            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              تم حفظ بيانات اليوم بنجاح!
            </span>
          ) : (
            <span className="text-xs text-slate-500">
              تسجيل منتظم يبني لك سجلاً يساعدك على رؤية تطورك.
            </span>
          )}

          <button
            onClick={handleSaveCheckin}
            disabled={isSaving}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-950"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isSaving ? "جاري الحفظ..." : "حفظ تسجيل اليوم"}</span>
          </button>
        </div>
      </div>

      {/* History of Recent Logs */}
      {logs.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-md">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>سجل الأيام السابقة ({logs.length} أيام مسجلة)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {logs.map((log) => (
              <div
                key={log.id}
                className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between font-mono text-slate-400 border-b border-slate-800/60 pb-1.5">
                  <span className="text-white font-bold">{log.logDate}</span>
                  <span className="text-amber-400">فوز اليوم:</span>
                </div>

                <div className="text-emerald-300 font-medium line-clamp-2">
                  {log.dailyWin || "لم يسجل إنجاز"}
                </div>

                <div className="grid grid-cols-3 gap-1 pt-1 text-[11px] text-slate-400">
                  <div className="bg-slate-900 p-1 rounded text-center">
                    نوم: {log.sleepHours}س ({log.sleepRating}/5)
                  </div>
                  <div className="bg-slate-900 p-1 rounded text-center">
                    ماء: {log.waterCups}ك
                  </div>
                  <div className="bg-slate-900 p-1 rounded text-center">
                    صلاة: {log.prayersCount}/5
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
