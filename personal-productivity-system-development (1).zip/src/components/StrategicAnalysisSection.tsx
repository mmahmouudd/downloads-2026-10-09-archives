"use client";

import React, { useState } from "react";
import {
  FileText,
  Target,
  GraduationCap,
  Clock,
  Compass,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  BookOpen,
  ArrowRight,
  Shield,
  Layers,
  Flame,
} from "lucide-react";

export default function StrategicAnalysisSection() {
  const [openSection, setOpenSection] = useState<number | null>(1);

  const toggleSection = (id: number) => {
    setOpenSection((prev) => (prev === id ? null : id));
  };

  return (
    <div className="space-y-6">
      {/* Introduction Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-emerald-400" />
          <h2 className="text-xl font-bold text-white">
            التحليل الاستراتيجي الشامل: تحويل التشتت إلى خطة تنفيذية واقعية
          </h2>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
          هذا التحليل مبني بدقة على معطيات وضعك الفعلي ومنهجية تفعيل القدرات التنفيذية خلال 168 ساعة للمهندس محمد شبكة، مع تفكيك الأرقام المثالية واستبدالها بحقائق يومك.
        </p>
      </div>

      {/* Sections Accordion */}
      <div className="space-y-4">
        {/* Deliverable 1: Diagnosis */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <button
            onClick={() => toggleSection(1)}
            className="w-full p-5 text-right flex items-center justify-between hover:bg-slate-800/40 transition"
          >
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800/40 flex items-center justify-center font-bold text-xs">
                1
              </span>
              <h3 className="font-bold text-white text-base">
                1. التشخيص التنظيمي الواقعي (فصل الحقائق عن الافتراضات)
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {openSection === 1 ? "▲ إغلاق" : "▼ تفاصيل"}
            </span>
          </button>

          {openSection === 1 && (
            <div className="p-5 pt-0 border-t border-slate-800/60 space-y-4 text-xs leading-relaxed text-slate-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-emerald-400 font-bold block text-sm">
                    الحقائق المؤكدة من وصفك:
                  </span>
                  <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                    <li>لديك قدرات سابقة مثبتة (حفظ صفحة قرآن في 5 دقائق، قطع الشاشات أشهراً كاملة).</li>
                    <li>النوم متذبذب بشدة (3 أيام بـ 6س، يومان بـ 10س، يومان بـ 14-15س)، وليس 8 ساعات ثابتة.</li>
                    <li>الدراسة: 9 مواد بالكلية تراكم منها 18 محاضرة، مع يوم حضور ويوم أونلاين.</li>
                    <li>قُبلت في أكاديمية زاد ولديك تراكم 8-9 أسابيع مجهول التفاصيل الدقيقة.</li>
                    <li>أنتجت أكثر من 400 إصدار و100 مشروع عبر Vibe Coding، لكن دون إطلاق مستقر.</li>
                    <li>عزلة تامة في الغرفة مع قلة حركة وضعف عناية شخصية وأكل غير منتظم.</li>
                  </ul>
                </div>

                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-amber-400 font-bold block text-sm">
                    الافتراضات التي تحتاج إلى تثبيت (ممنوع اختلاقها):
                  </span>
                  <ul className="space-y-1.5 list-disc list-inside text-slate-300">
                    <li>عدد محاضرات زاد وأوزون: لا نعرفه بدقة حتى تسجل الدخول وتحصره.</li>
                    <li>طبيعة برنامج ماكنزي و2B: مجهولة اللغة والالتزام، وتجميدها هو القرار السليم.</li>
                    <li>ساعات العمل العميق الـ 20: كانت رقماً مقترحاً غير واقعي لوضعك الحالي؛ البداية بـ 5-8 ساعات فقط.</li>
                    <li>الارتباط الأسري والاجتماعي: لا توجد التزامات 14 ساعة كما اقترح النموذج القديم؛ البدء بجلسات بسيطة.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Deliverable 2: Priorities Hierarchy */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <button
            onClick={() => toggleSection(2)}
            className="w-full p-5 text-right flex items-center justify-between hover:bg-slate-800/40 transition"
          >
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-blue-950 text-blue-400 border border-blue-800/40 flex items-center justify-center font-bold text-xs">
                2
              </span>
              <h3 className="font-bold text-white text-base">
                2. هرم الأولويات الحاسم: ما تبدأ به فوراً وما تجمده
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {openSection === 2 ? "▲ إغلاق" : "▼ تفاصيل"}
            </span>
          </button>

          {openSection === 2 && (
            <div className="p-5 pt-0 border-t border-slate-800/60 space-y-4 text-xs leading-relaxed text-slate-300">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-900/40 space-y-1.5">
                  <span className="font-bold text-rose-400 block">المستوى 1: عاجل وإلزامي</span>
                  <p className="text-slate-300">
                    • الكلية والمحاضرات الـ 18 المتراكمة. <br />
                    • العناية الشخصية اليومية (شاور، تغيير ملابس، ماء، أكل).
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-blue-900/40 space-y-1.5">
                  <span className="font-bold text-blue-400 block">المستوى 2: بناء الاستقرار</span>
                  <p className="text-slate-300">
                    • الصلاة بالمسجد (100م) لكسر العزلة. <br />
                    • تقريب تفاوت النوم لـ 7-8 ساعات. <br />
                    • ترتيب السرير والغرفة.
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-900/40 space-y-1.5">
                  <span className="font-bold text-amber-400 block">المستوى 3: المشروع المحوري</span>
                  <p className="text-slate-300">
                    • اختيار مشروع Vibe واحد ونشره. <br />
                    • أكاديمية زاد (محاضرة واحدة فقط يوم بعد يوم).
                  </p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <span className="font-bold text-slate-400 block">المستوى 4: مجمد مؤقتاً</span>
                  <p className="text-slate-500">
                    • ماكنزي و2B. <br />
                    • كتاب البيزنس والوكالة والكوميكس. <br />
                    • تعلم بايثون المتقدم والإنجليزي والتسويق.
                  </p>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-400">
                <strong className="text-white">لماذا هذا الترتيب؟</strong> لأن محاولة دراسة الكلية + زاد + ماكنزي + بايثون + كتاب البيزنس هي الوصفة المؤكدة للشلل الكامل والهروب إلى السوشيال ميديا. السيطرة على الكلية تعيد احترامك لذاتك أولاً.
              </div>
            </div>
          )}
        </div>

        {/* Deliverable 3: Academic backlog math */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <button
            onClick={() => toggleSection(3)}
            className="w-full p-5 text-right flex items-center justify-between hover:bg-slate-800/40 transition"
          >
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-sky-950 text-sky-400 border border-sky-800/40 flex items-center justify-center font-bold text-xs">
                3
              </span>
              <h3 className="font-bold text-white text-base">
                3. حصر التراكمات الدراسية وحساب الساعات الصافية
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {openSection === 3 ? "▲ إغلاق" : "▼ تفاصيل"}
            </span>
          </button>

          {openSection === 3 && (
            <div className="p-5 pt-0 border-t border-slate-800/60 space-y-3 text-xs leading-relaxed text-slate-300">
              <p>
                الـ 18 محاضرة متراكمة بالكلية تعني قرابة 27 ساعة استماع وتلخيص. إذا خصصنا <span className="text-emerald-400 font-bold">1.5 ساعة يومياً</span>، فستنتهي من التراكم بالكامل خلال <span className="text-emerald-400 font-bold">18 يوماً فقط</span>! هذا هدف مقدور عليه تماماً ولا يرهق عقلك.
              </p>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-slate-400 space-y-1">
                <div>• الكلية: يوم حضور (7س) + يوم أونلاين (4س) + 4.5س تعويض أسبوعي = 15.5 ساعة أسبوعياً.</div>
                <div>• أكاديمية زاد: 3 جلسات أسبوعياً × 1.5 ساعة = 4.5 ساعة.</div>
                <div>• الباقي (ماكنزي، 2B): صفر ساعات هذا الشهر لمنع التشتت.</div>
              </div>
            </div>
          )}
        </div>

        {/* Deliverable 4: Realistic 168h Math */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <button
            onClick={() => toggleSection(4)}
            className="w-full p-5 text-right flex items-center justify-between hover:bg-slate-800/40 transition"
          >
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-amber-950 text-amber-400 border border-amber-800/40 flex items-center justify-center font-bold text-xs">
                4
              </span>
              <h3 className="font-bold text-white text-base">
                4. توزيع الـ 168 ساعة: الواقع الفعلي مقابل الوهم النظري
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {openSection === 4 ? "▲ إغلاق" : "▼ تفاصيل"}
            </span>
          </button>

          {openSection === 4 && (
            <div className="p-5 pt-0 border-t border-slate-800/60 space-y-3 text-xs leading-relaxed text-slate-300">
              <div className="overflow-x-auto">
                <table className="w-full text-right">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-bold">
                      <th className="py-2 px-3">النشاط</th>
                      <th className="py-2 px-3">النمط الحسابي بالأسبوع</th>
                      <th className="py-2 px-3">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">النوم والراحة (الواقع المتفاوت)</td>
                      <td className="py-2 px-3">6س × 3 أيام + 10س × يومين + 14س × يومين</td>
                      <td className="py-2 px-3 font-bold text-indigo-400">66 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">الكلية والدراسة الإلزامية</td>
                      <td className="py-2 px-3">يوم حضور (7س) + يوم أونلاين (4س) + 1.5س × 3 أيام تعويض</td>
                      <td className="py-2 px-3 font-bold text-blue-400">15.5 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">المساقات الإضافية (زاد)</td>
                      <td className="py-2 px-3">1.5س × 3 أيام</td>
                      <td className="py-2 px-3 font-bold text-sky-400">4.5 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">الصلوات والمشي للمسجد (100م)</td>
                      <td className="py-2 px-3">1.5س × 7 أيام</td>
                      <td className="py-2 px-3 font-bold text-emerald-400">10.5 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">الطعام والشراب والعناية الشخصية</td>
                      <td className="py-2 px-3">2.5س × 7 أيام</td>
                      <td className="py-2 px-3 font-bold text-teal-400">17.5 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">المشروع المحوري (Vibe Coding)</td>
                      <td className="py-2 px-3">1س × 5 أيام (هدف مبدئي واقعي)</td>
                      <td className="py-2 px-3 font-bold text-cyan-400">5 ساعات</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">الأسرة والترتيب والحركة</td>
                      <td className="py-2 px-3">1.5س × 7 أيام</td>
                      <td className="py-2 px-3 font-bold text-violet-400">10.5 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">استهلاك الشاشة ومشتتات يراد تقليصها</td>
                      <td className="py-2 px-3">3س × 7 أيام (اعتراف واقعي)</td>
                      <td className="py-2 px-3 font-bold text-slate-400">21 ساعة</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-semibold text-white">احتياطي مرن للطوارئ والتنفس</td>
                      <td className="py-2 px-3">هامش أمان</td>
                      <td className="py-2 px-3 font-bold text-amber-400">17.5 ساعة</td>
                    </tr>
                    <tr className="bg-slate-950 font-bold text-white">
                      <td className="py-2.5 px-3">المجموع الكلي</td>
                      <td className="py-2.5 px-3">توزيع دقيق يطابق ظروفك الحقيقية</td>
                      <td className="py-2.5 px-3 text-emerald-400">168 ساعة بالضبط</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Deliverable 5: The Pivot Project Choice */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <button
            onClick={() => toggleSection(5)}
            className="w-full p-5 text-right flex items-center justify-between hover:bg-slate-800/40 transition"
          >
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-800/40 flex items-center justify-center font-bold text-xs">
                5
              </span>
              <h3 className="font-bold text-white text-base">
                5. لماذا اخترنا بورتفوليو Vibe Coding كمشروع محوري وحيد؟
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {openSection === 5 ? "▲ إغلاق" : "▼ تفاصيل"}
            </span>
          </button>

          {openSection === 5 && (
            <div className="p-5 pt-0 border-t border-slate-800/60 space-y-3 text-xs leading-relaxed text-slate-300">
              <p>
                لديك أفكار لكتاب بيزنس ومصنع محتوى وروايات مصورة ومئات أكواد الـ Vibe Coding. الاختيار ليس عشوائياً:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="font-bold text-cyan-400">1. العمل منجز بنسبة 70%</span>
                  <p className="text-slate-400 text-[11px]">الكود مكتوب والـ Back-End يعمل بالفعل، يحتاج فقط لتنظيف واجهة ونشر، بينما باقي الأفكار تبدأ من الصفر.</p>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="font-bold text-cyan-400">2. إثبات عملي للثقة</span>
                  <p className="text-slate-400 text-[11px]">رؤية رابط حقيقي واحد يعمل على الإنترنت يكسر عقدة «أنا أبدأ ولا أكمل»، ويمنحك دفعة نفسية جبارة.</p>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="font-bold text-cyan-400">3. يخدم دراستك وعملك</span>
                  <p className="text-slate-400 text-[11px]">بورتفوليو نظيف يفتح لك باب العمل الحر الحقيقي والتدريب، بدون مخاطر قانونية لحقوق الملكية الفكرية.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* The TWO Critical Closing Questions (Strict Rule 6 & 10) */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-indigo-950/70 border-2 border-emerald-500/50 rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
          <HelpCircle className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>السؤالان المباشران والحاسمان فقط للبدء الفوري (دون تعطيل):</span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          بناءً على طلبك الصريح بعدم طرح عشرات الأسئلة، إليك السؤالين الوحيدين الحاسمين لضبط إيقاع أسبوعك الأول فوراً:
        </p>

        <div className="space-y-3 pt-1">
          <div className="bg-slate-950/90 p-4 rounded-xl border border-slate-800 space-y-1">
            <span className="text-xs font-bold text-emerald-300 block">
              السؤال الأول (بخصوص الكلية):
            </span>
            <p className="text-sm font-semibold text-white leading-relaxed">
              ما هي «المادة الأولى المحددة» من مواد الكلية التسع التي إذا أنجزت أول محاضرتين منها غداً ستشعر بأكبر قدر من الراحة النفسية وتخفيف التراكم؟
            </p>
            <span className="text-[11px] text-slate-400 block pt-1">
              (لنبدأ بها فوراً في جلسة الـ 15 دقيقة الأولى بدل التفكير في الـ 9 مواد دفعة واحدة).
            </span>
          </div>

          <div className="bg-slate-950/90 p-4 rounded-xl border border-slate-800 space-y-1">
            <span className="text-xs font-bold text-sky-300 block">
              السؤال الثاني (بخصوص المشروع المحوري):
            </span>
            <p className="text-sm font-semibold text-white leading-relaxed">
              من بين مئات إصدارات الـ Vibe Coding التي لديك، ما هو اسم أو فكرة «المشروع الواحد» الأكثر اكتمالاً واستقراراً في الـ Back-End ليكون مرشحنا الأول للنشر؟
            </p>
            <span className="text-[11px] text-slate-400 block pt-1">
              (لنساعدك في تنظيف واجهته ورفعه على رابط عام خلال ساعة عمل أسبوعية واحدة).
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
