"use client";

import React, { useState } from "react";
import {
  Code,
  Sparkles,
  Inbox,
  CheckCircle2,
  Clock,
  Archive,
  ArrowUpRight,
  Plus,
  Trash2,
  FolderGit2,
  AlertTriangle,
  Flame,
  Star,
  Layers,
} from "lucide-react";

export interface ProjectItem {
  id: number;
  title: string;
  category: string;
  description?: string | null;
  workingState?: string | null;
  missingParts?: string | null;
  fixTimeEstHours?: number | null;
  potentialValue?: string | null;
  triageStatus: string; // pivot, parked, archived
  nextTinyStep?: string | null;
  isPrimaryPivot?: boolean | null;
}

export interface IdeaItem {
  id: number;
  title: string;
  details?: string | null;
  category?: string | null;
  status: string;
}

interface Props {
  projects: ProjectItem[];
  ideas: IdeaItem[];
  onUpdate: () => void;
}

export default function ProjectsSection({ projects, ideas, onUpdate }: Props) {
  const [activeTab, setActiveTab] = useState<"triage" | "inbox">("triage");
  const [newIdeaText, setNewIdeaText] = useState("");
  const [showAddProject, setShowAddProject] = useState(false);

  // New project form state
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newWorkingState, setNewWorkingState] = useState("");
  const [newMissingParts, setNewMissingParts] = useState("");
  const [newEstHours, setNewEstHours] = useState(5);
  const [newPotentialValue, setNewPotentialValue] = useState("");
  const [newNextStep, setNewNextStep] = useState("");
  const [newTriage, setNewTriage] = useState("parked");

  const pivotProjects = projects.filter((p) => p.triageStatus === "pivot" || p.isPrimaryPivot);
  const parkedProjects = projects.filter((p) => p.triageStatus === "parked" && !p.isPrimaryPivot);
  const archivedProjects = projects.filter((p) => p.triageStatus === "archived" && !p.isPrimaryPivot);

  const handleSetPrimaryPivot = async (project: ProjectItem) => {
    try {
      await fetch("/api/projects", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: project.id,
          triageStatus: "pivot",
          isPrimaryPivot: true,
        }),
      });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleMoveStatus = async (project: ProjectItem, newStatus: string) => {
    try {
      await fetch("/api/projects", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: project.id,
          triageStatus: newStatus,
          isPrimaryPivot: newStatus === "pivot",
        }),
      });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddIdea = async () => {
    if (!newIdeaText.trim()) return;
    try {
      await fetch("/api/ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newIdeaText.trim(),
          details: "تم التدوين لتفريغ الذهن دون مقاطعة العمل الحالي.",
        }),
      });
      setNewIdeaText("");
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteIdea = async (id: number) => {
    try {
      await fetch(`/api/ideas?id=${id}`, { method: "DELETE" });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateProject = async () => {
    if (!newTitle.trim()) return;
    try {
      await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newTitle,
          description: newDesc,
          workingState: newWorkingState,
          missingParts: newMissingParts,
          fixTimeEstHours: newEstHours,
          potentialValue: newPotentialValue,
          nextTinyStep: newNextStep,
          triageStatus: newTriage,
          isPrimaryPivot: newTriage === "pivot",
        }),
      });
      setShowAddProject(false);
      setNewTitle("");
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Tab Switcher */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab("triage")}
            className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition ${
              activeTab === "triage"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20"
                : "bg-slate-900 text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>لوحة فرز المشاريع والمشروع المحوري</span>
          </button>

          <button
            onClick={() => setActiveTab("inbox")}
            className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition ${
              activeTab === "inbox"
                ? "bg-amber-600 text-white shadow-md shadow-amber-500/20"
                : "bg-slate-900 text-slate-400 hover:text-white"
            }`}
          >
            <Inbox className="w-4 h-4" />
            <span>صندوق الأفكار العاجلة ({ideas.length})</span>
          </button>
        </div>

        {activeTab === "triage" && (
          <button
            onClick={() => setShowAddProject(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة فكرة/مشروع للجرد</span>
          </button>
        )}
      </div>

      {activeTab === "triage" ? (
        <div className="space-y-6">
          {/* Pivotal Project Spotlight Banner */}
          {pivotProjects.length > 0 && (
            <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/40 border-2 border-emerald-500/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 left-0 bg-emerald-500 text-slate-950 text-[11px] font-black px-4 py-1 rounded-br-xl uppercase tracking-wider flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>المشروع المحوري الوحيد للمرحلة الحالية</span>
              </div>

              {pivotProjects.map((pivot) => (
                <div key={pivot.id} className="pt-3 space-y-3">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <h3 className="text-xl font-black text-white flex items-center gap-2">
                      <Flame className="w-5 h-5 text-amber-400 shrink-0" />
                      <span>{pivot.title}</span>
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800/60">
                      <Clock className="w-3.5 h-3.5" />
                      <span>الوقت المقدر للإطلاق: {pivot.fixTimeEstHours || 6} ساعات موزعة على الأسبوع</span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-300 leading-relaxed max-w-3xl">
                    {pivot.description}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl text-xs space-y-1">
                      <span className="text-emerald-400 font-semibold block">ما يعمل بالفعل:</span>
                      <p className="text-slate-300">{pivot.workingState || "الـ Back-End والتجارب البرمجية المتعددة."}</p>
                    </div>

                    <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl text-xs space-y-1">
                      <span className="text-amber-400 font-semibold block">ما ينقصه ليخرج للنور:</span>
                      <p className="text-slate-300">{pivot.missingParts || "تنظيف الواجهة وتثبيت دومين/رابط واحد منظم."}</p>
                    </div>
                  </div>

                  {/* Tiny 15-min First Step */}
                  <div className="mt-3 bg-emerald-950/40 border border-emerald-500/40 p-3.5 rounded-xl flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0 text-white font-bold text-xs">
                      15 د
                    </div>
                    <div>
                      <span className="text-xs font-bold text-emerald-300 block">
                        الخطوة الميكروية الأولى فوراً (15 دقيقة فقط):
                      </span>
                      <p className="text-xs text-white mt-0.5 leading-relaxed font-medium">
                        {pivot.nextTinyStep || "فتح مجلد المشروعات واختيار أفضل مشروع واحد فقط، ووضع الباقي في أرشيف مغلق."}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Parked Projects List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>قائمة الانتظار (مؤجلة لحين استقرار الكلية)</span>
                <span className="text-xs text-slate-400">({parkedProjects.length} مشاريع)</span>
              </h4>
              <span className="text-xs text-slate-400">تجميدها يحميك من التشتت واستنزاف الطاقة</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {parkedProjects.map((p) => (
                <div
                  key={p.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-md hover:border-slate-700 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h5 className="font-bold text-white text-sm">{p.title}</h5>
                    <span className="text-[11px] bg-amber-950 text-amber-300 border border-amber-800/60 px-2 py-0.5 rounded-md shrink-0">
                      قائمة الانتظار
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">{p.description}</p>

                  <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 text-[11px] space-y-1">
                    <div className="text-slate-400">
                      <span className="text-slate-300 font-semibold">سبب التجميد: </span>
                      {p.potentialValue || "تجنب التشتت وتعارضه مع الأولوية الدراسية العاجلة."}
                    </div>
                    {p.nextTinyStep && (
                      <div className="text-slate-500">
                        <span className="text-slate-400">الخطوة المؤجلة: </span>
                        {p.nextTinyStep}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <button
                      onClick={() => handleSetPrimaryPivot(p)}
                      className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 transition"
                    >
                      <Star className="w-3.5 h-3.5" />
                      <span>جعله المشروع المحوري</span>
                    </button>

                    <button
                      onClick={() => handleMoveStatus(p, "archived")}
                      className="text-slate-500 hover:text-slate-300 flex items-center gap-1 transition"
                    >
                      <Archive className="w-3.5 h-3.5" />
                      <span>أرشفة</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Archived Projects */}
          {archivedProjects.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-sm font-bold text-slate-400 flex items-center gap-2">
                <Archive className="w-4 h-4 text-slate-500" />
                <span>المشاريع المؤرشفة للمستقبل البعيد</span>
                <span className="text-xs text-slate-500">({archivedProjects.length})</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {archivedProjects.map((p) => (
                  <div
                    key={p.id}
                    className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-4 text-xs space-y-2 opacity-70 hover:opacity-100 transition"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-300">{p.title}</span>
                      <button
                        onClick={() => handleMoveStatus(p, "parked")}
                        className="text-sky-400 hover:underline text-[11px]"
                      >
                        استعادة للانتظار
                      </button>
                    </div>
                    <p className="text-slate-500 text-[11px]">{p.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Idea Inbox Section */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Inbox className="w-5 h-5 text-amber-400" />
              <span>صندوق الأفكار العاجلة (Idea Inbox)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              عندما تلمع في ذهنك فكرة مشروع جديدة أو فكرة متجر أو رواية، لا تبدأ في تنفيذها فوراً! اكتبها هنا فوراً لتفرغ عقلك منها، وتعود لجلستك الحالية دون تشتيت.
            </p>
          </div>

          {/* Add Idea Input */}
          <div className="flex gap-2">
            <input
              type="text"
              value={newIdeaText}
              onChange={(e) => setNewIdeaText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAddIdea();
              }}
              placeholder="اكتب الفكرة التي خطرت ببالك هنا واضغط حفظ..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleAddIdea}
              disabled={!newIdeaText.trim()}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>إيداع في الصندوق</span>
            </button>
          </div>

          {/* Ideas List */}
          <div className="space-y-3">
            {ideas.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                الصندوق فارغ حالياً. كل فكرة جديدة تطرأ اكتبها هنا بدلاً من بدء مشروع عشوائي.
              </div>
            ) : (
              ideas.map((idea) => (
                <div
                  key={idea.id}
                  className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex items-start justify-between gap-3 group hover:border-slate-700 transition"
                >
                  <div className="space-y-1">
                    <h5 className="font-bold text-sm text-slate-200">{idea.title}</h5>
                    {idea.details && <p className="text-xs text-slate-400">{idea.details}</p>}
                  </div>

                  <button
                    onClick={() => handleDeleteIdea(idea.id)}
                    className="text-slate-600 group-hover:text-rose-400 transition p-1"
                    title="حذف الفكرة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Add Project Modal */}
      {showAddProject && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-lg">إضافة مشروع إلى جدول الجرد</h3>
              <button
                onClick={() => setShowAddProject(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">اسم المشروع</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: تطبيق مهام، بوت تليجرام، متجر..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">وصف موجز</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">الحالة في الفرز</label>
                  <select
                    value={newTriage}
                    onChange={(e) => setNewTriage(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                  >
                    <option value="parked">قائمة الانتظار (تجميد)</option>
                    <option value="pivot">المشروع المحوري (نشط)</option>
                    <option value="archived">أرشيف للمستقبل</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">الساعات المقدرة للإصلاح</label>
                  <input
                    type="number"
                    min={1}
                    value={newEstHours}
                    onChange={(e) => setNewEstHours(parseInt(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">الخطوة الميكروية الأولى (15 دقيقة)</label>
                <input
                  type="text"
                  value={newNextStep}
                  onChange={(e) => setNewNextStep(e.target.value)}
                  placeholder="مثال: فتح الملف واختبار تسجيل الدخول فقط"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddProject(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                onClick={handleCreateProject}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
              >
                إضافة للجرد
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
