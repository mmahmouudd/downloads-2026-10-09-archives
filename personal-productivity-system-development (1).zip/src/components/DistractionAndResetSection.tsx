"use client";

import React, { useState } from "react";
import {
  ShieldAlert,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
  Smartphone,
  Eye,
  HeartPulse,
  Flame,
  ArrowLeft,
  XCircle,
} from "lucide-react";

export default function DistractionAndResetSection() {
  const [activeResetStep, setActiveResetStep] = useState(1);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
        <div className="flex items-center gap-2">
          <RotateCcw className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl font-bold text-white">
            بروتوكول التعافي خلال 24 ساعة ودرع حماية المشتتات
          </h2>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
          التعثر ليس فشلاً؛ التعثر جزء طبيعي من أي مسار إنساني. الخطأ القاتل ليس في ضياع يوم، بل في معاقبة النفس بجدول مستحيل في اليوم التالي! إليك الدليل الميداني للتعافي السريع وقواعد إيقاف التشتت.
        </p>
      </div>

      {/* 24-Hour Recovery Protocol Interactive Wizard */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950/40 border border-indigo-900/40 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs text-indigo-400 font-bold block mb-1">
              بروتوكول الـ 24 ساعة للتعافي بعد يوم ضائع
            </span>
            <h3 className="text-lg font-black text-white">
              ماذا تفعل إذا ضاع منك يوم في النوم المفرط أو السوشيال أو العادة السرية؟
            </h3>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            {[1, 2, 3, 4].map((stepNum) => (
              <button
                key={stepNum}
                onClick={() => setActiveResetStep(stepNum)}
                className={`w-8 h-8 rounded-lg text-xs font-bold transition ${
                  activeResetStep === stepNum
                    ? "bg-indigo-600 text-white"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {stepNum}
              </button>
            ))}
          </div>
        </div>

        {/* Step 1 */}
        {activeResetStep === 1 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-bold text-lg border border-indigo-500/30">
                1
              </div>
              <div>
                <h4 className="text-base font-bold text-white">
                  الخطوة 1: الإيقاف الفوري لجلد الذات (Self-Compassion)
                </h4>
                <span className="text-xs text-slate-400">توقف عن تسمية نفسك «فاشل» أو «كسول»</span>
              </div>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2 text-xs leading-relaxed text-slate-300">
              <p>
                • <strong>القاعدة:</strong> جلد الذات والندم الحارق لا يصنعان إنجازاً، بل يفرزان كورتيزول يجعلك تهرب مجدداً إلى الشاشات والإباحية لتخفيف الألم النفسي.
              </p>
              <p>
                • <strong>ما تفعله الآن:</strong> قل لنفسك: «أنا إنسان يمر بمرحلة إعادة ترتيب. ما حدث اليوم حدث وانتهى. أتنفس بعمق، وأستغفر الله، وأستعد للخطوة التالية».
              </p>
            </div>

            <button
              onClick={() => setActiveResetStep(2)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <span>الانتقال للخطوة 2: تحليل السبب</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Step 2 */}
        {activeResetStep === 2 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-600/30 text-amber-400 flex items-center justify-center font-bold text-lg border border-amber-500/30">
                2
              </div>
              <div>
                <h4 className="text-base font-bold text-white">
                  الخطوة 2: مراجعة السبب بموضوعية علمية (Root Cause)
                </h4>
                <span className="text-xs text-slate-400">ما المحفز الحقيقي الذي فجر التشتت؟</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-amber-400 block">هل كان السبب إحباطاً برمجياً؟</span>
                <p className="text-slate-400">
                  طلبت من الذكاء الاصطناعي كوداً فخرجت الواجهة سيئة أو غير مفهومة، فشعرت بالعجز وهربت للمحتوى الترفيهي؟
                </p>
              </div>

              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-amber-400 block">هل كان السبب سهر وإرهاق بدني؟</span>
                <p className="text-slate-400">
                  سهرت أمام الشاشة حتى الصباح، فاستيقظت بطاقة منعدمة وقضيت باقي اليوم في النوم التراكمي؟
                </p>
              </div>
            </div>

            <button
              onClick={() => setActiveResetStep(3)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <span>الانتقال للخطوة 3: خطة الغد المصغرة</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Step 3 */}
        {activeResetStep === 3 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-600/30 text-rose-400 flex items-center justify-center font-bold text-lg border border-rose-500/30">
                3
              </div>
              <div>
                <h4 className="text-base font-bold text-white">
                  الخطوة 3: تقليص خطة اليوم التالي للحد الأدنى (ممنوع الجدول العقابي!)
                </h4>
                <span className="text-xs text-slate-400">لا تحاول تعويض 12 ساعة في يوم واحد</span>
              </div>
            </div>

            <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2 text-xs leading-relaxed text-slate-300">
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>الخطأ القاتل الشائع: وضع جدول مذاكرة 14 ساعة لتعويض الأمس!</span>
              </div>
              <p>
                • هذا يضمن بنسبة 95% انتكاسة جديدة بسبب الضغط الهائل.
              </p>
              <div className="flex items-center gap-2 text-emerald-400 font-bold pt-1">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>الحل الصحيح: جدول «الحد الأدنى للأمان» (Minimum Viable Day):</span>
              </div>
              <p>
                • نوم طبيعي 8 ساعات + المشي للمسجد + وجبتان + ساعة واحدة فقط كلية. هذا يكفي تماماً لاستعادة السيطرة!
              </p>
            </div>

            <button
              onClick={() => setActiveResetStep(4)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
            >
              <span>الانتقال للخطوة 4: العودة بأصغر حركة</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Step 4 */}
        {activeResetStep === 4 && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600/30 text-emerald-400 flex items-center justify-center font-bold text-lg border border-emerald-500/30">
                4
              </div>
              <div>
                <h4 className="text-base font-bold text-white">
                  الخطوة 4: العودة بالحركة الصغرى فوراً (Micro-Momentum)
                </h4>
                <span className="text-xs text-slate-400">استعد إحساس الإنجاز في 5 دقائق</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                <span className="font-bold text-emerald-400">1. اغسل وجهك بالماء البارد</span>
                <p className="text-slate-400 text-[11px]">واشرب كوب ماء كبير لترطيب الجسم وخفض التوتر.</p>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                <span className="font-bold text-emerald-400">2. رتب السرير وافتح النافذة</span>
                <p className="text-slate-400 text-[11px]">كما نجحت مؤخراً، ترتيب البيئة يرسل إشارة نظام لعقلك.</p>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center space-y-1">
                <span className="font-bold text-emerald-400">3. اخرج للمسجد (100م)</span>
                <p className="text-slate-400 text-[11px]">صلاة وخطوات في الهواء تكسر تماماً عزلة الغرفة.</p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveResetStep(1)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
              >
                إعادة البروتوكول من البداية
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Specific Anti-Distraction Shield Rules */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-xl">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-sky-400" />
          <span>درع المشتتات: قواعد ميدانية صريحة لوقف التسلسل التدميري</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Rule 1 */}
          <div className="bg-slate-950/70 border border-slate-800 p-4 rounded-xl space-y-2">
            <span className="font-bold text-sky-400 block text-sm">
              1. قاعدة «فشل الكود أو التصميم النيون»:
            </span>
            <p className="text-slate-300 leading-relaxed">
              عندما تعطي الذكاء الاصطناعي برومبت فيخرج كود غير مفهوم أو واجهة بألوان نيون رديئة: <br />
              <strong className="text-amber-400">توقف فوراً!</strong> قم من أمام الجهاز لمدة 5 دقائق، اشرب ماء، ولا تفتح YouTube أو أغانٍ أو TikTok. عُد واكتب تعديلاً واحداً فقط بدلاً من الدخول في نقاش فلسفي يستنزف الساعات.
            </p>
          </div>

          {/* Rule 2 */}
          <div className="bg-slate-950/70 border border-slate-800 p-4 rounded-xl space-y-2">
            <span className="font-bold text-sky-400 block text-sm">
              2. قاعدة «الهاتف بعيد عن وسادة النوم»:
            </span>
            <p className="text-slate-300 leading-relaxed">
              ضع شاحن الهاتف على بُعد مترين من السرير قبل النوم. تصفح الهاتف وأنت ممدد يسرق ساعتين من نومك، ويجعلك تبدأ الصباح بتشتت Reels وTikTok.
            </p>
          </div>

          {/* Rule 3 */}
          <div className="bg-slate-950/70 border border-slate-800 p-4 rounded-xl space-y-2">
            <span className="font-bold text-sky-400 block text-sm">
              3. التعامل العملي مع الإباحية والعادة السرية:
            </span>
            <p className="text-slate-300 leading-relaxed">
              لا ترتبط هذه المشكلة بالشهوة وحدها، بل بالملل والعزلة والجلوس وحيداً أمام الشاشة لساعات دون هدف. <br />
              <strong className="text-emerald-400">الحل السلوكي:</strong> عندما تشعر بالدافع، أغلق شاشة الجهاز فوراً، واخرج من الغرفة إلى الصالة أو انزل الشارع أو المسجد. تغيير المكان يقطع الدائرة العصبية.
            </p>
          </div>

          {/* Rule 4 */}
          <div className="bg-slate-950/70 border border-slate-800 p-4 rounded-xl space-y-2">
            <span className="font-bold text-sky-400 block text-sm">
              4. قاعدة «الحد الأدنى المقبول» (Good Enough MVP):
            </span>
            <p className="text-slate-300 leading-relaxed">
              لا تنتظر أن يكون الموقع أو الكود مثالياً بنسبة 100%. إذا كان يعمل بنسبة 80%، انشره أو سجله ناجحاً. الكمالية والبحث عن 500 نسخة هما أكبر مصنع للملل والتسويف.
            </p>
          </div>
        </div>
      </div>

      {/* Respectful Health & Medical Disclaimer */}
      <div className="bg-slate-900 border border-teal-900/40 rounded-2xl p-5 shadow-lg space-y-3">
        <div className="flex items-center gap-2 text-teal-400 font-bold text-sm">
          <Stethoscope className="w-5 h-5 text-teal-400" />
          <span>تنبيه صحي مهني محترم (الرعاية الطبية الواقعية)</span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          ذكرت تفاصيل مهمة في وضعك البدني: <span className="text-white font-semibold">وزنك 52 كجم وطولك 170 سم، وألم وجفاف العين، و4-7 أسنان مفقودة، وحب الشباب بالوجه والجسم</span>. <br />
          كنظام إدارة وتنظيم، نؤكد باحترام شديد أن <strong>الذكاء الاصطناعي لا يقدم ولا ينبغي أن يقدم تشخيصاً طبياً</strong>. هذه الأمور تستحق خطوة واقعية لحجز موعد مع:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-teal-300">1. طبيب رمد وعيون:</span>
            <p className="text-slate-400 text-[11px]">لفحص جفاف العين وإجهاد الشاشات والتأكد من عدم وجود حساسية أو حاجة لقطرات ترطيب.</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-teal-300">2. طبيب أسنان:</span>
            <p className="text-slate-400 text-[11px]">لوضع خطة علاجية لتعويض الأسنان المفقودة، لأن مضغ الطعام يؤثر مباشرة على الشهية والوزن.</p>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="font-bold text-teal-300">3. طبيب جلدية وتغذية:</span>
            <p className="text-slate-400 text-[11px]">لتقييم حب الشباب وعلاج البشرة، مع وضع برنامج لزيادة الوزن التدريجي بأمان.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
