"use client";

import React, { useState } from "react";
import {
  Clock,
  Plus,
  Trash2,
  Mic,
  MicOff,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Moon,
  BookOpen,
  GraduationCap,
  Compass,
  Utensils,
  Activity,
  Code,
  Smartphone,
  Shield,
  Users,
  RotateCcw,
} from "lucide-react";

export interface Pattern {
  id: string;
  days: number;
  hoursPerDay: number;
}

export interface BudgetItem {
  id: number;
  category: string;
  title: string;
  patterns: Pattern[];
  totalHours: number;
  color: string;
  icon: string;
  notes?: string | null;
}

interface Props {
  items: BudgetItem[];
  onUpdate: () => void;
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  moon: <Moon className="w-5 h-5" />,
  "book-open": <BookOpen className="w-5 h-5" />,
  "graduation-cap": <GraduationCap className="w-5 h-5" />,
  compass: <Compass className="w-5 h-5" />,
  utensils: <Utensils className="w-5 h-5" />,
  sparkles: <Sparkles className="w-5 h-5" />,
  activity: <Activity className="w-5 h-5" />,
  users: <Users className="w-5 h-5" />,
  code: <Code className="w-5 h-5" />,
  smartphone: <Smartphone className="w-5 h-5" />,
  shield: <Shield className="w-5 h-5" />,
  clock: <Clock className="w-5 h-5" />,
};

const COLOR_CLASSES: Record<string, { bg: string; text: string; border: string; bar: string }> = {
  indigo: { bg: "bg-indigo-950/40", text: "text-indigo-400", border: "border-indigo-800/40", bar: "bg-indigo-500" },
  blue: { bg: "bg-blue-950/40", text: "text-blue-400", border: "border-blue-800/40", bar: "bg-blue-500" },
  sky: { bg: "bg-sky-950/40", text: "text-sky-400", border: "border-sky-800/40", bar: "bg-sky-500" },
  emerald: { bg: "bg-emerald-950/40", text: "text-emerald-400", border: "border-emerald-800/40", bar: "bg-emerald-500" },
  amber: { bg: "bg-amber-950/40", text: "text-amber-400", border: "border-amber-800/40", bar: "bg-amber-500" },
  teal: { bg: "bg-teal-950/40", text: "text-teal-400", border: "border-teal-800/40", bar: "bg-teal-500" },
  rose: { bg: "bg-rose-950/40", text: "text-rose-400", border: "border-rose-800/40", bar: "bg-rose-500" },
  violet: { bg: "bg-violet-950/40", text: "text-violet-400", border: "border-violet-800/40", bar: "bg-violet-500" },
  cyan: { bg: "bg-cyan-950/40", text: "text-cyan-400", border: "border-cyan-800/40", bar: "bg-cyan-500" },
  slate: { bg: "bg-slate-800/50", text: "text-slate-400", border: "border-slate-700/50", bar: "bg-slate-500" },
  zinc: { bg: "bg-zinc-800/50", text: "text-zinc-400", border: "border-zinc-700/50", bar: "bg-zinc-500" },
};

export default function BudgetSection({ items, onUpdate }: Props) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [naturalText, setNaturalText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [parsedPreview, setParsedPreview] = useState<{
    category: string;
    title: string;
    patterns: Pattern[];
    summary: string;
    warning?: string;
  } | null>(null);
  const [isParsing, setIsParsing] = useState(false);

  // New item modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newCategory, setNewCategory] = useState("الدراسة الإلزامية: الكلية");
  const [newPatterns, setNewPatterns] = useState<Pattern[]>([
    { id: "np1", days: 3, hoursPerDay: 2 },
  ]);

  const totalAllocated = items.reduce((acc, curr) => {
    const itemTotal = (curr.patterns || []).reduce(
      (s, p) => s + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0),
      0
    );
    return acc + itemTotal;
  }, 0);

  const roundedAllocated = Math.round(totalAllocated * 10) / 10;
  const remainingHours = Math.round((168 - roundedAllocated) * 10) / 10;
  const isOver = roundedAllocated > 168;

  // Speech Recognition hook
  const handleVoiceToggle = () => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      alert("خاصية التعرف الصوتي غير مدعومة في هذا المتصفح. يمكنك كتابة النص مباشرة في الحقل أدناه.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRec();
    recognition.lang = "ar-EG";
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setNaturalText((prev) => (prev ? prev + " " + transcript : transcript));
      setIsListening(false);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognition.start();
  };

  const parseNaturalInput = async () => {
    if (!naturalText.trim()) return;
    setIsParsing(true);
    try {
      const res = await fetch("/api/parse-natural", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: naturalText }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setParsedPreview(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsParsing(false);
    }
  };

  const applyParsedItem = async () => {
    if (!parsedPreview) return;
    try {
      await fetch("/api/budget", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: parsedPreview.category,
          title: parsedPreview.title,
          patterns: parsedPreview.patterns,
        }),
      });
      setParsedPreview(null);
      setNaturalText("");
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateItemPatterns = async (item: BudgetItem, patterns: Pattern[]) => {
    try {
      await fetch("/api/budget", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: item.id,
          title: item.title,
          category: item.category,
          color: item.color,
          notes: item.notes,
          patterns,
        }),
      });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteItem = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا النشاط؟")) return;
    try {
      await fetch(`/api/budget?id=${id}`, { method: "DELETE" });
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddPatternToItem = (item: BudgetItem) => {
    const existingDays = (item.patterns || []).reduce((s, p) => s + p.days, 0);
    const remainDays = Math.max(1, 7 - existingDays);
    const updated = [
      ...(item.patterns || []),
      { id: "p_" + Date.now(), days: remainDays, hoursPerDay: 2 },
    ];
    handleUpdateItemPatterns(item, updated);
  };

  const handleRemovePattern = (item: BudgetItem, pIndex: number) => {
    const updated = (item.patterns || []).filter((_, idx) => idx !== pIndex);
    handleUpdateItemPatterns(item, updated);
  };

  const handleCreateNewItem = async () => {
    if (!newTitle.trim()) return;
    try {
      await fetch("/api/budget", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newTitle,
          category: newCategory,
          patterns: newPatterns,
        }),
      });
      setShowAddModal(false);
      setNewTitle("");
      onUpdate();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-8">
      {/* 168 Hour Visual Gauge & Stats */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-xl md:text-2xl font-bold text-white">
                ميزانية الـ 168 ساعة الأسبوعية الواقعية
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              إجمالي ساعات الأسبوع = 168 ساعة ثابتة. لا نثبت الساعات يومياً بل نحسب الأنماط المتفاوتة (أيام × ساعات).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-semibold flex items-center gap-2 transition"
            >
              <Plus className="w-4 h-4" />
              إضافة نشاط جديد
            </button>
          </div>
        </div>

        {/* Big Numbers Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4">
            <span className="text-xs text-slate-400 font-medium">إجمالي ساعات الأسبوع</span>
            <div className="text-2xl md:text-3xl font-extrabold text-white mt-1">168 <span className="text-sm font-normal text-slate-400">ساعة</span></div>
            <span className="text-[11px] text-slate-500">مجموع 7 أيام × 24 ساعة</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4">
            <span className="text-xs text-slate-400 font-medium">الساعات الموزعة بالأنماط</span>
            <div className={`text-2xl md:text-3xl font-extrabold mt-1 ${isOver ? "text-rose-400" : "text-emerald-400"}`}>
              {roundedAllocated} <span className="text-sm font-normal text-slate-400">ساعة</span>
            </div>
            <span className="text-[11px] text-slate-500">{Math.round((roundedAllocated / 168) * 100)}% من طاقة الأسبوع</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4">
            <span className="text-xs text-slate-400 font-medium">
              {isOver ? "عجز الساعات (تجاوز)" : "الوقت المتبقي / الاحتياطي المرن"}
            </span>
            <div className={`text-2xl md:text-3xl font-extrabold mt-1 ${isOver ? "text-rose-400" : "text-sky-400"}`}>
              {Math.abs(remainingHours)} <span className="text-sm font-normal text-slate-400">ساعة</span>
            </div>
            <span className="text-[11px] text-slate-500">
              {isOver ? "تحذير: تجاوزت الـ 168 ساعة" : "هامش أمان لمنع الضغط والتعثر"}
            </span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4">
            <span className="text-xs text-slate-400 font-medium">الهدف الأولي للعمل العميق</span>
            <div className="text-2xl md:text-3xl font-extrabold text-amber-400 mt-1">
              5 - 8 <span className="text-sm font-normal text-slate-400">ساعات</span>
            </div>
            <span className="text-[11px] text-amber-500/80">واقعي تدريجي، بدلاً من 20س مستحيلة</span>
          </div>
        </div>

        {/* Progress Bar of the 168 Hours */}
        <div className="mt-6">
          <div className="flex justify-between text-xs text-slate-400 mb-2">
            <span>التوزيع التراكمي لساعات الأسبوع</span>
            <span>{roundedAllocated} من أصل 168 ساعة</span>
          </div>
          <div className="w-full h-4 bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
            {items.map((item) => {
              const itemHours = (item.patterns || []).reduce(
                (sum, p) => sum + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0),
                0
              );
              const pct = (itemHours / 168) * 100;
              if (pct <= 0) return null;
              const colorConfig = COLOR_CLASSES[item.color] || COLOR_CLASSES.indigo;
              return (
                <div
                  key={item.id}
                  style={{ width: `${pct}%` }}
                  className={`h-full ${colorConfig.bar} transition-all duration-300 relative group`}
                  title={`${item.title}: ${Math.round(itemHours)} ساعة (${Math.round(pct)}%)`}
                />
              );
            })}
          </div>

          {isOver && (
            <div className="flex items-center gap-2 mt-3 p-3 bg-rose-950/50 border border-rose-800/50 rounded-xl text-rose-300 text-xs">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>
                تنبيه: مجموع الساعات الموزعة يتجاوز 168 ساعة بمقدار {Math.abs(remainingHours)} ساعة! قم بتعديل ساعات الأنشطة أو تقليص مشتتات السوشيال ميديا لتحقيق التوازن.
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Voice & Natural Language Smart Parser Box */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950/40 border border-indigo-900/30 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center gap-2 text-indigo-400 text-sm font-bold mb-2">
          <Sparkles className="w-4 h-4" />
          <span>الإدخال المرن بالصوت أو باللغة الطبيعية</span>
        </div>
        <p className="text-xs text-slate-300 mb-3 leading-relaxed">
          تحدث بصوتك أو اكتب بالعامية/الفصحى نمط وقتك. مثال: <span className="text-amber-300 font-medium">«أنام 6 ساعات في ثلاثة أيام، و10 ساعات في يومين، و14 ساعة في يومين»</span> أو <span className="text-sky-300 font-medium">«الكلية 7 ساعات يوم الحضور و4 ساعات أونلاين»</span>. سنحلل النمط ونعرضه عليك لتأكيده قبل الإضافة.
        </p>

        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={naturalText}
              onChange={(e) => setNaturalText(e.target.value)}
              placeholder="اكتب أو تحدث هنا... (مثال: أنام 6 ساعات في 3 أيام و 10 ساعات في يومين)"
              className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <button
            type="button"
            onClick={handleVoiceToggle}
            className={`px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition shrink-0 ${
              isListening
                ? "bg-rose-600 text-white animate-pulse"
                : "bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>{isListening ? "جاري الاستماع..." : "تحدث بالصوت"}</span>
          </button>

          <button
            type="button"
            onClick={parseNaturalInput}
            disabled={isParsing || !naturalText.trim()}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-sm font-semibold transition shrink-0 flex items-center justify-center gap-2"
          >
            {isParsing ? "جاري التحليل..." : "تحليل النمط"}
          </button>
        </div>

        {/* Confirmation Preview Card */}
        {parsedPreview && (
          <div className="mt-4 p-4 bg-slate-950 border border-indigo-500/50 rounded-xl space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-300 font-semibold text-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>النتيجة المستخرجة من كلامك:</span>
              </div>
              <span className="text-xs bg-indigo-900/50 text-indigo-300 px-2.5 py-1 rounded-full border border-indigo-700/40">
                {parsedPreview.category}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              {parsedPreview.summary}
            </p>

            {parsedPreview.warning && (
              <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-950/40 border border-amber-800/40 p-2.5 rounded-lg">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{parsedPreview.warning}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setParsedPreview(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={applyParsedItem}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                تأكيد واعتماد النشاط
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Activities Grid with Multi-pattern Day × Hour controls */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <span>أنشطة الأسبوع وحساب الأنماط المتفاوتة</span>
            <span className="text-xs font-normal text-slate-400">({items.length} أقسام)</span>
          </h3>
          <span className="text-xs text-slate-400">
            اضغط على أي نمط لتعديل الساعات أو الأيام عبر الحقول الرقمية أو المنزلق
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((item) => {
            const patterns = item.patterns || [];
            const itemTotalDays = patterns.reduce((s, p) => s + (Number(p.days) || 0), 0);
            const itemTotalHours = patterns.reduce(
              (s, p) => s + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0),
              0
            );
            const isDaysOver = itemTotalDays > 7;
            const colorConfig = COLOR_CLASSES[item.color] || COLOR_CLASSES.indigo;

            return (
              <div
                key={item.id}
                className={`bg-slate-900 border rounded-2xl p-5 transition-all shadow-md ${
                  isDaysOver ? "border-rose-700/80" : colorConfig.border
                }`}
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorConfig.bg} ${colorConfig.text} shrink-0`}
                    >
                      {CATEGORY_ICONS[item.icon] || <Clock className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-base leading-snug">{item.title}</h4>
                      <span className="text-xs text-slate-400 block">{item.category}</span>
                    </div>
                  </div>

                  <div className="text-left shrink-0">
                    <div className="text-lg font-extrabold text-white">
                      {Math.round(itemTotalHours * 10) / 10}{" "}
                      <span className="text-xs font-normal text-slate-400">ساعة/أسبوع</span>
                    </div>
                    <div
                      className={`text-[11px] font-medium px-2 py-0.5 rounded-md inline-block mt-0.5 ${
                        isDaysOver
                          ? "bg-rose-950 text-rose-300 border border-rose-800"
                          : itemTotalDays === 7
                          ? "bg-emerald-950/60 text-emerald-300 border border-emerald-800/40"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {itemTotalDays} من 7 أيام
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {item.notes && (
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60">
                    {item.notes}
                  </p>
                )}

                {/* Patterns List */}
                <div className="mt-3.5 space-y-2.5">
                  <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                    <span>الأنماط الأسبوعية (أيام × ساعات):</span>
                    {isDaysOver && (
                      <span className="text-rose-400 text-[11px] flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        تجاوز 7 أيام!
                      </span>
                    )}
                  </div>

                  {patterns.map((p, pIdx) => {
                    const patternHours = (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0);

                    return (
                      <div
                        key={p.id || pIdx}
                        className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3 space-y-2"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-medium text-slate-300">
                            النمط {pIdx + 1}: {p.hoursPerDay} ساعة × {p.days} أيام ={" "}
                            <span className="text-emerald-400 font-bold">{patternHours} ساعة</span>
                          </span>

                          {patterns.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemovePattern(item, pIdx)}
                              className="text-slate-500 hover:text-rose-400 transition"
                              title="حذف هذا النمط"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        {/* Sliders and exact number inputs */}
                        <div className="grid grid-cols-2 gap-3 pt-1">
                          {/* Days Control */}
                          <div>
                            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                              <span>عدد الأيام:</span>
                              <span className="font-bold text-white">{p.days} يوم</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="range"
                                min={1}
                                max={7}
                                step={1}
                                value={p.days}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value) || 1;
                                  const updated = patterns.map((itemPat, i) =>
                                    i === pIdx ? { ...itemPat, days: val } : itemPat
                                  );
                                  handleUpdateItemPatterns(item, updated);
                                }}
                                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                              />
                              <input
                                type="number"
                                min={1}
                                max={7}
                                value={p.days}
                                onChange={(e) => {
                                  const val = Math.min(7, Math.max(1, parseInt(e.target.value) || 1));
                                  const updated = patterns.map((itemPat, i) =>
                                    i === pIdx ? { ...itemPat, days: val } : itemPat
                                  );
                                  handleUpdateItemPatterns(item, updated);
                                }}
                                className="w-12 bg-slate-900 border border-slate-700 text-center text-xs py-1 rounded-md text-white font-mono"
                              />
                            </div>
                          </div>

                          {/* Hours Control */}
                          <div>
                            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                              <span>الساعات/يوم:</span>
                              <span className="font-bold text-white">{p.hoursPerDay} ساعة</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="range"
                                min={0.5}
                                max={16}
                                step={0.5}
                                value={p.hoursPerDay}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value) || 1;
                                  const updated = patterns.map((itemPat, i) =>
                                    i === pIdx ? { ...itemPat, hoursPerDay: val } : itemPat
                                  );
                                  handleUpdateItemPatterns(item, updated);
                                }}
                                className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                              />
                              <input
                                type="number"
                                min={0.5}
                                max={24}
                                step={0.5}
                                value={p.hoursPerDay}
                                onChange={(e) => {
                                  const val = Math.max(0.5, parseFloat(e.target.value) || 0.5);
                                  const updated = patterns.map((itemPat, i) =>
                                    i === pIdx ? { ...itemPat, hoursPerDay: val } : itemPat
                                  );
                                  handleUpdateItemPatterns(item, updated);
                                }}
                                className="w-14 bg-slate-900 border border-slate-700 text-center text-xs py-1 rounded-md text-white font-mono"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Card footer actions */}
                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => handleAddPatternToItem(item)}
                    disabled={itemTotalDays >= 7}
                    className="text-xs text-sky-400 hover:text-sky-300 disabled:opacity-40 disabled:hover:text-sky-400 flex items-center gap-1 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة نمط أيام آخر</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteItem(item.id)}
                    className="text-xs text-slate-500 hover:text-rose-400 flex items-center gap-1 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Custom Activity Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-lg">إضافة نشاط أسبوعي جديد</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">اسم النشاط</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: جلسة حل تمارين الكلية، قراءة..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">القسم</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white"
                >
                  <option value="الدراسة الإلزامية: الكلية">الدراسة الإلزامية: الكلية</option>
                  <option value="المساقات الإضافية">المساقات الإضافية (زاد، أوزون، ماكنزي)</option>
                  <option value="المشروع المحوري والتقنية">المشروع المحوري والتقنية</option>
                  <option value="الصلاة والعبادات">الصلاة والعبادات</option>
                  <option value="الرياضة والحركة">الرياضة والحركة</option>
                  <option value="العناية الشخصية والنظافة">العناية الشخصية والنظافة</option>
                  <option value="الطعام والشرب">الطعام والشرب</option>
                  <option value="الأسرة والمسؤوليات">الأسرة والمسؤوليات</option>
                  <option value="الترفيه ومشتتات السوشيال">الترفيه ومشتتات السوشيال</option>
                  <option value="أخرى">أخرى</option>
                </select>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs text-slate-300 font-medium">النمط الأولي:</span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">عدد الأيام:</label>
                    <input
                      type="number"
                      min={1}
                      max={7}
                      value={newPatterns[0].days}
                      onChange={(e) =>
                        setNewPatterns([
                          { ...newPatterns[0], days: Math.min(7, Math.max(1, parseInt(e.target.value) || 1)) },
                        ])
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">الساعات باليوم:</label>
                    <input
                      type="number"
                      min={0.5}
                      max={24}
                      step={0.5}
                      value={newPatterns[0].hoursPerDay}
                      onChange={(e) =>
                        setNewPatterns([
                          { ...newPatterns[0], hoursPerDay: parseFloat(e.target.value) || 1 },
                        ])
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-sm text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                onClick={handleCreateNewItem}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
              >
                حفظ النشاط
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
