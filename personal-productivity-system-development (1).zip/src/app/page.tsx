"use client";

import React, { useState, useEffect } from "react";
import {
  Clock,
  BookOpen,
  Layers,
  Calendar,
  Activity,
  ShieldAlert,
  FileText,
  Compass,
  Sparkles,
  RefreshCw,
  Trophy,
  Moon,
  Droplets,
  Heart,
  ChevronDown,
} from "lucide-react";
import BudgetSection, { BudgetItem } from "@/components/BudgetSection";
import AcademicBacklogSection, { AcademicItem } from "@/components/AcademicBacklogSection";
import ProjectsSection, { ProjectItem, IdeaItem } from "@/components/ProjectsSection";
import WeekScheduleSection from "@/components/WeekScheduleSection";
import EnergyCheckinSection, { DailyLogItem } from "@/components/EnergyCheckinSection";
import DistractionAndResetSection from "@/components/DistractionAndResetSection";
import StrategicAnalysisSection from "@/components/StrategicAnalysisSection";

export default function Home() {
  const [activeTab, setActiveTab] = useState<string>("budget");
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [academicItems, setAcademicItems] = useState<AcademicItem[]>([]);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [ideas, setIdeas] = useState<IdeaItem[]>([]);
  const [logs, setLogs] = useState<DailyLogItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAllData = async () => {
    try {
      const [resB, resA, resP, resI, resL] = await Promise.all([
        fetch("/api/budget").then((r) => r.json()).catch(() => ({ items: [] })),
        fetch("/api/academic").then((r) => r.json()).catch(() => ({ items: [] })),
        fetch("/api/projects").then((r) => r.json()).catch(() => ({ items: [] })),
        fetch("/api/ideas").then((r) => r.json()).catch(() => ({ ideas: [] })),
        fetch("/api/logs").then((r) => r.json()).catch(() => ({ logs: [] })),
      ]);

      if (resB.items) setBudgetItems(resB.items);
      if (resA.items) setAcademicItems(resA.items);
      if (resP.items) setProjects(resP.items);
      if (resI.ideas) setIdeas(resI.ideas);
      if (resL.logs) setLogs(resL.logs);
    } catch (err) {
      console.error("Fetch data error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Calculate live stats
  const totalAllocatedHours = budgetItems.reduce((acc, curr) => {
    const itemTotal = (curr.patterns || []).reduce(
      (s, p) => s + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0),
      0
    );
    return acc + itemTotal;
  }, 0);
  const roundedAllocated = Math.round(totalAllocatedHours * 10) / 10;
  const remainingHours = Math.round((168 - roundedAllocated) * 10) / 10;
  const totalPendingLectures = academicItems.reduce((acc, it) => acc + (it.pendingLectures || 0), 0);
  const primaryPivot = projects.find((p) => p.isPrimaryPivot || p.triageStatus === "pivot");

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-emerald-950 text-white font-black text-lg">
              168
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black text-white leading-tight">
                  منظومة الـ 168 ساعة الواقعية
                </h1>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded-full font-bold">
                  نسخة تفعيل القدرات التنفيذية
                </span>
              </div>
              <p className="text-xs text-slate-400">
                إدارة الوقت والدراسة والمشاريع بدون جلد الذات | مستوحى من منهجية م. محمد شبكة
              </p>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto pb-1 md:pb-0 text-xs">
            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl shrink-0 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>الموزع: <strong className="text-white font-mono">{roundedAllocated}</strong>/168س</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl shrink-0 flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${remainingHours < 0 ? "bg-rose-500" : "bg-sky-400"}`} />
              <span>المرن: <strong className={`font-mono ${remainingHours < 0 ? "text-rose-400" : "text-sky-300"}`}>{remainingHours}</strong>س</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl shrink-0 flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span>المحاضرات: <strong className="text-amber-300 font-mono">{totalPendingLectures}</strong> متأخرة</span>
            </div>

            <button
              onClick={fetchAllData}
              title="تحديث البيانات"
              className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-slate-400 hover:text-white transition shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Navigation */}
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center gap-1 overflow-x-auto py-2 no-scrollbar border-t border-slate-800/40">
          <button
            onClick={() => setActiveTab("budget")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "budget"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>ميزانية الـ 168 ساعة التفاعلية</span>
          </button>

          <button
            onClick={() => setActiveTab("academic")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "academic"
                ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>حصر التراكمات الدراسية</span>
          </button>

          <button
            onClick={() => setActiveTab("projects")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "projects"
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>جرد المشاريع والمشروع المحوري</span>
          </button>

          <button
            onClick={() => setActiveTab("schedule")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "schedule"
                ? "bg-sky-600 text-white shadow-md shadow-sky-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>الجدول الأسبوعي (يومًا بيوم)</span>
          </button>

          <button
            onClick={() => setActiveTab("energy")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "energy"
                ? "bg-rose-600 text-white shadow-md shadow-rose-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>مثلث الطاقة والتسجيل اليومي</span>
          </button>

          <button
            onClick={() => setActiveTab("reset")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "reset"
                ? "bg-amber-600 text-white shadow-md shadow-amber-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>درع المشتتات والتعافي (24س)</span>
          </button>

          <button
            onClick={() => setActiveTab("analysis")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition ${
              activeTab === "analysis"
                ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>التحليل الاستراتيجي والسؤالان</span>
          </button>
        </nav>
      </header>

      {/* Main Content Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 flex-1 w-full space-y-6">
        {isLoading ? (
          <div className="py-24 text-center space-y-3">
            <div className="w-10 h-10 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-slate-400">جاري تحميل بيانات منظومة الـ 168 ساعة...</p>
          </div>
        ) : (
          <>
            {activeTab === "budget" && (
              <BudgetSection items={budgetItems} onUpdate={fetchAllData} />
            )}

            {activeTab === "academic" && (
              <AcademicBacklogSection items={academicItems} onUpdate={fetchAllData} />
            )}

            {activeTab === "projects" && (
              <ProjectsSection projects={projects} ideas={ideas} onUpdate={fetchAllData} />
            )}

            {activeTab === "schedule" && <WeekScheduleSection />}

            {activeTab === "energy" && (
              <EnergyCheckinSection logs={logs} onUpdate={fetchAllData} />
            )}

            {activeTab === "reset" && <DistractionAndResetSection />}

            {activeTab === "analysis" && <StrategicAnalysisSection />}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>
            منظومة الـ 168 ساعة الواقعية © 2026 | مصممة خصيصاً لإعادة تفعيل القدرات التنفيذية
          </span>
          <span className="text-slate-600">
            «أحب الأعمال إلى الله أدومها وإن قل»
          </span>
        </div>
      </footer>
    </div>
  );
}
