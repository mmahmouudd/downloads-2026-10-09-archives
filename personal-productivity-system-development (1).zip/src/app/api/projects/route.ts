import { NextResponse } from "next/server";
import { db } from "@/db";
import { projectItems } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed-data";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeedData();
    const items = await db.select().from(projectItems).orderBy(projectItems.id);
    return NextResponse.json({ success: true, items });
  } catch (error) {
    console.error("GET /api/projects error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      title,
      category,
      description,
      workingState,
      missingParts,
      fixTimeEstHours,
      potentialValue,
      triageStatus,
      nextTinyStep,
      isPrimaryPivot,
    } = body;

    if (isPrimaryPivot) {
      await db.update(projectItems).set({ isPrimaryPivot: false });
    }

    const [newItem] = await db
      .insert(projectItems)
      .values({
        title,
        category: category || "code",
        description,
        workingState,
        missingParts,
        fixTimeEstHours: fixTimeEstHours ? Number(fixTimeEstHours) : null,
        potentialValue,
        triageStatus: triageStatus || "parked",
        nextTinyStep,
        isPrimaryPivot: Boolean(isPrimaryPivot),
      })
      .returning();

    return NextResponse.json({ success: true, item: newItem });
  } catch (error) {
    console.error("POST /api/projects error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { id, isPrimaryPivot, ...updates } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    if (isPrimaryPivot) {
      await db.update(projectItems).set({ isPrimaryPivot: false });
    }

    const [updated] = await db
      .update(projectItems)
      .set({
        ...updates,
        isPrimaryPivot: isPrimaryPivot !== undefined ? Boolean(isPrimaryPivot) : undefined,
        updatedAt: new Date(),
      })
      .where(eq(projectItems.id, Number(id)))
      .returning();

    return NextResponse.json({ success: true, item: updated });
  } catch (error) {
    console.error("PUT /api/projects error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    await db.delete(projectItems).where(eq(projectItems.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/projects error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
