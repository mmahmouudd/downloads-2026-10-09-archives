import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetItems } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed-data";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeedData();
    const items = await db.select().from(budgetItems).orderBy(budgetItems.id);
    return NextResponse.json({ success: true, items });
  } catch (error) {
    console.error("GET /api/budget error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { category, title, patterns, color, icon, notes } = body;

    // calculate total hours from patterns
    const totalHours = Array.isArray(patterns)
      ? patterns.reduce((sum: number, p: { days: number; hoursPerDay: number }) => {
          return sum + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0);
        }, 0)
      : 0;

    const [newItem] = await db
      .insert(budgetItems)
      .values({
        category: category || "عام",
        title: title || "نشاط جديد",
        patterns: patterns || [{ id: "p_" + Date.now(), days: 1, hoursPerDay: 1 }],
        totalHours: Math.round(totalHours),
        color: color || "indigo",
        icon: icon || "clock",
        notes: notes || "",
      })
      .returning();

    return NextResponse.json({ success: true, item: newItem });
  } catch (error) {
    console.error("POST /api/budget error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { id, title, category, patterns, color, notes } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    const totalHours = Array.isArray(patterns)
      ? patterns.reduce((sum: number, p: { days: number; hoursPerDay: number }) => {
          return sum + (Number(p.days) || 0) * (Number(p.hoursPerDay) || 0);
        }, 0)
      : 0;

    const [updated] = await db
      .update(budgetItems)
      .set({
        title,
        category,
        patterns,
        totalHours: Math.round(totalHours),
        color,
        notes,
        updatedAt: new Date(),
      })
      .where(eq(budgetItems.id, Number(id)))
      .returning();

    return NextResponse.json({ success: true, item: updated });
  } catch (error) {
    console.error("PUT /api/budget error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    await db.delete(budgetItems).where(eq(budgetItems.id, Number(id)));
    return NextResponse.json({ success: true, message: "Deleted" });
  } catch (error) {
    console.error("DELETE /api/budget error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
