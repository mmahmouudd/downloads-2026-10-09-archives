import { NextResponse } from "next/server";
import { db } from "@/db";
import { ideaInbox } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed-data";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeedData();
    const ideas = await db.select().from(ideaInbox).orderBy(desc(ideaInbox.id));
    return NextResponse.json({ success: true, ideas });
  } catch (error) {
    console.error("GET /api/ideas error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { title, details, category, status } = body;

    const [newIdea] = await db
      .insert(ideaInbox)
      .values({
        title,
        details,
        category: category || "general",
        status: status || "parked",
      })
      .returning();

    return NextResponse.json({ success: true, idea: newIdea });
  } catch (error) {
    console.error("POST /api/ideas error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    await db.delete(ideaInbox).where(eq(ideaInbox.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/ideas error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
