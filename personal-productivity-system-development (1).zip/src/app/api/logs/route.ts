import { NextResponse } from "next/server";
import { db } from "@/db";
import { dailyLogs } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed-data";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeedData();
    const logs = await db.select().from(dailyLogs).orderBy(desc(dailyLogs.logDate)).limit(30);
    return NextResponse.json({ success: true, logs });
  } catch (error) {
    console.error("GET /api/logs error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      logDate,
      sleepHours,
      sleepRating,
      nutritionRating,
      waterCups,
      movementRating,
      movementMins,
      prayersCount,
      hygieneDone,
      screenDistractionHours,
      dailyWin,
      reflection,
    } = body;

    const dateToUse = logDate || new Date().toISOString().split("T")[0];

    // Check if log for this date exists
    const [existing] = await db.select().from(dailyLogs).where(eq(dailyLogs.logDate, dateToUse));

    if (existing) {
      const [updated] = await db
        .update(dailyLogs)
        .set({
          sleepHours: Number(sleepHours),
          sleepRating: Number(sleepRating),
          nutritionRating: Number(nutritionRating),
          waterCups: Number(waterCups),
          movementRating: Number(movementRating),
          movementMins: Number(movementMins),
          prayersCount: Number(prayersCount),
          hygieneDone: Boolean(hygieneDone),
          screenDistractionHours: Number(screenDistractionHours),
          dailyWin,
          reflection,
        })
        .where(eq(dailyLogs.id, existing.id))
        .returning();

      return NextResponse.json({ success: true, log: updated, updated: true });
    }

    const [newLog] = await db
      .insert(dailyLogs)
      .values({
        logDate: dateToUse,
        sleepHours: Number(sleepHours) || 7,
        sleepRating: Number(sleepRating) || 3,
        nutritionRating: Number(nutritionRating) || 3,
        waterCups: Number(waterCups) || 4,
        movementRating: Number(movementRating) || 2,
        movementMins: Number(movementMins) || 15,
        prayersCount: Number(prayersCount) || 3,
        hygieneDone: Boolean(hygieneDone),
        screenDistractionHours: Number(screenDistractionHours) || 3,
        dailyWin: dailyWin || "بداية جديدة وتنظيم الخطوة الأولى",
        reflection: reflection || "",
      })
      .returning();

    return NextResponse.json({ success: true, log: newLog, updated: false });
  } catch (error) {
    console.error("POST /api/logs error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
