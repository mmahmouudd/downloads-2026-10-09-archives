import { NextResponse } from "next/server";

// Arabic number words mapping
const ARABIC_NUMBERS: Record<string, number> = {
  "صفر": 0,
  "واحد": 1,
  "واحدة": 1,
  "يوم": 1,
  "ساعة": 1,
  "اثنين": 2,
  "اثنان": 2,
  "يومين": 2,
  "ساعتين": 2,
  "ثلاث": 3,
  "ثلاثة": 3,
  "ثلاثة أيام": 3,
  "أربع": 4,
  "أربعة": 4,
  "خمس": 5,
  "خمسة": 5,
  "ست": 6,
  "ستة": 6,
  "سبع": 7,
  "سبعة": 7,
  "ثمان": 8,
  "ثمانية": 8,
  "تسع": 9,
  "تسعة": 9,
  "عشر": 10,
  "عشرة": 10,
  "أحد عشر": 11,
  "إحدى عشرة": 11,
  "اثنا عشر": 12,
  "اثني عشر": 12,
  "ثلاثة عشر": 13,
  "أربعة عشر": 14,
  "أربعة عشر ساعة": 14,
  "14": 14,
};

function normalizeArabic(text: string): string {
  return text
    .replace(/[إأآا]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ي/g, "ي")
    .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d).toString())
    .trim();
}

export async function POST(req: Request) {
  try {
    const { text } = await req.json();
    if (!text || typeof text !== "string") {
      return NextResponse.json({ success: false, error: "Text is required" }, { status: 400 });
    }

    const clean = text.trim();
    const norm = normalizeArabic(clean).toLowerCase();
    const patterns: Array<{ days: number; hoursPerDay: number }> = [];

    // Category detection
    let category = "أخرى";
    let title = "نشاط مدخل صوتياً/نصياً";
    let icon = "clock";
    let color = "indigo";

    if (norm.includes("نوم") || norm.includes("انام") || norm.includes("راحه") || norm.includes("استيقاظ") || norm.includes("سرير")) {
      category = "النوم والراحة والاستشفاء";
      title = "ساعات النوم والراحة";
      icon = "moon";
      color = "indigo";
    } else if (norm.includes("كلي") || norm.includes("جامع") || norm.includes("محاضر")) {
      category = "الدراسة الإلزامية: الكلية";
      title = "الكلية والمذاكرة";
      icon = "book-open";
      color = "blue";
    } else if (norm.includes("زاد") || norm.includes("اوزون") || norm.includes("كورس") || norm.includes("ماكنزي")) {
      category = "المساقات الإضافية";
      title = "المساقات التعليمية الإضافية";
      icon = "graduation-cap";
      color = "sky";
    } else if (norm.includes("صل") || norm.includes("مسجد") || norm.includes("قران") || norm.includes("دين")) {
      category = "الصلاة والعبادات";
      title = "الصلوات والعبادات";
      icon = "compass";
      color = "emerald";
    } else if (norm.includes("اكل") || norm.includes("طعام") || norm.includes("وجب") || norm.includes("ماء")) {
      category = "الطعام والشرب";
      title = "الوجبات والماء";
      icon = "utensils";
      color = "amber";
    } else if (norm.includes("رياض") || norm.includes("مشي") || norm.includes("تمرن") || norm.includes("جيم")) {
      category = "الرياضة والحركة";
      title = "الرياضة والمشي";
      icon = "activity";
      color = "rose";
    } else if (norm.includes("برمج") || norm.includes("مشروع") || norm.includes("كود") || norm.includes("vibe")) {
      category = "المشروع المحوري والتقنية";
      title = "المشروع والبرمجة";
      icon = "code";
      color = "cyan";
    } else if (norm.includes("هاتف") || norm.includes("سوشيال") || norm.includes("تيك") || norm.includes("يوتيوب")) {
      category = "الترفيه ومشتتات السوشيال";
      title = "استهلاك الشاشة";
      icon = "smartphone";
      color = "slate";
    }

    // Pattern extraction regex
    // Examples:
    // "6 ساعات في 3 أيام" or "6 ساعات في ثلاثة أيام"
    // "10 ساعات في يومين"
    // "14 ساعة في يومين"
    // "2 ساعة 5 أيام"
    // "8 ساعات يوميا" or "8 ساعات كل يوم"
    
    // Check for "X ساعات كل يوم" or "X ساعات يوميا"
    const dailyRegex = /(\d+|نصف|ساعتين|ساعة)\s*(?:ساعات?|ساعة)?\s*(?:يوميا|كل يوم)/i;
    const dailyMatch = clean.match(dailyRegex);
    if (dailyMatch) {
      let hours = 1;
      const raw = dailyMatch[1];
      if (raw === "ساعتين") hours = 2;
      else if (raw === "نصف") hours = 0.5;
      else if (raw === "ساعة") hours = 1;
      else hours = parseFloat(raw) || 1;
      patterns.push({ days: 7, hoursPerDay: hours });
    }

    // Check multi-segment matches
    // Regex matching "X ساعات في Y أيام" or "X ساعة Y يوم"
    const segmentRegex = /(\d+|ساعتين|ساعة)\s*(?:ساعات?|ساعة)?\s*(?:في|\s)\s*(\d+|يومين|يوم|ثلاثة|ثلاث|اربعة|اربع|خمسة|خمس|ستة|ست|سبعة|سبع)\s*(?:ايام|يوم|ايام)?/gi;
    let match;
    while ((match = segmentRegex.exec(clean)) !== null) {
      let hours = 0;
      let days = 0;

      const rawHours = match[1];
      if (rawHours === "ساعتين") hours = 2;
      else if (rawHours === "ساعة") hours = 1;
      else hours = parseFloat(rawHours) || 0;

      const rawDays = match[2];
      if (rawDays === "يومين") days = 2;
      else if (rawDays === "يوم") days = 1;
      else if (ARABIC_NUMBERS[rawDays]) days = ARABIC_NUMBERS[rawDays];
      else days = parseFloat(rawDays) || 1;

      if (hours > 0 && days > 0) {
        patterns.push({ days: Math.min(days, 7), hoursPerDay: hours });
      }
    }

    // If no complex pattern found, fallback to reasonable guess or default
    if (patterns.length === 0) {
      // Look for any numbers
      const numbers = clean.match(/\d+(\.\d+)?/g);
      if (numbers && numbers.length >= 2) {
        // e.g. 6 and 3 -> 6 hours in 3 days
        const h = parseFloat(numbers[0]);
        const d = parseFloat(numbers[1]);
        patterns.push({ days: Math.min(d, 7), hoursPerDay: h });
      } else if (numbers && numbers.length === 1) {
        patterns.push({ days: 7, hoursPerDay: parseFloat(numbers[0]) });
      } else {
        // default 1 pattern
        patterns.push({ days: 3, hoursPerDay: 2 });
      }
    }

    const totalDays = patterns.reduce((acc, p) => acc + p.days, 0);
    const totalHours = patterns.reduce((acc, p) => acc + p.days * p.hoursPerDay, 0);

    const summary = `تم استخراج ${patterns.length} نمط: ${patterns
      .map((p) => `${p.hoursPerDay} ساعة × ${p.days} أيام (= ${p.hoursPerDay * p.days} ساعة)`)
      .join("، ")}. إجمالي الأيام: ${totalDays} من 7 أيام. إجمالي الساعات: ${totalHours} ساعة.`;

    return NextResponse.json({
      success: true,
      data: {
        category,
        title,
        icon,
        color,
        patterns: patterns.map((p, idx) => ({ id: "gen_" + idx + "_" + Date.now(), ...p })),
        totalDays,
        totalHours,
        summary,
        warning:
          totalDays > 7
            ? "تنبيه: مجموع الأيام يتجاوز 7 أيام بالأسبوع!"
            : totalDays < 7
            ? `ملاحظة: تبقى ${7 - totalDays} أيام غير محددة لهذا النشاط.`
            : "المجموع يغطي بالضبط 7 أيام الأسبوع.",
      },
    });
  } catch (error) {
    console.error("POST /api/parse-natural error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
