import { NextResponse } from "next/server";
import { db } from "@/db";
import { academicItems } from "@/db/schema";
import { ensureSeedData } from "@/lib/seed-data";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeedData();
    const items = await db.select().from(academicItems).orderBy(academicItems.id);
    return NextResponse.json({ success: true, items });
  } catch (error) {
    console.error("GET /api/academic error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      institution,
      courseName,
      totalLectures,
      pendingLectures,
      completedLectures,
      durationPerLectureMins,
      requirementType,
      status,
      missingInfoStep,
      notes,
      priority,
    } = body;

    const [newItem] = await db
      .insert(academicItems)
      .values({
        institution: institution || "الكلية",
        courseName: courseName || "مقرر جديد",
        totalLectures: totalLectures ? Number(totalLectures) : null,
        pendingLectures: Number(pendingLectures) || 0,
        completedLectures: Number(completedLectures) || 0,
        durationPerLectureMins: Number(durationPerLectureMins) || 60,
        requirementType: requirementType || "watch_and_solve",
        status: status || "not_started",
        missingInfoStep: missingInfoStep || "",
        notes: notes || "",
        priority: priority || "high",
      })
      .returning();

    return NextResponse.json({ success: true, item: newItem });
  } catch (error) {
    console.error("POST /api/academic error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    const [updated] = await db
      .update(academicItems)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(academicItems.id, Number(id)))
      .returning();

    return NextResponse.json({ success: true, item: updated });
  } catch (error) {
    console.error("PUT /api/academic error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "ID required" }, { status: 400 });
    }

    await db.delete(academicItems).where(eq(academicItems.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/academic error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
