import { db } from "@/db";
import { budgetItems, academicItems, projectItems, dailyLogs, ideaInbox } from "@/db/schema";
import { count } from "drizzle-orm";

export async function ensureSeedData() {
  try {
    const [{ value: budgetCount }] = await db.select({ value: count() }).from(budgetItems);

    if (budgetCount === 0) {
      await db.insert(budgetItems).values([
        {
          category: "النوم والراحة والاستشفاء",
          title: "النوم والراحة المتفاوتة (الواقع الفعلي)",
          patterns: [
            { id: "p1", days: 3, hoursPerDay: 6 },
            { id: "p2", days: 2, hoursPerDay: 10 },
            { id: "p3", days: 2, hoursPerDay: 14 },
          ],
          totalHours: 66,
          color: "indigo",
          icon: "moon",
          notes: "تفاوت حقيقي بين 6 و10 و14 ساعة بسبب السهر والتنقل المفاجئ. الهدف التدريجي هو تقريب التباين نحو 7-8 ساعات مستقرة.",
        },
        {
          category: "الدراسة الإلزامية: الكلية",
          title: "الكلية (يوم حضور + يوم أونلاين + تعويض)",
          patterns: [
            { id: "p4", days: 1, hoursPerDay: 7 },
            { id: "p5", days: 1, hoursPerDay: 4 },
            { id: "p6", days: 3, hoursPerDay: 1.5 },
          ],
          totalHours: 16,
          color: "blue",
          icon: "book-open",
          notes: "يوم الحضور الجامعي (7 ساعات مع التنقل) + يوم الأونلاين (4 ساعات) + 3 جلسات تعويض للمواد المتراكمة (1.5 ساعة كل جلسة).",
        },
        {
          category: "المساقات الإضافية",
          title: "أكاديمية زاد ومعهد أوزون (متابعة خفيفة)",
          patterns: [
            { id: "p7", days: 3, hoursPerDay: 1.5 },
          ],
          totalHours: 5,
          color: "sky",
          icon: "graduation-cap",
          notes: "جلسات قصيرة محددة بمحاضرة واحدة فقط لمنع التشتت والضغط الزائد.",
        },
        {
          category: "الصلاة والعبادات",
          title: "الصلوات الخمس في أوقاتها + مشي المسجد",
          patterns: [
            { id: "p8", days: 7, hoursPerDay: 1.5 },
          ],
          totalHours: 11,
          color: "emerald",
          icon: "compass",
          notes: "المسجد يبعد 100 متر، وهي فرصة للحركة وتغيير جو الغرفة 5 مرات يومياً.",
        },
        {
          category: "الطعام والشرب",
          title: "الوجبات وشرب الماء المنظم",
          patterns: [
            { id: "p9", days: 7, hoursPerDay: 1.5 },
          ],
          totalHours: 11,
          color: "amber",
          icon: "utensils",
          notes: "وجبتان أساسيتان منتظمتان على الأقل + تذكير شرب كوب ماء مع كل صلاة.",
        },
        {
          category: "العناية الشخصية والنظافة",
          title: "النظافة الشخصية والاستحمام والملابس",
          patterns: [
            { id: "p10", days: 7, hoursPerDay: 1 },
          ],
          totalHours: 7,
          color: "teal",
          icon: "sparkles",
          notes: "تغيير الملابس يومياً، غسيل الوجه والأسنان بانتظام، استحمام دوري، وترتيب السرير فور الاستيقاظ.",
        },
        {
          category: "الرياضة والحركة",
          title: "المشي الخفيف وتنشيط الجسم",
          patterns: [
            { id: "p11", days: 5, hoursPerDay: 0.5 },
          ],
          totalHours: 3,
          color: "rose",
          icon: "activity",
          notes: "مشي 15-20 دقيقة وتفادي الجلوس المستمر لساعات طويلة أمام الشاشة.",
        },
        {
          category: "الأسرة والمسؤوليات",
          title: "جلسة الأسرة وترتيب الغرفة والمهام المنزلية",
          patterns: [
            { id: "p12", days: 7, hoursPerDay: 1 },
          ],
          totalHours: 7,
          color: "violet",
          icon: "users",
          notes: "المشاركة اليومية البسيطة والجلوس مع الوالدين وتخفيف العبء.",
        },
        {
          category: "المشروع المحوري والتقنية",
          title: "مشروع Vibe Coding الفردي المختار (هدف واقعي)",
          patterns: [
            { id: "p13", days: 5, hoursPerDay: 1 },
          ],
          totalHours: 5,
          color: "cyan",
          icon: "code",
          notes: "ساعة واحدة فقط يومياً مركزة بدلاً من الساعات المفتوحة غير المنضبطة، مخصصة لمشروع واحد قابل للإطلاق.",
        },
        {
          category: "الترفيه ومشتتات السوشيال",
          title: "استهلاك الهاتف والراحة غير الموجهة (الحالي المراد ترشيده)",
          patterns: [
            { id: "p14", days: 7, hoursPerDay: 3 },
          ],
          totalHours: 21,
          color: "slate",
          icon: "smartphone",
          notes: "اعتراف واقعي بالوقت المستهلك حالياً على Reels والتشتت، مع خطة لتقليصه واسترداد 10-15 ساعة منه تدريجياً.",
        },
        {
          category: "الراحة والوقت الاحتياطي",
          title: "وقت مرن للطوارئ والتقاط الأنفاس",
          patterns: [
            { id: "p15", days: 7, hoursPerDay: 2.3 },
          ],
          totalHours: 16,
          color: "zinc",
          icon: "shield",
          notes: "مساحة أمان لمنع التراكم عند حدوث طارئ وتفادي الضغط العصبي.",
        },
      ]);
    }

    const [{ value: academicCount }] = await db.select({ value: count() }).from(academicItems);
    if (academicCount === 0) {
      await db.insert(academicItems).values([
        {
          institution: "الكلية",
          courseName: "المواد الجامعية الأساسية (9 مواد)",
          totalLectures: 18,
          pendingLectures: 18,
          completedLectures: 0,
          durationPerLectureMins: 90,
          requirementType: "watch_and_solve",
          status: "not_started",
          missingInfoStep: "مراجعة جدول الكلية والتواصل مع زميل لحصر الـ 18 محاضرة المتراكمة مادة بمادة ومواعيد التسليمات",
          notes: "الأولوية رقم 1 المطلقة في الأكاديميا: يوم حضور + يوم أونلاين، مع تخصيص 1.5 ساعة لمادة واحدة يومياً.",
          priority: "urgent",
        },
        {
          institution: "أكاديمية زاد",
          courseName: "برنامج زاد للعلوم الشرعية - المستوى الأول",
          totalLectures: null,
          pendingLectures: 18,
          completedLectures: 0,
          durationPerLectureMins: 45,
          requirementType: "watch_and_solve",
          status: "pending",
          missingInfoStep: "تسجيل الدخول على حساب زاد وحصر عدد المحاضرات التي نزلت خلال الأسابيع الـ 8-9 الماضية وتاريخ أول اختبار",
          notes: "القبول تم بحمد الله. المطلوب: خطوة أولى 15 دقيقة لفتح المنصة وحصر المتأخر دون بدء الاستماع العشوائي.",
          priority: "high",
        },
        {
          institution: "معهد أوزون برو ماكس",
          courseName: "محاضرات د. حازم شومان (تيليجرام)",
          totalLectures: null,
          pendingLectures: 10,
          completedLectures: 0,
          durationPerLectureMins: 45,
          requirementType: "watch_only",
          status: "pending",
          missingInfoStep: "فتح مجموعة التيليجرام وفهرسة الروابط أو الملفات وتدوين عدد التسجيلات الفعلي",
          notes: "محتوى إيماني ودعوي يساعد على تنشيط القلب. الاستماع أثناء المشي أو الاستراحة.",
          priority: "medium",
        },
        {
          institution: "ماكنزي / McKinsey",
          courseName: "برنامج ماكنزي التدريبي (مجهول التفاصيل حالياً)",
          totalLectures: null,
          pendingLectures: 0,
          completedLectures: 0,
          durationPerLectureMins: 60,
          requirementType: "watch_and_solve",
          status: "not_started",
          missingInfoStep: "التحقق من تفاصيل القبول ورابط المنصة، وما إذا كان المحتوى عربياً أم إنجليزياً، وشروط الشهادة",
          notes: "مؤجل بالكامل حتى استقرار الكلية، خانة مخصصة للمعلومات فقط دون أي ضغط تنفيذي الآن.",
          priority: "parked",
        },
        {
          institution: "برنامج 2B",
          courseName: "برنامج 2B (غير محدد التفاصيل)",
          totalLectures: null,
          pendingLectures: 0,
          completedLectures: 0,
          durationPerLectureMins: 60,
          requirementType: "watch_only",
          status: "not_started",
          missingInfoStep: "البحث في الملاحظات أو البريد لمعرفة الاسم الكامل للمشروع والجهة الراعية وطبيعة الالتزام",
          notes: "خانة مؤقتة لتأكيد التفاصيل دون اختلاق معلومات غير مؤكدة.",
          priority: "parked",
        },
      ]);
    }

    const [{ value: projectCount }] = await db.select({ value: count() }).from(projectItems);
    if (projectCount === 0) {
      await db.insert(projectItems).values([
        {
          title: "فرز مشروعات Vibe Coding ونشر أفضل مشروع واحد (بورتفوليو حقيقي)",
          category: "vibe_iterations",
          description: "لديك مئات الإصدارات وواجهات كثيرة. المشروع المحوري هو اختيار أفضل مشروع يعمل الـ Back-End فيه، تنقيح واجهته من الألوان الفاقعة غير الاحترافية، ورفعه على GitHub وVercel برابط معلن.",
          workingState: "أكواد كثيرة بعضها يحتوي منطق Back-End سليم ونماذج تعمل.",
          missingParts: "تنظيم الواجهة، فحص الأخطاء، ونشر على رابط مباشر واحد + Portfolio منظم على GitHub.",
          fixTimeEstHours: 6,
          potentialValue: "إثبات قدرتك لنفسك وللآخرين، تحويل المئات المبعثرة إلى أصل رقمي واحد معلن وناجح.",
          triageStatus: "pivot",
          nextTinyStep: "فتح المجلد وتحديد أفضل مشروع واحد فقط، ونقل البقية لمجلد Archive لمدة 14 يوماً.",
          isPrimaryPivot: true,
        },
        {
          title: "كتاب البيزنس وتأسيس شركة شخص واحد بمصر وتأسيس وكالة AI",
          category: "business_book",
          description: "مسودة كتاب بالذكاء الاصطناعي مع خطة لوكالة تعتمد على الذكاء الاصطناعي ومستقلين محترفين.",
          workingState: "مسودة نصية وهيكل أفكار مكتوب.",
          missingParts: "تحقق قانوني للسوق المصري، وتجربة بيع حقيقية، واستقرار الوقت الدراسي.",
          fixTimeEstHours: 25,
          potentialValue: "مهم مستقبلاً، لكنه حالياً يلتهم طاقة هائلة من دون إيراد فوري.",
          triageStatus: "parked",
          nextTinyStep: "حفظ المسودة في Google Drive ووضعها في قائمة الانتظار حتى انتهاء اختبارات الكلية.",
          isPrimaryPivot: false,
        },
        {
          title: "مصنع إعادة توظيف المحتوى الرائج (Repurposing Engine)",
          category: "content",
          description: "أداة آلية لاستخراج أفكار فيديوهات الفيروسات وتحويلها لبودكاست ومقاطع قصيرة.",
          workingState: "تصور نظري وتجارب برمجية أولية غير مكتملة.",
          missingParts: "برمجة متكاملة، وحل مشكلة حقوق الملكية الفكرية لتجنب مخالفات المنصات.",
          fixTimeEstHours: 40,
          potentialValue: "تقني ومثير، لكنه معقد جداً في وضعك الحالي.",
          triageStatus: "parked",
          nextTinyStep: "تجميد الفكرة والتركيز على البرمجة الأساسية في Vibe Coding.",
          isPrimaryPivot: false,
        },
        {
          title: "القصص المصورة والمانجا والروايات بالذكاء الاصطناعي",
          category: "comics",
          description: "محاولة توليد ونشر قصة مصورة للبيع عبر الإنترنت.",
          workingState: "تجارب صور ونصوص عشوائية.",
          missingParts: "حبكة مكتملة، اتساق الشخصيات، وخطة تسويق ومنصة دفع.",
          fixTimeEstHours: 35,
          potentialValue: "احتمالية بيع غير مؤكدة واستنزاف بصري عالي.",
          triageStatus: "archived",
          nextTinyStep: "أرشفة المجلد بالكامل دون الرجوع إليه هذا الشهر.",
          isPrimaryPivot: false,
        },
        {
          title: "المحتوى الديني بالذكاء الاصطناعي",
          category: "content",
          description: "صفحة أو قناة لإنتاج مقاطع دينية وتصاميم بالذكاء الاصطناعي.",
          workingState: "تجارب أولية لبعض المقاطع.",
          missingParts: "مراجعة شرعية دقيقة، نظام إنتاج أسبوعي ثابت غير مشتت.",
          fixTimeEstHours: 12,
          potentialValue: "أجر ونفع، لكن الأولى الالتزام بالفرائض والكلية قبل الدعوة الرقمية.",
          triageStatus: "parked",
          nextTinyStep: "تأجيل حتى انتظام الصلوات الخمس ومحاضرات الكلية.",
          isPrimaryPivot: false,
        },
      ]);
    }

    const [{ value: ideasCount }] = await db.select({ value: count() }).from(ideaInbox);
    if (ideasCount === 0) {
      await db.insert(ideaInbox).values([
        {
          title: "غرفة مسجد مخصصة في بيت المستقبل بمئذنة وتكييف وسجاد وإضاءة هادئة",
          details: "رؤية بعيدة المدى مباركة، تُحفظ في الصندوق لتعطي أملاً ولا تشغل عن صلاة المسجد الحالي (100م).",
          category: "spiritual_future",
          status: "parked",
        },
        {
          title: "بناء جسم رياضي 70 كجم وتعلم فنون قتالية للدفاع عن النفس",
          details: "البداية الحالية: مشي 15 دقيقة يومياً وشرب الماء وزيادة الوزن تدريجياً من 52 كجم.",
          category: "health",
          status: "parked",
        },
        {
          title: "تعلم بايثون وتطوير الواجهات الأمامية والإنجليزية بالتفصيل",
          details: "مسار رائع يتم تفعيله بمجرد السيطرة على مواد الكلية الحالية.",
          category: "learning",
          status: "parked",
        },
        {
          title: "وكالة تسويق رقمي تعتمد على الذكاء الاصطناعي ومستقلين محترفين",
          details: "تأجيل حتى انتهاء الكلية أو الحصول على أول عميل تدريبي.",
          category: "business",
          status: "parked",
        },
      ]);
    }

    const [{ value: logCount }] = await db.select({ value: count() }).from(dailyLogs);
    if (logCount === 0) {
      const today = new Date().toISOString().split("T")[0];
      await db.insert(dailyLogs).values([
        {
          logDate: today,
          sleepHours: 8,
          sleepRating: 3,
          nutritionRating: 3,
          waterCups: 4,
          movementRating: 2,
          movementMins: 15,
          prayersCount: 3,
          hygieneDone: true,
          screenDistractionHours: 3,
          dailyWin: "ترتيب السرير والغرفة، والبدء في وضع خطة تنظيم الـ 168 ساعة الواقعية.",
          reflection: "خطوة البداية دائماً صعبة، لكن مجرد وضع الأمور على الطاولة يخفف العبء الذهني.",
        },
      ]);
    }

    return { success: true };
  } catch (error) {
    console.error("Error in ensureSeedData:", error);
    return { success: false, error: String(error) };
  }
}
