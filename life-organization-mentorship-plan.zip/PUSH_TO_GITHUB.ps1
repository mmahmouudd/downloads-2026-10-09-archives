# رفع المشروع إلى GitHub داخل مجلد باسم فريد (Windows PowerShell)
# الاستخدام:
#   $env:GITHUB_TOKEN = "ghp_xxx"
#   .\PUSH_TO_GITHUB.ps1 https://github.com/user/repo

param(
  [Parameter(Mandatory = $true)][string]$Repo
)

if (-not $env:GITHUB_TOKEN) {
  Write-Host "خطأ: ضع التوكن في GITHUB_TOKEN ولا تكتبه داخل الملف."
  exit 1
}

$slug = $Repo -replace '^https://github.com/', '' -replace '\.git$', '' -replace '/$', ''
$folder = "week168-planner-$(Get-Date -Format yyyyMMdd)-$(Get-Random -Minimum 1000 -Maximum 9999)"
Write-Host "المجلد الجديد: $folder"

$tmp = Join-Path $env:TEMP ("ghpush-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tmp | Out-Null

git clone --depth 1 "https://x-access-token:$($env:GITHUB_TOKEN)@github.com/$slug.git" (Join-Path $tmp "repo")
Set-Location (Join-Path $tmp "repo")

New-Item -ItemType Directory -Path $folder | Out-Null

$srcDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$items = @("src", "public", "index.html", "package.json", "tsconfig.json", "vite.config.ts", "tailwind.config.js", "postcss.config.js")
foreach ($item in $items) {
  $p = Join-Path $srcDir $item
  if (Test-Path $p) { Copy-Item -Recurse -Force $p (Join-Path (Get-Location) $folder) }
}
if (Test-Path (Join-Path $srcDir "README-EXPORT.md")) {
  Copy-Item -Force (Join-Path $srcDir "README-EXPORT.md") (Join-Path (Get-Location) "$folder/README.md")
}

Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path $folder "dist")
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue (Join-Path $folder "node_modules")

git config user.name "dev"
git config user.email "dev@users.noreply.github.com"
git add $folder
git commit -m "add: $folder (week168 planner)"
git push origin HEAD

Write-Host "تم الرفع: https://github.com/$slug/tree/main/$folder"
Set-Location $srcDir
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $tmp
