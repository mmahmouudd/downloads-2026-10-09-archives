export type Tab = 'home' | 'budget' | 'schedule' | 'study' | 'projects' | 'track' | 'plan';

export type CategoryId =
  | 'sleep'
  | 'study'
  | 'courses'
  | 'work'
  | 'projects'
  | 'worship'
  | 'food'
  | 'selfcare'
  | 'move'
  | 'family'
  | 'commute'
  | 'leisure'
  | 'buffer';

export type Priority = 'urgent' | 'important' | 'optional' | 'later';
export type Scenario = 'current' | 'plan';

export interface Pattern {
  id: string;
  hours: number; // ساعات في اليوم
  days: number; // عدد الأيام
}

export interface Activity {
  id: string;
  name: string;
  cat: CategoryId;
  priority: Priority;
  deep: boolean; // يُحسب ضمن التركيز العميق الذاتي
  patterns: Pattern[];
  note?: string;
}

export interface Block {
  id: string;
  day: number; // 0 = السبت ... 6 = الجمعة
  start: string; // HH:MM
  end: string; // HH:MM
  title: string;
  cat: CategoryId;
  priority: Priority;
  deep: boolean;
}

export type StudyKind = 'mandatory' | 'program' | 'optional';
export type StudyStatus = 'notstarted' | 'doing' | 'done';

export interface StudyItem {
  id: string;
  name: string;
  kind: StudyKind;
  priority: Priority;
  total: number | null; // إجمالي المحاضرات (إن عُرف)
  backlog: number | null; // المتراكم (إن عُرف)
  done: number; // ما أُنجز من المتراكم
  minutes: number | null; // مدة المحاضرة
  factor: number; // 1 مشاهدة فقط، 1.5 مشاهدة + حل ومراجعة
  status: StudyStatus;
  deadline: string;
  review: string;
  missing: string; // الخطوة لمعرفة الناقص
}

export type ProjectStatus = 'idea' | 'partial' | 'building' | 'done' | 'archived';
export type Decision = 'focus' | 'queue' | 'pause' | 'archive';

export interface Project {
  id: string;
  name: string;
  idea: string;
  status: ProjectStatus;
  works: string;
  missing: string;
  fixHours: number | null;
  value: number; // 1-5
  readiness: number; // 1-5
  alignment: number; // 1-5
  effort: number; // 1-5 (الأقل أفضل)
  next: string;
  decision: Decision;
}

export interface Idea {
  id: string;
  text: string;
  date: string;
}

export interface DayLog {
  date: string;
  sleepHours: number | null;
  sleepQ: number;
  nutriQ: number;
  moveQ: number;
  meals: number;
  water: number;
  walkMin: number;
  selfCare: boolean;
  prayers: number;
  socialMin: number;
  leisureMin: number;
  win: string;
  trigger: string;
}

export interface AppState {
  v: 1;
  scenario: Scenario;
  activities: Record<Scenario, Activity[]>;
  blocks: Block[];
  study: StudyItem[];
  studyWeekly: number;
  projects: Project[];
  ideas: Idea[];
  logs: DayLog[];
  focusFactor: number;
}
