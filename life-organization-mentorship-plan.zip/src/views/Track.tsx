import { useState } from 'react';
import type { DayLog } from '../types';
import { useStore } from '../lib/store';
import { fmt, todayStr } from '../lib/util';
import { Card, Field, H2, Notice, NullNum, NumInput, Rate, Stat, inputCls } from '../components/ui';

const blank = (date: string): DayLog => ({
  date,
  sleepHours: null,
  sleepQ: 3,
  nutriQ: 3,
  moveQ: 3,
  meals: 0,
  water: 0,
  walkMin: 0,
  selfCare: false,
  prayers: 0,
  socialMin: 0,
  leisureMin: 0,
  win: '',
  trigger: '',
});

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);

export function Track() {
  const { state, set } = useStore();
  const [date, setDate] = useState(todayStr());
  const log = state.logs.find((l) => l.date === date) ?? blank(date);

  const upd = (patch: Partial<DayLog>) =>
    set((s) => {
      const cur = s.logs.find((l) => l.date === date) ?? blank(date);
      const next = { ...cur, ...patch };
      const others = s.logs.filter((l) => l.date !== date);
      return { ...s, logs: [...others, next].sort((a, b) => (a.date < b.date ? 1 : -1)) };
    });

  const recent = [...state.logs].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 7);
  const sleeps = recent.map((l) => l.sleepHours).filter((x): x is number => x !== null);
  const sleepRange = sleeps.length ? Math.max(...sleeps) - Math.min(...sleeps) : null;

  return (
    <div className="space-y-5">
      <Card>
        <H2 sub="دقيقتان في اليوم. هذه ملاحظات وتدرّج وليست حكمًا عليك ولا تشخيصًا طبيًا. الرقم الأسوأ اليوم هو معلومة لتعديل خطة الغد.">المتابعة اليومية</H2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="التاريخ">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value || todayStr())} className={inputCls} />
          </Field>
          <Field label="ساعات النوم الليلة الماضية" hint="فارغ = لم تقِس">
            <NullNum value={log.sleepHours} onChange={(v) => upd({ sleepHours: v === null ? null : Math.min(24, v) })} placeholder="مثال: 7.5" />
          </Field>
        </div>

        <div className="mt-5 grid gap-5 sm:grid-cols-3">
          <div>
            <div className="mb-1.5 text-[15px] font-semibold text-ink">جودة النوم (1–5)</div>
            <Rate value={log.sleepQ} onChange={(v) => upd({ sleepQ: v })} label="جودة النوم" />
          </div>
          <div>
            <div className="mb-1.5 text-[15px] font-semibold text-ink">الغذاء والترطيب (1–5)</div>
            <Rate value={log.nutriQ} onChange={(v) => upd({ nutriQ: v })} label="الغذاء والترطيب" />
          </div>
          <div>
            <div className="mb-1.5 text-[15px] font-semibold text-ink">الحركة والنشاط (1–5)</div>
            <Rate value={log.moveQ} onChange={(v) => upd({ moveQ: v })} label="الحركة" />
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {(
            [
              ['meals', 'وجبات', 0, 6, 1],
              ['water', 'أكواب ماء', 0, 20, 1],
              ['walkMin', 'دقائق مشي', 0, 300, 5],
              ['prayers', 'صلوات (0–5)', 0, 5, 1],
              ['socialMin', 'دقائق تواصل', 0, 600, 5],
              ['leisureMin', 'دقائق سوشيال/ترفيه', 0, 1000, 10],
            ] as [keyof DayLog, string, number, number, number][]
          ).map(([k, l, mn, mx, st]) => (
            <label key={k} className="block text-[15px] font-semibold text-ink">
              {l}
              <NumInput value={log[k] as number} min={mn} max={mx} step={st} onChange={(v) => upd({ [k]: v } as Partial<DayLog>)} className="mt-1 !w-full" label={l} />
            </label>
          ))}
        </div>

        <label className="mt-5 flex cursor-pointer items-center gap-2 text-[16px] text-ink">
          <input type="checkbox" checked={log.selfCare} onChange={(e) => upd({ selfCare: e.target.checked })} className="h-5 w-5 accent-[#1f6a67]" />
          أنجزتُ العناية الأساسية اليوم (استحمام/أسنان/ملابس نظيفة)
        </label>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <Field label="إنجاز واحد أساسي تحقق اليوم">
            <input value={log.win} onChange={(e) => upd({ win: e.target.value })} placeholder="ولو صغيرًا: رتبتُ غرفتي" className={inputCls} />
          </Field>
          <Field label="ما الذي سحبني عن المهمة؟ (إن حدث)" hint="سطر واحد: سجّل المحفّز دون تفاصيل">
            <input value={log.trigger} onChange={(e) => upd({ trigger: e.target.value })} placeholder="مثال: فشل تصميم → تيك توك" className={inputCls} />
          </Field>
        </div>
        <p className="mt-3 text-sm text-muted">يُحفظ تلقائيًا على جهازك.</p>
      </Card>

      <Card>
        <H2>آخر 7 أيام مسجّلة</H2>
        {recent.length === 0 ? (
          <Notice tone="info">لا تسجيلات بعد. ابدأ بتسجيل اليوم؛ بعد 3 أيام سترى نمطك الحقيقي بدل التقدير.</Notice>
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Stat label="متوسط النوم" value={sleeps.length ? `${fmt(avg(sleeps)!)} س` : '—'} sub={sleepRange !== null ? `الفرق بين الأطول والأقصر: ${fmt(sleepRange)} س` : ''} />
              <Stat label="متوسط الوجبات" value={fmt(avg(recent.map((l) => l.meals)) ?? 0)} />
              <Stat label="متوسط الماء" value={`${fmt(avg(recent.map((l) => l.water)) ?? 0)} كوب`} />
              <Stat label="متوسط سوشيال/ترفيه" value={`${fmt(avg(recent.map((l) => l.leisureMin)) ?? 0)} د`} />
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[40rem] text-[15px]">
                <thead>
                  <tr className="border-b border-line text-muted">
                    {['التاريخ', 'النوم', 'وجبات', 'ماء', 'مشي', 'صلوات', 'ترفيه', 'الإنجاز'].map((h) => (
                      <th key={h} className="py-2 text-start font-semibold">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {recent.map((l) => (
                    <tr key={l.date} className="border-b border-line/60">
                      <td className="py-2">{l.date}</td>
                      <td className="py-2">{l.sleepHours ?? '—'}</td>
                      <td className="py-2">{l.meals}</td>
                      <td className="py-2">{l.water}</td>
                      <td className="py-2">{l.walkMin} د</td>
                      <td className="py-2">{l.prayers}/5</td>
                      <td className="py-2">{l.leisureMin} د</td>
                      <td className="py-2">{l.win || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {sleepRange !== null && sleepRange >= 4 && (
              <div className="mt-3">
                <Notice tone="info">نومك يتفاوت بنحو {fmt(sleepRange)} ساعات هذا الأسبوع. ثبّت وقت الاستيقاظ أولًا؛ هذا يخفض التفاوت أسرع من محاولة ضبط وقت النوم.</Notice>
              </div>
            )}
          </>
        )}
      </Card>
    </div>
  );
}
