import { useState } from 'react';
import type { Decision, Project, ProjectStatus } from '../types';
import { useStore } from '../lib/store';
import { projectScore } from '../lib/calc';
import { fmt, todayStr, uid } from '../lib/util';
import { Btn, Card, Field, H2, NullNum, Notice, Select, inputCls } from '../components/ui';

const STATUS: { value: ProjectStatus; label: string }[] = [
  { value: 'idea', label: 'فكرة فقط' },
  { value: 'partial', label: 'يعمل جزئيًا' },
  { value: 'building', label: 'قيد البناء' },
  { value: 'done', label: 'مكتمل' },
  { value: 'archived', label: 'مؤرشف' },
];
const DECISION: { value: Decision; label: string }[] = [
  { value: 'focus', label: 'ركّز عليه الآن' },
  { value: 'queue', label: 'قائمة الانتظار' },
  { value: 'pause', label: 'إيقاف مؤقت' },
  { value: 'archive', label: 'أرشفة/تجاهل' },
];
const DEC_CLS: Record<Decision, string> = {
  focus: 'bg-brand text-white',
  queue: 'bg-[#dde8ee] text-[#2f5566]',
  pause: 'bg-[#f6e8c8] text-[#7a5410]',
  archive: 'bg-[#e8e5dc] text-[#5b686c]',
};
const SCORES = [1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }));

function ProjectCard({ p, onChange, onDelete }: { p: Project; onChange: (p: Project) => void; onDelete: () => void }) {
  const upd = (patch: Partial<Project>) => onChange({ ...p, ...patch });
  return (
    <details className="rounded-2xl border border-line bg-white" open={p.decision === 'focus'}>
      <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 px-4 py-3.5">
        <span className="text-[17px] font-bold text-ink">{p.name}</span>
        <span className="flex items-center gap-2">
          <span className="text-[15px] text-muted">النتيجة {projectScore(p)} / 20</span>
          <span className={`rounded-full px-2.5 py-0.5 text-sm font-semibold ${DEC_CLS[p.decision]}`}>{DECISION.find((d) => d.value === p.decision)?.label}</span>
        </span>
      </summary>
      <div className="space-y-4 border-t border-line p-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="الاسم">
            <input value={p.name} onChange={(e) => upd({ name: e.target.value })} className={inputCls} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الحالة">
              <Select value={p.status} onChange={(v) => upd({ status: v })} options={STATUS} className="w-full" />
            </Field>
            <Field label="القرار">
              <Select value={p.decision} onChange={(v) => upd({ decision: v })} options={DECISION} className="w-full" />
            </Field>
          </div>
        </div>
        <Field label="الفكرة">
          <textarea value={p.idea} onChange={(e) => upd({ idea: e.target.value })} rows={2} className={inputCls} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="ما يعمل منه">
            <textarea value={p.works} onChange={(e) => upd({ works: e.target.value })} rows={2} className={inputCls} />
          </Field>
          <Field label="ما ينقصه">
            <textarea value={p.missing} onChange={(e) => upd({ missing: e.target.value })} rows={2} className={inputCls} />
          </Field>
          <Field label="وقت الإصلاح التقديري (ساعات)" hint="فارغ = غير معروف">
            <NullNum value={p.fixHours} onChange={(v) => upd({ fixHours: v })} />
          </Field>
          <Field label="الخطوة التالية (10–20 دقيقة)">
            <input value={p.next} onChange={(e) => upd({ next: e.target.value })} className={inputCls} />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {(
            [
              ['value', 'القيمة المحتملة'],
              ['readiness', 'الجاهزية الحالية'],
              ['alignment', 'توافقه مع هدف المرحلة'],
              ['effort', 'الجهد لإكماله (الأقل أفضل)'],
            ] as [keyof Project, string][]
          ).map(([k, l]) => (
            <Field key={k} label={l}>
              <Select value={String(p[k])} onChange={(v) => upd({ [k]: parseInt(v) } as Partial<Project>)} options={SCORES} className="w-full" />
            </Field>
          ))}
        </div>
        <Btn variant="danger" onClick={onDelete}>
          حذف المشروع
        </Btn>
      </div>
    </details>
  );
}

export function Projects() {
  const { state, set } = useStore();
  const [idea, setIdea] = useState('');
  const ps = state.projects;
  const setPs = (f: (p: Project[]) => Project[]) => set((s) => ({ ...s, projects: f(s.projects) }));
  const ranked = [...ps].filter((p) => p.decision !== 'archive').sort((a, b) => projectScore(b) - projectScore(a));
  const focusCount = ps.filter((p) => p.decision === 'focus').length;
  const top = ranked[0];

  const addIdea = () => {
    const t = idea.trim();
    if (!t) return;
    set((s) => ({ ...s, ideas: [{ id: uid(), text: t, date: todayStr() }, ...s.ideas] }));
    setIdea('');
  };

  const promote = (id: string) => {
    const it = state.ideas.find((i) => i.id === id);
    if (!it) return;
    set((s) => ({
      ...s,
      ideas: s.ideas.filter((i) => i.id !== id),
      projects: [
        ...s.projects,
        { id: uid(), name: it.text.slice(0, 60), idea: it.text, status: 'idea', works: '', missing: '', fixHours: null, value: 3, readiness: 1, alignment: 2, effort: 3, next: '', decision: 'queue' },
      ],
    }));
  };

  return (
    <div className="space-y-5">
      <Card>
        <H2 sub="الجرد الموحد: لكل مشروع ما يعمل وما ينقص ووقت الإصلاح والقيمة والخطوة التالية. المعيار: القيمة + الجاهزية + التوافق + (6 − الجهد) من 20.">جرد المشاريع واختيار واحد</H2>
        {top && (
          <Notice tone="good">
            الأعلى نتيجة الآن: <b>{top.name}</b> ({projectScore(top)}/20). اختيار مشروع واحد فقط في حالة «ركّز».
          </Notice>
        )}
        {focusCount > 1 && (
          <div className="mt-3">
            <Notice tone="bad">لديك {focusCount} مشاريع في حالة «ركّز». اترك واحدًا فقط وانقل الباقي لقائمة الانتظار.</Notice>
          </div>
        )}
        {focusCount === 0 && (
          <div className="mt-3">
            <Notice tone="warn">لا يوجد مشروع محوري. اختر واحدًا.</Notice>
          </div>
        )}
        <div className="mt-3 text-[15px] leading-7 text-muted">
          ملاحظة تقنية: أعمالك الكثيرة (100–500 نسخة) تقديرات غير مدققة. لا تنشرها دفعة واحدة: اختر واحدًا، شغّله، أصلحه، انشره برابط مستقل، ثم اكتب له README وصورة شاشة.
        </div>
      </Card>

      <div className="space-y-2.5">
        {ranked.map((p) => (
          <ProjectCard key={p.id} p={p} onChange={(n) => setPs((x) => x.map((y) => (y.id === n.id ? n : y)))} onDelete={() => setPs((x) => x.filter((y) => y.id !== p.id))} />
        ))}
        {ps
          .filter((p) => p.decision === 'archive')
          .map((p) => (
            <ProjectCard key={p.id} p={p} onChange={(n) => setPs((x) => x.map((y) => (y.id === n.id ? n : y)))} onDelete={() => setPs((x) => x.filter((y) => y.id !== p.id))} />
          ))}
        <Btn
          variant="ghost"
          onClick={() =>
            setPs((x) => [...x, { id: uid(), name: 'مشروع جديد', idea: '', status: 'idea', works: '', missing: '', fixHours: null, value: 3, readiness: 2, alignment: 2, effort: 3, next: '', decision: 'queue' }])
          }
        >
          + إضافة مشروع إلى الجرد
        </Btn>
      </div>

      <Card>
        <H2 sub="فكرة جديدة؟ اكتبها في سطر واحد (30 ثانية) ثم ارجع لمهمتك. لا تُفتح أي فكرة قبل مراجعة يوم الجمعة.">قائمة انتظار الأفكار</H2>
        <div className="flex gap-2">
          <input
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addIdea()}
            placeholder="سجّل الفكرة هنا ولا تبدأها…"
            className={inputCls}
            aria-label="فكرة جديدة"
          />
          <Btn onClick={addIdea}>سجّل</Btn>
        </div>
        <ul className="mt-3 space-y-2">
          {state.ideas.length === 0 && <li className="text-[15px] text-muted">لا أفكار في الانتظار.</li>}
          {state.ideas.map((i) => (
            <li key={i.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white px-3 py-2.5">
              <span className="text-[15px] text-ink">
                {i.text} <span className="text-sm text-muted">({i.date})</span>
              </span>
              <span className="flex gap-2">
                <Btn variant="soft" onClick={() => promote(i.id)} className="!py-1.5">
                  أضف للجرد
                </Btn>
                <Btn variant="danger" onClick={() => set((s) => ({ ...s, ideas: s.ideas.filter((x) => x.id !== i.id) }))} className="!py-1.5">
                  حذف
                </Btn>
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">عدد الأفكار المنتظرة: {fmt(state.ideas.length)}</p>
      </Card>
    </div>
  );
}
