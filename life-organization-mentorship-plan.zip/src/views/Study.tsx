import type { Priority, StudyItem, StudyKind, StudyStatus } from '../types';
import { useStore } from '../lib/store';
import { PRIORITY_OPTIONS } from '../lib/constants';
import { studyHours, studyRemaining } from '../lib/calc';
import { fmt, uid } from '../lib/util';
import { Btn, Card, Field, H2, NullNum, Notice, NumInput, PriorityBadge, Select, Stat, inputCls } from '../components/ui';

const KIND: { value: StudyKind; label: string }[] = [
  { value: 'mandatory', label: 'إلزامي (الكلية)' },
  { value: 'program', label: 'برنامج مسجَّل فيه' },
  { value: 'optional', label: 'تعلم اختياري/طموح' },
];
const STATUS: { value: StudyStatus; label: string }[] = [
  { value: 'notstarted', label: 'لم تبدأ' },
  { value: 'doing', label: 'قيد التنفيذ' },
  { value: 'done', label: 'مكتملة' },
];
const FACTOR = [
  { value: '1', label: 'مشاهدة فقط (×1)' },
  { value: '1.5', label: 'مشاهدة + حل ومراجعة (×1.5)' },
];

function Item({ s, onChange, onDelete }: { s: StudyItem; onChange: (s: StudyItem) => void; onDelete: () => void }) {
  const rem = studyRemaining(s);
  const hrs = studyHours(s);
  const base = s.backlog ?? s.total;
  const pct = base ? Math.min(100, Math.round((s.done / base) * 100)) : 0;
  const upd = (p: Partial<StudyItem>) => onChange({ ...s, ...p });
  const incomplete = rem === null || s.minutes === null;

  return (
    <details className="group rounded-2xl border border-line bg-white" open={s.kind === 'mandatory'}>
      <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 px-4 py-3.5">
        <span className="flex flex-wrap items-center gap-2">
          <span className="text-[17px] font-bold text-ink">{s.name}</span>
          <PriorityBadge p={s.priority} />
        </span>
        <span className="text-[15px] text-muted">
          {rem === null ? 'العدد غير معروف' : `المتبقي: ${rem} محاضرة`}
          {hrs !== null && ` • ≈ ${fmt(hrs)} ساعة`}
        </span>
      </summary>
      <div className="space-y-4 border-t border-line p-4">
        {base ? (
          <div>
            <div className="h-2.5 overflow-hidden rounded-full bg-paper">
              <div className="h-full bg-brand" style={{ width: `${pct}%` }} />
            </div>
            <div className="mt-1 text-sm text-muted">أُنجز {s.done} من {base} ({pct}%)</div>
          </div>
        ) : null}

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="الاسم">
            <input value={s.name} onChange={(e) => upd({ name: e.target.value })} className={inputCls} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="النوع">
              <Select value={s.kind} onChange={(v) => upd({ kind: v })} options={KIND} className="w-full" />
            </Field>
            <Field label="الأولوية">
              <Select<Priority> value={s.priority} onChange={(v) => upd({ priority: v })} options={PRIORITY_OPTIONS} className="w-full" />
            </Field>
          </div>
          <Field label="إجمالي المحاضرات" hint="اتركه فارغًا إن كنت لا تعرفه">
            <NullNum value={s.total} onChange={(v) => upd({ total: v })} />
          </Field>
          <Field label="المحاضرات المتراكمة" hint="التي فاتتك ولم تذاكرها">
            <NullNum value={s.backlog} onChange={(v) => upd({ backlog: v })} />
          </Field>
          <Field label="ما أنجزتُه من المتراكم">
            <NumInput value={s.done} min={0} max={9999} onChange={(v) => upd({ done: v })} className="!w-full" />
          </Field>
          <Field label="مدة المحاضرة (دقيقة)" hint="اتركها فارغة إن لم تعرفها">
            <NullNum value={s.minutes} onChange={(v) => upd({ minutes: v })} />
          </Field>
          <Field label="ما تحتاجه">
            <Select value={String(s.factor)} onChange={(v) => upd({ factor: parseFloat(v) })} options={FACTOR} className="w-full" />
          </Field>
          <Field label="الحالة">
            <Select value={s.status} onChange={(v) => upd({ status: v })} options={STATUS} className="w-full" />
          </Field>
          <Field label="الموعد النهائي">
            <input type="date" value={s.deadline} onChange={(e) => upd({ deadline: e.target.value })} className={inputCls} />
          </Field>
          <Field label="موعد المراجعة">
            <input type="date" value={s.review} onChange={(e) => upd({ review: e.target.value })} className={inputCls} />
          </Field>
        </div>

        <Field label="الخطوة اللازمة لمعرفة البيانات الناقصة">
          <textarea value={s.missing} onChange={(e) => upd({ missing: e.target.value })} rows={2} className={inputCls} />
        </Field>

        {incomplete && s.kind !== 'optional' && <Notice tone="warn">بيانات ناقصة: لن يُحسب الوقت المطلوب بدقة قبل معرفة العدد والمدة. لا تخمّنهما.</Notice>}

        <div className="flex gap-2">
          <Btn variant="soft" onClick={() => upd({ done: Math.min(rem === null ? s.done + 1 : s.done + 1, 99999) })}>
            + أنجزتُ محاضرة
          </Btn>
          <Btn variant="danger" onClick={onDelete}>
            حذف
          </Btn>
        </div>
      </div>
    </details>
  );
}

export function Study() {
  const { state, set } = useStore();
  const items = state.study;
  const setItems = (f: (i: StudyItem[]) => StudyItem[]) => set((s) => ({ ...s, study: f(s.study) }));
  const upd = (n: StudyItem) => setItems((is) => is.map((x) => (x.id === n.id ? n : x)));

  const committed = items.filter((i) => i.kind !== 'optional');
  const knownHours = committed.reduce((s, i) => s + (studyHours(i) ?? 0), 0);
  const knownLectures = committed.reduce((s, i) => s + (studyRemaining(i) ?? 0), 0);
  const missingCount = committed.filter((i) => studyRemaining(i) === null || i.minutes === null).length;
  const weeks = state.studyWeekly > 0 ? knownHours / state.studyWeekly : 0;

  const add = (kind: StudyKind) =>
    setItems((is) => [
      ...is,
      { id: uid(), name: 'عنصر جديد', kind, priority: kind === 'optional' ? 'later' : 'important', total: null, backlog: null, done: 0, minutes: null, factor: 1, status: 'notstarted', deadline: '', review: '', missing: '' },
    ]);

  const group = (kind: StudyKind) => items.filter((i) => i.kind === kind);

  return (
    <div className="space-y-5">
      <Card>
        <H2 sub="هنا يُفصل الإلزامي والمتأخر عن الطموح. ما لا تعرف رقمه اتركه فارغًا؛ سيظهر كـ«ناقص» ولن يُخترع له رقم.">لوحة التراكم الدراسي</H2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="محاضرات متراكمة معروفة" value={knownLectures} sub="في الإلزامي والبرامج" />
          <Stat label="ساعات معروفة للتعويض" value={`${fmt(knownHours)} س`} sub="تتحدث مع إدخال المدة" />
          <Stat label="عناصر ببيانات ناقصة" value={missingCount} tone={missingCount ? 'warn' : 'good'} sub="تحتاج حصرًا" />
          <Stat label="مدة التعويض المتوقعة" value={weeks ? `${fmt(weeks)} أسبوع` : '—'} sub="للمعروف فقط" />
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 text-[15px] text-ink">
            ساعات التعويض الأسبوعية المتاحة:
            <NumInput value={state.studyWeekly} min={1} max={60} onChange={(v) => set((s) => ({ ...s, studyWeekly: v }))} />
            ساعة
          </label>
        </div>
        <div className="mt-4">
          <Notice tone="info">
            الترتيب المقترح: <b>1) الكلية أولًا</b> (لها مواعيد ونتائج)، <b>2) حصر البرامج</b> (زاد/أوزون/ماكنزي/2B) دون مشاهدة جديدة هذا الأسبوع، <b>3) التعلم الاختياري مؤجل</b> حتى تتحقق بوابة «متى أضيف مسارًا جديدًا» في تبويب الخطة.
          </Notice>
        </div>
      </Card>

      <div>
        <h3 className="mb-2 text-lg font-bold text-ink">إلزامي ومتأخر</h3>
        <div className="space-y-2.5">
          {group('mandatory').map((s) => (
            <Item key={s.id} s={s} onChange={upd} onDelete={() => setItems((is) => is.filter((x) => x.id !== s.id))} />
          ))}
          <Btn variant="ghost" onClick={() => add('mandatory')}>+ إضافة مادة/التزام إلزامي</Btn>
        </div>
      </div>

      <div>
        <h3 className="mb-2 text-lg font-bold text-ink">برامج مسجَّل فيها (تحتاج حصرًا)</h3>
        <div className="space-y-2.5">
          {group('program').map((s) => (
            <Item key={s.id} s={s} onChange={upd} onDelete={() => setItems((is) => is.filter((x) => x.id !== s.id))} />
          ))}
          <Btn variant="ghost" onClick={() => add('program')}>+ إضافة برنامج</Btn>
        </div>
      </div>

      <div>
        <h3 className="mb-2 text-lg font-bold text-ink">تعلّم اختياري مؤجل</h3>
        <div className="space-y-2.5">
          {group('optional').map((s) => (
            <Item key={s.id} s={s} onChange={upd} onDelete={() => setItems((is) => is.filter((x) => x.id !== s.id))} />
          ))}
          <Btn variant="ghost" onClick={() => add('optional')}>+ إضافة مسار اختياري</Btn>
        </div>
      </div>
    </div>
  );
}
