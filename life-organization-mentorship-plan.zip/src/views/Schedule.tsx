import { useState } from 'react';
import type { Block } from '../types';
import { useStore } from '../lib/store';
import { CAT_OPTIONS, CATEGORIES, DAYS, PRIORITY_OPTIONS, catMap } from '../lib/constants';
import { analyzeBlocks, blockHours, scheduleByCat, totalsOf } from '../lib/calc';
import { dayIndexToday, fmt, toMin, toTime, uid } from '../lib/util';
import { seedBlocks } from '../lib/seed';
import { Btn, Card, H2, Notice, Select, inputCls } from '../components/ui';

export function Schedule() {
  const { state, set } = useStore();
  const [day, setDay] = useState(dayIndexToday());
  const blocks = state.blocks;
  const an = analyzeBlocks(blocks);
  const list = blocks.filter((b) => b.day === day).sort((a, b) => toMin(a.start) - toMin(b.start));

  const setBlocks = (f: (b: Block[]) => Block[]) => set((s) => ({ ...s, blocks: f(s.blocks) }));
  const upd = (id: string, patch: Partial<Block>) => setBlocks((bs) => bs.map((b) => (b.id === id ? { ...b, ...patch } : b)));

  const addBlock = () => {
    const last = list.filter((b) => !an.invalid.has(b.id)).slice(-1)[0];
    const start = last ? toMin(last.end) : 9 * 60;
    const end = Math.min(1439, start + 60);
    setBlocks((bs) => [...bs, { id: uid(), day, start: toTime(Math.min(start, 1380)), end: toTime(Math.max(end, Math.min(start, 1380) + 30)), title: 'فترة جديدة', cat: 'study', priority: 'important', deep: false }]);
  };

  const dayHours = (d: number) => blocks.filter((b) => b.day === d).reduce((s, b) => s + blockHours(b), 0);
  const dayDeep = (d: number) => blocks.filter((b) => b.day === d && b.deep).reduce((s, b) => s + blockHours(b), 0);
  const weekDeep = blocks.filter((b) => b.deep).reduce((s, b) => s + blockHours(b), 0);
  const scheduled = scheduleByCat(blocks);
  const budget = totalsOf(state.activities.plan).byCat;
  const dayConf = an.pairs.filter((p) => p.a.day === day);
  const dayInvalid = list.filter((b) => an.invalid.has(b.id));

  return (
    <div className="space-y-5">
      <Card>
        <H2 sub="كل يوم مختلف في الاستيقاظ والدراسة والمهام. الجدول المبدئي مبني على افتراضات واضحة (يوم الحضور الأحد، الأونلاين الثلاثاء، أوقات الصلاة تقريبية) فعدّلها لتطابق واقعك.">
          الجدول اليومي
        </H2>
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="أيام الأسبوع">
          {DAYS.map((d, i) => {
            const bad = an.pairs.some((p) => p.a.day === i);
            return (
              <button
                key={d}
                role="tab"
                aria-selected={day === i}
                onClick={() => setDay(i)}
                className={`relative rounded-xl border px-4 py-2 text-[15px] font-semibold transition ${day === i ? 'border-brand bg-brand text-white' : 'border-line bg-white text-ink hover:bg-paper'}`}
              >
                {d}
                {bad && <span className="absolute -top-1 -end-1 h-3 w-3 rounded-full bg-bad" title="يوجد تعارض" />}
              </button>
            );
          })}
        </div>

        <div className="mt-4" dir="ltr">
          <div className="relative h-8 w-full overflow-hidden rounded-lg bg-paper ring-1 ring-line">
            {list.map((b) => {
              if (an.invalid.has(b.id)) return null;
              const l = (toMin(b.start) / 1440) * 100;
              const w = ((toMin(b.end) - toMin(b.start)) / 1440) * 100;
              return (
                <div
                  key={b.id}
                  title={`${b.title} (${b.start}–${b.end})`}
                  className={`absolute top-0 h-full ${an.bad.has(b.id) ? 'opacity-70 ring-2 ring-inset ring-bad' : ''}`}
                  style={{ left: `${l}%`, width: `${w}%`, background: catMap[b.cat].color }}
                />
              );
            })}
          </div>
          <div className="mt-1 flex justify-between text-xs text-muted">
            {['00', '04', '08', '12', '16', '20', '24'].map((h) => (
              <span key={h}>{h}</span>
            ))}
          </div>
        </div>

        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-[15px] text-ink">
          <span>مجدول: <b>{fmt(dayHours(day))}</b> س</span>
          <span>غير مجدول: <b>{fmt(Math.max(0, 24 - dayHours(day)))}</b> س</span>
          <span>تركيز عميق: <b>{fmt(dayDeep(day))}</b> س</span>
        </div>

        <div className="mt-3 space-y-2">
          {dayConf.map((p, i) => (
            <Notice key={i} tone="bad">
              تعارض: «{p.a.title}» ({p.a.start}–{p.a.end}) يتداخل مع «{p.b.title}» ({p.b.start}–{p.b.end})
            </Notice>
          ))}
          {dayInvalid.map((b) => (
            <Notice key={b.id} tone="bad">
              وقت النهاية يجب أن يكون بعد البداية في «{b.title}». (للنوم الذي يعبر منتصف الليل، قسّمه إلى فترتين.)
            </Notice>
          ))}
        </div>
      </Card>

      <div className="space-y-2.5">
        {list.map((b) => (
          <div key={b.id} className={`rounded-2xl border bg-white p-3 ${an.bad.has(b.id) || an.invalid.has(b.id) ? 'border-bad' : 'border-line'}`}>
            <div className="grid gap-2 sm:grid-cols-[auto_auto_1fr]">
              <input type="time" value={b.start} onChange={(e) => upd(b.id, { start: e.target.value })} className={`${inputCls} !w-32`} aria-label="البداية" />
              <input type="time" value={b.end} onChange={(e) => upd(b.id, { end: e.target.value })} className={`${inputCls} !w-32`} aria-label="النهاية" />
              <input value={b.title} onChange={(e) => upd(b.id, { title: e.target.value })} className={inputCls} aria-label="الوصف" />
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Select value={b.cat} onChange={(v) => upd(b.id, { cat: v })} options={CAT_OPTIONS} label="القسم" />
              <Select value={b.priority} onChange={(v) => upd(b.id, { priority: v })} options={PRIORITY_OPTIONS} label="الأولوية" />
              <label className="flex cursor-pointer items-center gap-2 text-[15px]">
                <input type="checkbox" checked={b.deep} onChange={(e) => upd(b.id, { deep: e.target.checked })} className="h-5 w-5 accent-[#1f6a67]" />
                تركيز عميق
              </label>
              <span className="text-sm text-muted">{fmt(blockHours(b))} س</span>
              <button type="button" onClick={() => setBlocks((bs) => bs.filter((x) => x.id !== b.id))} className="ms-auto rounded-lg px-3 py-1.5 text-sm text-bad hover:bg-bad-soft">
                حذف
              </button>
            </div>
          </div>
        ))}
        <div className="flex flex-wrap gap-2">
          <Btn onClick={addBlock}>+ إضافة فترة في {DAYS[day]}</Btn>
          <Btn variant="danger" onClick={() => window.confirm(`مسح كل فترات ${DAYS[day]}؟`) && setBlocks((bs) => bs.filter((b) => b.day !== day))}>
            مسح هذا اليوم
          </Btn>
          <Btn variant="ghost" onClick={() => window.confirm('استبدال كل الجدول بالجدول المقترح للأسبوع الأول؟') && setBlocks(() => seedBlocks())}>
            استعادة جدول الأسبوع الأول المقترح
          </Btn>
        </div>
      </div>

      <Card>
        <H2 sub="لمحة عن الأسبوع كله. التركيز العميق المجدول يجب أن يقارب هدف الأسبوع.">ملخص الأسبوع</H2>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[28rem] text-[15px]">
            <thead>
              <tr className="border-b border-line text-start text-muted">
                <th className="py-2 text-start font-semibold">اليوم</th>
                <th className="py-2 text-start font-semibold">مجدول</th>
                <th className="py-2 text-start font-semibold">غير مجدول</th>
                <th className="py-2 text-start font-semibold">تركيز عميق</th>
              </tr>
            </thead>
            <tbody>
              {DAYS.map((d, i) => (
                <tr key={d} className="border-b border-line/60">
                  <td className="py-2 font-semibold">{d}</td>
                  <td className="py-2">{fmt(dayHours(i))} س</td>
                  <td className="py-2">{fmt(Math.max(0, 24 - dayHours(i)))} س</td>
                  <td className="py-2">{fmt(dayDeep(i))} س</td>
                </tr>
              ))}
              <tr className="font-bold">
                <td className="py-2">الأسبوع</td>
                <td className="py-2">{fmt(blocks.reduce((s, b) => s + blockHours(b), 0))} س</td>
                <td className="py-2">—</td>
                <td className="py-2">{fmt(weekDeep)} س</td>
              </tr>
            </tbody>
          </table>
        </div>
        {an.pairs.length > 0 && (
          <div className="mt-3">
            <Notice tone="bad">يوجد {an.pairs.length} تعارض في الأسبوع. الأيام التي بها تعارض عليها نقطة حمراء.</Notice>
          </div>
        )}
      </Card>

      <Card>
        <H2 sub="مقارنة ما وضعتَه في «ميزانية خطة الأسبوع» بما جدولتَه فعليًا. الفروق الصغيرة طبيعية، والكبيرة تعني أن أحدهما يحتاج تعديلًا.">الميزانية مقابل الجدول</H2>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[28rem] text-[15px]">
            <thead>
              <tr className="border-b border-line text-muted">
                <th className="py-2 text-start font-semibold">القسم</th>
                <th className="py-2 text-start font-semibold">الميزانية</th>
                <th className="py-2 text-start font-semibold">الجدول</th>
                <th className="py-2 text-start font-semibold">الفرق</th>
              </tr>
            </thead>
            <tbody>
              {CATEGORIES.filter((c) => budget[c.id] > 0 || scheduled[c.id] > 0).map((c) => {
                const diff = scheduled[c.id] - budget[c.id];
                return (
                  <tr key={c.id} className="border-b border-line/60">
                    <td className="py-2">
                      <span className="me-2 inline-block h-3 w-3 rounded-sm align-middle" style={{ background: c.color }} />
                      {c.short}
                    </td>
                    <td className="py-2">{fmt(budget[c.id])} س</td>
                    <td className="py-2">{fmt(scheduled[c.id])} س</td>
                    <td className={`py-2 font-semibold ${Math.abs(diff) > 3 ? 'text-bad' : 'text-muted'}`}>{diff > 0 ? '+' : ''}{fmt(diff)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
