import { useState } from 'react';
import type { Activity, Pattern, Scenario } from '../types';
import { useStore } from '../lib/store';
import { CATEGORIES, DEEPABLE, PRIORITY_OPTIONS, catMap } from '../lib/constants';
import { WEEK_HOURS, actDays, actHours, focusEstimate, sleepStats, totalsOf } from '../lib/calc';
import { fmt, uid } from '../lib/util';
import { Btn, Card, H2, NumInput, Notice, Select, Stat, inputCls } from '../components/ui';
import { QuickEntry } from '../components/QuickEntry';

function PatternRow({
  p,
  maxDays,
  canDelete,
  onChange,
  onDelete,
}: {
  p: Pattern;
  maxDays: number;
  canDelete: boolean;
  onChange: (patch: Partial<Pattern>) => void;
  onDelete: () => void;
}) {
  return (
    <div className="grid items-end gap-3 rounded-xl bg-paper p-3 sm:grid-cols-[1fr_1fr_auto]">
      <div>
        <div className="mb-1 text-sm text-muted">ساعات في اليوم</div>
        <div className="flex items-center gap-2">
          <input type="range" min={0} max={24} step={0.5} value={p.hours} onChange={(e) => onChange({ hours: parseFloat(e.target.value) })} className="w-full accent-[#1f6a67]" aria-label="ساعات في اليوم (منزلق)" />
          <NumInput value={p.hours} min={0} max={24} step={0.5} onChange={(v) => onChange({ hours: v })} label="ساعات في اليوم" />
        </div>
      </div>
      <div>
        <div className="mb-1 text-sm text-muted">عدد الأيام (حتى {maxDays})</div>
        <div className="flex items-center gap-2">
          <input type="range" min={1} max={Math.max(1, maxDays)} step={1} value={Math.min(p.days, Math.max(1, maxDays))} onChange={(e) => onChange({ days: parseInt(e.target.value) })} className="w-full accent-[#1f6a67]" aria-label="عدد الأيام (منزلق)" />
          <NumInput value={p.days} min={1} max={Math.max(1, maxDays)} onChange={(v) => onChange({ days: v })} label="عدد الأيام" />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3 sm:justify-end">
        <span className="text-[15px] text-ink">
          = <b className="text-lg">{fmt(p.hours * p.days)}</b> س
        </span>
        {canDelete && (
          <button type="button" onClick={onDelete} className="rounded-lg px-2 py-1 text-sm text-bad hover:bg-bad-soft" aria-label="حذف النمط">
            حذف
          </button>
        )}
      </div>
    </div>
  );
}

function ActivityRow({ a, onChange, onDelete }: { a: Activity; onChange: (a: Activity) => void; onDelete: () => void }) {
  const days = actDays(a);
  const upd = (patch: Partial<Activity>) => onChange({ ...a, ...patch });
  const updP = (id: string, patch: Partial<Pattern>) => upd({ patterns: a.patterns.map((p) => (p.id === id ? { ...p, ...patch } : p)) });

  return (
    <div className="rounded-2xl border border-line bg-white p-3.5">
      <div className="flex flex-wrap items-center gap-2">
        <input value={a.name} onChange={(e) => upd({ name: e.target.value })} className={`${inputCls} min-w-[10rem] flex-1 font-semibold`} aria-label="اسم النشاط" />
        <Select value={a.priority} onChange={(v) => upd({ priority: v })} options={PRIORITY_OPTIONS} label="الأولوية" />
        <Btn variant="danger" onClick={onDelete} className="!px-3">
          حذف
        </Btn>
      </div>

      {DEEPABLE.includes(a.cat) && (
        <label className="mt-2 flex cursor-pointer items-center gap-2 text-[15px] text-ink">
          <input type="checkbox" checked={a.deep} onChange={(e) => upd({ deep: e.target.checked })} className="h-5 w-5 accent-[#1f6a67]" />
          يُحسب ضمن التركيز العميق الذاتي (وليس محاضرة أو دوامًا مفروضًا)
        </label>
      )}

      <div className="mt-3 space-y-2.5">
        {a.patterns.map((p) => (
          <PatternRow
            key={p.id}
            p={p}
            maxDays={7 - (days - p.days)}
            canDelete={a.patterns.length > 1}
            onChange={(patch) => updP(p.id, patch)}
            onDelete={() => upd({ patterns: a.patterns.filter((x) => x.id !== p.id) })}
          />
        ))}
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[15px]">
        <div className="flex flex-wrap items-center gap-3">
          <Btn
            variant="soft"
            disabled={days >= 7}
            title={days >= 7 ? 'اكتملت الأيام السبعة لهذا النشاط' : ''}
            onClick={() => upd({ patterns: [...a.patterns, { id: uid(), hours: 1, days: 1 }] })}
          >
            + نمط آخر لنفس النشاط
          </Btn>
          <span className={days > 7 ? 'text-bad' : 'text-muted'}>
            الأيام الموزعة: <b>{days}</b> / 7
          </span>
        </div>
        <span className="font-semibold text-ink">المجموع: {fmt(actHours(a))} ساعة / أسبوع</span>
      </div>
      {a.note && <p className="mt-2 text-sm leading-6 text-muted">ملاحظة: {a.note}</p>}
    </div>
  );
}

export function Budget() {
  const { state, set } = useStore();
  const sc = state.scenario;
  const acts = state.activities[sc];
  const setActs = (next: Activity[]) => set((s) => ({ ...s, activities: { ...s.activities, [sc]: next } }));
  const setScenario = (v: Scenario) => set((s) => ({ ...s, scenario: v }));
  const [open, setOpen] = useState<Record<string, boolean>>({});

  const t = totalsOf(acts);
  const fe = focusEstimate(acts, state.focusFactor);
  const ss = sleepStats(acts);
  const over = t.allocated > WEEK_HOURS;
  const denom = Math.max(WEEK_HOURS, t.allocated);

  const addActivity = (cat: Activity['cat']) => {
    setActs([
      ...acts,
      { id: uid(), name: 'نشاط جديد', cat, priority: 'important', deep: false, patterns: [{ id: uid(), hours: 1, days: 1 }] },
    ]);
    setOpen((o) => ({ ...o, [cat]: true }));
  };

  return (
    <div className="space-y-5">
      <Card>
        <H2 sub="كل نشاط يمكن أن يكون له أكثر من نمط (مثلًا: النوم 6 ساعات في 3 أيام و10 ساعات في يومين). الموقع يجمع كل شيء ويقارنه بـ 168 ساعة.">
          ميزانية الأسبوع (168 ساعة)
        </H2>
        <div className="inline-flex rounded-xl border border-line bg-paper p-1" role="tablist" aria-label="اختيار السيناريو">
          {([
            ['plan', 'خطة الأسبوع الأول'],
            ['current', 'الواقع الحالي (تقدير)'],
          ] as [Scenario, string][]).map(([k, l]) => (
            <button
              key={k}
              role="tab"
              aria-selected={sc === k}
              onClick={() => setScenario(k)}
              className={`rounded-lg px-4 py-2 text-[15px] font-semibold transition ${sc === k ? 'bg-brand text-white' : 'text-ink hover:bg-white'}`}
            >
              {l}
            </button>
          ))}
        </div>
        {sc === 'current' && (
          <div className="mt-3">
            <Notice tone="warn">
              هذا تقدير أولي مما وصفتَه، وليس قياسًا. كل ما لم تذكره تُرك فارغًا عمدًا كي لا أخترع أرقامًا. سجّل 3 أيام فعلية في «المتابعة اليومية» ثم عدّل هنا.
            </Notice>
          </div>
        )}
      </Card>

      <QuickEntry acts={acts} onApply={setActs} />

      <Card>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="الموزَّع" value={`${fmt(t.allocated)} / 168`} tone={over ? 'bad' : 'default'} />
          <Stat
            label={over ? 'تجاوز الإجمالي' : 'غير موزَّع'}
            value={`${fmt(Math.abs(t.unallocated))} ساعة`}
            tone={over ? 'bad' : 'warn'}
            sub={over ? 'قلّل ساعات نشاط ما' : 'ليست كلها وقت تركيز'}
          />
          <Stat label="متوسط النوم" value={ss.nights ? `${fmt(ss.avg)} س` : '—'} sub={ss.nights ? `من ${fmt(ss.min)} إلى ${fmt(ss.max)} (فرق ${fmt(ss.range)})` : 'لم يُدخل'} />
          <Stat label="تركيز عميق مخطط" value={`${fmt(fe.plannedDeep)} س`} sub={`سقفك الواقعي ≈ ${fmt(fe.ceiling)} س`} tone={fe.plannedDeep > fe.ceiling ? 'bad' : 'good'} />
        </div>

        <div className="mt-4 flex h-5 w-full overflow-hidden rounded-full bg-paper ring-1 ring-line" aria-hidden>
          {CATEGORIES.map((c) => {
            const h = t.byCat[c.id];
            return h > 0 ? <div key={c.id} style={{ width: `${(h / denom) * 100}%`, background: c.color }} title={`${c.short}: ${fmt(h)} س`} /> : null;
          })}
          {!over && t.unallocated > 0 && <div style={{ width: `${(t.unallocated / denom) * 100}%` }} />}
        </div>
        <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-sm">
          {CATEGORIES.filter((c) => t.byCat[c.id] > 0).map((c) => (
            <span key={c.id} className="inline-flex items-center gap-1.5 text-ink">
              <span className="h-3 w-3 rounded-sm" style={{ background: c.color }} />
              {c.short} <b>{fmt(t.byCat[c.id])}</b>
            </span>
          ))}
        </div>

        <div className="mt-4 space-y-2">
          {over && <Notice tone="bad">مجموع ما وزّعته يتجاوز 168 ساعة بمقدار {fmt(t.allocated - WEEK_HOURS)} ساعة. لا يمكن تنفيذ ذلك فعليًا.</Notice>}
          {!over && t.unallocated > 0 && (
            <Notice tone="warn">
              لديك {fmt(t.unallocated)} ساعة غير موزعة. لا تعدّها ساعات عمل عميق: جزء منها راحة وانتقال ومهام غير متوقعة وتعب.
            </Notice>
          )}
          {!over && t.unallocated === 0 && <Notice tone="good">الميزانية مطابقة تمامًا لـ 168 ساعة.</Notice>}
          {ss.nights > 0 && ss.nights < 7 && <Notice tone="warn">نومك موزع على {ss.nights} من 7 ليالٍ فقط؛ أضف النمط الناقص ليكتمل الحساب.</Notice>}
          {ss.range >= 6 && <Notice tone="info">فرق النوم بين أقصر وأطول ليلة {fmt(ss.range)} ساعة. الهدف في الأسابيع القادمة تقليل هذا الفرق خطوة بخطوة، لا الوصول لرقم مثالي دفعة واحدة.</Notice>}
        </div>
      </Card>

      <Card>
        <H2 sub="الساعات المتاحة نظريًا ليست ساعات تركيز. هذه الأرقام تقدير قابل للتعديل بالمنزلق.">الفرق بين المتاح نظريًا وما يمكن استغلاله بتركيز</H2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Stat label="متاح نظريًا بعد الأساسيات والمفروض" value={`${fmt(fe.base)} س`} sub="168 − (نوم، أكل، عناية، عبادة، تنقل، أسرة، حركة، احتياطي، محاضرات ودوام ثابت)" />
          <Stat label="السقف الواقعي للتركيز العميق" value={`${fmt(fe.ceiling)} س`} sub={`المتاح × ${Math.round(state.focusFactor * 100)}%`} />
          <Stat label="هدف البداية المقترح" value={`${fmt(fe.startTarget)} س`} sub="≈ 65% من السقف، ثم نزيد عند الالتزام" tone="good" />
        </div>
        <div className="mt-4">
          <label className="block text-[15px] text-ink">
            نسبة الساعات التي أستطيع تحويلها لتركيز فعلي: <b>{Math.round(state.focusFactor * 100)}%</b>
            <input
              type="range"
              min={0.15}
              max={0.5}
              step={0.05}
              value={state.focusFactor}
              onChange={(e) => set((s) => ({ ...s, focusFactor: parseFloat(e.target.value) }))}
              className="mt-2 w-full accent-[#1f6a67]"
            />
          </label>
        </div>
        {fe.ceiling < 20 && (
          <div className="mt-3">
            <Notice tone="warn">
              هدف الـ 20 ساعة أعلى من سقفك الواقعي الحالي ({fmt(fe.ceiling)} س). ابدأ بنحو {fmt(fe.startTarget)} س، وارفع بنسبة 10–15% فقط بعد أسبوعين تحقق فيهما 80% من الهدف.
            </Notice>
          </div>
        )}
      </Card>

      <div className="space-y-3">
        {CATEGORIES.map((c) => {
          const list = acts.filter((a) => a.cat === c.id);
          const hrs = t.byCat[c.id];
          const isOpen = open[c.id] ?? list.length > 0;
          return (
            <section key={c.id} className="overflow-hidden rounded-2xl border border-line bg-card">
              <button
                type="button"
                onClick={() => setOpen((o) => ({ ...o, [c.id]: !isOpen }))}
                aria-expanded={isOpen}
                className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-start hover:bg-paper"
              >
                <span className="flex items-center gap-3">
                  <span className="h-4 w-4 rounded-md" style={{ background: c.color }} />
                  <span>
                    <span className="block text-[17px] font-bold text-ink">{c.label}</span>
                    <span className="block text-sm text-muted">{c.hint}</span>
                  </span>
                </span>
                <span className="shrink-0 text-end">
                  <span className="block text-lg font-bold text-ink">{fmt(hrs)} س</span>
                  <span className="block text-sm text-muted">{isOpen ? '▲ إخفاء' : '▼ تفاصيل'}</span>
                </span>
              </button>
              {isOpen && (
                <div className="space-y-3 border-t border-line p-3.5">
                  {list.length === 0 && <p className="text-[15px] text-muted">لا أنشطة في هذا القسم بعد.</p>}
                  {list.map((a) => (
                    <ActivityRow
                      key={a.id}
                      a={a}
                      onChange={(n) => setActs(acts.map((x) => (x.id === a.id ? n : x)))}
                      onDelete={() => setActs(acts.filter((x) => x.id !== a.id))}
                    />
                  ))}
                  <Btn variant="ghost" onClick={() => addActivity(c.id)}>
                    + إضافة نشاط في «{catMap[c.id].short}»
                  </Btn>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
