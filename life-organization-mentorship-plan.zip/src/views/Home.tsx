import { useState } from 'react';
import type { Tab } from '../types';
import { useStore } from '../lib/store';
import { CATEGORIES, DAYS } from '../lib/constants';
import { WEEK_HOURS, focusEstimate, sleepStats, studyRemaining, totalsOf } from '../lib/calc';
import { dayIndexToday, fmt, toMin, todayStr, uid } from '../lib/util';
import { Btn, Card, H2, Notice, Stat, inputCls } from '../components/ui';

export function Home({ go }: { go: (t: Tab) => void }) {
  const { state, set } = useStore();
  const [idea, setIdea] = useState('');
  const plan = state.activities.plan;
  const cur = state.activities.current;
  const tp = totalsOf(plan);
  const tc = totalsOf(cur);
  const fe = focusEstimate(plan, state.focusFactor);
  const ss = sleepStats(plan);

  const today = dayIndexToday();
  const blocks = state.blocks.filter((b) => b.day === today).sort((a, b) => toMin(a.start) - toMin(b.start));
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const current = blocks.find((b) => toMin(b.start) <= nowMin && nowMin < toMin(b.end));
  const next = blocks.find((b) => toMin(b.start) > nowMin);

  const committed = state.study.filter((s) => s.kind !== 'optional');
  const knownLectures = committed.reduce((s, i) => s + (studyRemaining(i) ?? 0), 0);
  const missing = committed.filter((i) => studyRemaining(i) === null || i.minutes === null).length;
  const focusProject = state.projects.find((p) => p.decision === 'focus');
  const todayLog = state.logs.find((l) => l.date === todayStr());

  const addIdea = () => {
    const t = idea.trim();
    if (!t) return;
    set((s) => ({ ...s, ideas: [{ id: uid(), text: t, date: todayStr() }, ...s.ideas] }));
    setIdea('');
  };

  const rows = CATEGORIES.filter((c) => tp.byCat[c.id] > 0 || tc.byCat[c.id] > 0);
  const maxRow = Math.max(1, ...rows.map((c) => Math.max(tp.byCat[c.id], tc.byCat[c.id])));

  return (
    <div className="space-y-5">
      <Card className="!bg-brand !text-white !border-brand">
        <h2 className="text-2xl font-bold leading-9">ابدأ من هنا: وقتك حقيقي، وخطتك تبدأ من واقعك</h2>
        <p className="mt-2 text-[16px] leading-8 text-white/90">
          أسبوعك 168 ساعة. هذه الأداة تحسب أين تذهب ساعاتك فعليًا، وتبني جدولًا يتغير من يوم لآخر، وتحميك من فتح مشاريع كثيرة معًا. الأولوية الآن: الكلية، ثم استقرار النوم والجسم، ثم مشروع واحد فقط.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Btn variant="ghost" onClick={() => go('plan')}>اقرأ الخطة</Btn>
          <Btn variant="ghost" onClick={() => go('budget')}>عدّل ميزانيتك</Btn>
          <Btn variant="ghost" onClick={() => go('track')}>سجّل اليوم</Btn>
        </div>
      </Card>

      <Card>
        <H2 sub={`${DAYS[today]} — ما الذي أفعله الآن؟`}>الآن والتالي</H2>
        {blocks.length === 0 ? (
          <Notice tone="warn">لا فترات في جدول اليوم. أضفها من تبويب «الجدول».</Notice>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-brand/30 bg-brand-soft p-4">
              <div className="text-sm text-brand-dark">الآن</div>
              <div className="mt-1 text-lg font-bold text-ink">{current ? current.title : 'لا فترة مجدولة الآن'}</div>
              {current && <div className="text-sm text-muted">{current.start} – {current.end}</div>}
            </div>
            <div className="rounded-xl border border-line bg-white p-4">
              <div className="text-sm text-muted">التالي</div>
              <div className="mt-1 text-lg font-bold text-ink">{next ? next.title : 'لا فترات متبقية اليوم'}</div>
              {next && <div className="text-sm text-muted">{next.start} – {next.end}</div>}
            </div>
          </div>
        )}
        <div className="mt-3">
          {todayLog ? (
            <Notice tone="good">سجّلتَ اليوم بالفعل. أحسنت.</Notice>
          ) : (
            <Notice tone="info">لم تسجّل اليوم بعد: دقيقتان في «المتابعة اليومية».</Notice>
          )}
        </div>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="موزَّع في الخطة" value={`${fmt(tp.allocated)} / ${WEEK_HOURS}`} sub={`غير موزَّع ${fmt(tp.unallocated)} س`} tone={tp.allocated > WEEK_HOURS ? 'bad' : 'default'} />
        <Stat label="تركيز عميق مخطط" value={`${fmt(fe.plannedDeep)} س`} sub={`سقف واقعي ≈ ${fmt(fe.ceiling)} س`} tone={fe.plannedDeep > fe.ceiling ? 'bad' : 'good'} />
        <Stat label="متوسط النوم المخطط" value={ss.nights ? `${fmt(ss.avg)} س` : '—'} sub="ثبّت الاستيقاظ أولًا" />
        <Stat label="محاضرات متراكمة معروفة" value={knownLectures} sub={missing ? `${missing} عناصر ببيانات ناقصة` : 'كل البيانات معروفة'} tone={missing ? 'warn' : 'good'} />
      </div>

      <Card>
        <H2 sub="الواقع الحالي تقدير أولي لما ذكرتَه فقط، والباقي لم يُقَس بعد. الفارق بين الصفين هو ما تعمل عليه.">الواقع مقابل الخطة (ساعات/أسبوع)</H2>
        <div className="space-y-2.5">
          {rows.map((c) => (
            <div key={c.id}>
              <div className="mb-1 flex justify-between text-[15px]">
                <span className="font-semibold text-ink">{c.short}</span>
                <span className="text-muted">الحالي {fmt(tc.byCat[c.id])} • الخطة {fmt(tp.byCat[c.id])}</span>
              </div>
              <div className="space-y-1">
                <div className="h-2.5 overflow-hidden rounded-full bg-paper">
                  <div className="h-full rounded-full opacity-45" style={{ width: `${(tc.byCat[c.id] / maxRow) * 100}%`, background: c.color }} />
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-paper">
                  <div className="h-full rounded-full" style={{ width: `${(tp.byCat[c.id] / maxRow) * 100}%`, background: c.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">الشريط الباهت = الحالي، الغامق = الخطة.</p>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <H2>المشروع المحوري الآن</H2>
          {focusProject ? (
            <>
              <div className="text-lg font-bold text-ink">{focusProject.name}</div>
              <p className="mt-1 text-[15px] leading-7 text-muted">الخطوة التالية: {focusProject.next || 'لم تُحدَّد بعد'}</p>
            </>
          ) : (
            <Notice tone="warn">لم تختر مشروعًا محوريًا بعد.</Notice>
          )}
          <div className="mt-3">
            <Btn variant="soft" onClick={() => go('projects')}>افتح الجرد</Btn>
          </div>
        </Card>

        <Card>
          <H2 sub="لا تبدأها. سجّلها وارجع لمهمتك.">فكرة جديدة؟</H2>
          <div className="flex gap-2">
            <input value={idea} onChange={(e) => setIdea(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addIdea()} placeholder="سطر واحد…" className={inputCls} aria-label="فكرة جديدة" />
            <Btn onClick={addIdea}>سجّل</Btn>
          </div>
          <p className="mt-2 text-sm text-muted">في الانتظار: {state.ideas.length} فكرة</p>
        </Card>
      </div>
    </div>
  );
}
