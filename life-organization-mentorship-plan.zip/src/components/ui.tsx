import type { ReactNode } from 'react';
import { PRIORITIES } from '../lib/constants';
import type { Priority } from '../types';

export const inputCls =
  'w-full rounded-xl border border-line bg-white px-3 py-2 text-base text-ink placeholder:text-muted/70 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20';

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-line bg-card p-4 sm:p-5 ${className}`}>{children}</section>;
}

export function H2({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return (
    <div className="mb-3">
      <h2 className="text-xl font-bold leading-8 text-ink">{children}</h2>
      {sub && <p className="mt-1 text-[15px] leading-7 text-muted">{sub}</p>}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = 'primary',
  disabled,
  className = '',
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'soft' | 'ghost' | 'danger';
  disabled?: boolean;
  className?: string;
  title?: string;
}) {
  const v = {
    primary: 'bg-brand text-white hover:bg-brand-dark',
    soft: 'bg-brand-soft text-brand-dark hover:bg-[#cfe4e1]',
    ghost: 'border border-line bg-white text-ink hover:bg-paper',
    danger: 'border border-bad/30 bg-white text-bad hover:bg-bad-soft',
  }[variant];
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-[15px] font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 ${v} ${className}`}
    >
      {children}
    </button>
  );
}

export function Notice({ tone = 'info', children }: { tone?: 'info' | 'warn' | 'bad' | 'good'; children: ReactNode }) {
  const t = {
    info: 'bg-brand-soft text-brand-dark border-brand/20',
    warn: 'bg-warn-soft text-[#6b4210] border-warn/25',
    bad: 'bg-bad-soft text-[#7d2a22] border-bad/25',
    good: 'bg-good-soft text-[#2b5a3a] border-good/25',
  }[tone];
  return <div className={`rounded-xl border px-4 py-3 text-[15px] leading-7 ${t}`}>{children}</div>;
}

export function PriorityBadge({ p }: { p: Priority }) {
  return <span className={`rounded-full px-2.5 py-0.5 text-sm font-semibold ${PRIORITIES[p].cls}`}>{PRIORITIES[p].label}</span>;
}

export function Select<T extends string>({
  value,
  onChange,
  options,
  className = '',
  label,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
  className?: string;
  label?: string;
}) {
  return (
    <select
      aria-label={label}
      value={value}
      onChange={(e) => onChange(e.target.value as T)}
      className={`rounded-xl border border-line bg-white px-3 py-2 text-base text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20 ${className}`}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function NumInput({
  value,
  onChange,
  min = 0,
  max = 999,
  step = 1,
  className = '',
  label,
}: {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  className?: string;
  label?: string;
}) {
  return (
    <input
      type="number"
      inputMode="decimal"
      aria-label={label}
      value={Number.isFinite(value) ? value : ''}
      min={min}
      max={max}
      step={step}
      onChange={(e) => {
        const v = parseFloat(e.target.value);
        onChange(Number.isNaN(v) ? min : Math.min(max, Math.max(min, v)));
      }}
      className={`w-20 rounded-xl border border-line bg-white px-2 py-2 text-center text-base font-semibold text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20 ${className}`}
    />
  );
}

export function NullNum({
  value,
  onChange,
  placeholder = 'غير معروف',
  label,
}: {
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder?: string;
  label?: string;
}) {
  return (
    <input
      type="number"
      inputMode="numeric"
      aria-label={label}
      min={0}
      value={value ?? ''}
      placeholder={placeholder}
      onChange={(e) => {
        const raw = e.target.value;
        if (raw === '') return onChange(null);
        const v = parseFloat(raw);
        onChange(Number.isNaN(v) ? null : Math.max(0, v));
      }}
      className={inputCls}
    />
  );
}

export function Rate({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  return (
    <div role="group" aria-label={label} className="flex gap-1.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          aria-pressed={value === n}
          onClick={() => onChange(n)}
          className={`h-11 w-11 rounded-xl border text-base font-semibold transition ${
            value === n ? 'border-brand bg-brand text-white' : 'border-line bg-white text-ink hover:bg-paper'
          }`}
        >
          {n}
        </button>
      ))}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[15px] font-semibold text-ink">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-sm text-muted">{hint}</span>}
    </label>
  );
}

export function Stat({ label, value, sub, tone = 'default' }: { label: string; value: ReactNode; sub?: ReactNode; tone?: 'default' | 'warn' | 'bad' | 'good' }) {
  const c = { default: 'text-ink', warn: 'text-warn', bad: 'text-bad', good: 'text-good' }[tone];
  return (
    <div className="rounded-xl border border-line bg-white p-3.5">
      <div className="text-sm text-muted">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${c}`}>{value}</div>
      {sub && <div className="mt-0.5 text-sm text-muted">{sub}</div>}
    </div>
  );
}
