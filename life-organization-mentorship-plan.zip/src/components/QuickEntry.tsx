import { useRef, useState } from 'react';
import type { Activity } from '../types';
import { parseText } from '../lib/parser';
import type { Parsed } from '../lib/parser';
import { CAT_OPTIONS } from '../lib/constants';
import { actDays } from '../lib/calc';
import { uid } from '../lib/util';
import { Btn, Card, H2, NumInput, Notice, Select, inputCls } from './ui';

const EXAMPLE = 'أنام 6 ساعات في ثلاثة أيام، و10 ساعات في يومين، و14 ساعة في يومين، وأدرس في الكلية يومًا حضوريًا ويومًا أونلاين';

interface Props {
  acts: Activity[];
  onApply: (next: Activity[]) => void;
}

export function QuickEntry({ acts, onApply }: Props) {
  const [text, setText] = useState('');
  const [rows, setRows] = useState<Parsed[] | null>(null);
  const [msg, setMsg] = useState('');
  const [listening, setListening] = useState(false);
  const recRef = useRef<any>(null);

  const SR: any = typeof window !== 'undefined' ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition : null;

  const toggleMic = () => {
    if (!SR) return;
    if (listening && recRef.current) {
      recRef.current.stop();
      return;
    }
    const rec = new SR();
    rec.lang = 'ar-EG';
    rec.interimResults = false;
    rec.continuous = false;
    rec.onresult = (e: any) => {
      const t = Array.from(e.results as ArrayLike<any>)
        .map((r) => r[0].transcript)
        .join(' ');
      setText((prev) => (prev ? prev + '، ' : '') + t);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => {
      setListening(false);
      setMsg('تعذّر استخدام الميكروفون. اسمح للمتصفح بالوصول إليه أو اكتب النص يدويًا.');
    };
    recRef.current = rec;
    setListening(true);
    setMsg('');
    rec.start();
  };

  const analyze = () => {
    setMsg('');
    const r = parseText(text);
    setRows(r);
    if (!r.length) setMsg('لم أستخرج شيئًا. اكتب الساعات والأيام صراحة، مثل: «أنام 7 ساعات في 5 أيام».');
  };

  const upd = (id: string, patch: Partial<Parsed>) => setRows((rs) => (rs ? rs.map((r) => (r.id === id ? { ...r, ...patch } : r)) : rs));

  const apply = () => {
    if (!rows) return;
    let next = acts.map((a) => ({ ...a, patterns: a.patterns.map((p) => ({ ...p })) }));
    let added = 0;
    const skipped: string[] = [];
    rows
      .filter((r) => r.include)
      .forEach((r) => {
        if (r.hours <= 0) {
          skipped.push(`«${r.name}»: الساعات صفر`);
          return;
        }
        const existing = next.find((a) => a.cat === r.cat && a.name === r.name);
        if (existing) {
          const room = 7 - actDays(existing);
          if (room <= 0) {
            skipped.push(`«${r.name}»: أيامه مكتملة (7/7)`);
            return;
          }
          existing.patterns.push({ id: uid(), hours: r.hours, days: Math.min(r.days, room) });
        } else {
          next = [
            ...next,
            {
              id: uid(),
              name: r.name,
              cat: r.cat,
              priority: 'important',
              deep: false,
              patterns: [{ id: uid(), hours: r.hours, days: r.days }],
            },
          ];
        }
        added++;
      });
    onApply(next);
    setRows(null);
    setText('');
    setMsg(`تمت إضافة ${added} نمط.${skipped.length ? ' تم تخطي: ' + skipped.join('، ') : ''}`);
  };

  return (
    <Card>
      <H2 sub="اكتب وصفك بلغتك أو تكلّم. يحلّل الموقع النص محليًا على جهازك (قواعد بسيطة بلا ذكاء اصطناعي خارجي)، ثم يعرض لك ما فهمه لتؤكده أو تصحّحه قبل أي حساب.">
        إدخال سريع بالكتابة أو الصوت
      </H2>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={3}
        placeholder={EXAMPLE}
        className={inputCls}
        aria-label="وصف الوقت بلغة طبيعية"
      />
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Btn onClick={analyze} disabled={!text.trim()}>
          حلّل النص
        </Btn>
        <Btn variant="ghost" onClick={() => setText(EXAMPLE)}>
          جرّب مثالًا
        </Btn>
        {SR ? (
          <Btn variant={listening ? 'danger' : 'soft'} onClick={toggleMic}>
            {listening ? '■ إيقاف الاستماع' : '🎙 تحدّث'}
          </Btn>
        ) : (
          <span className="text-sm text-muted">متصفحك لا يدعم الإدخال الصوتي، اكتب النص يدويًا.</span>
        )}
      </div>
      {msg && (
        <div className="mt-3">
          <Notice tone="info">{msg}</Notice>
        </div>
      )}

      {rows && rows.length > 0 && (
        <div className="mt-4 space-y-3">
          <Notice tone="warn">هذا ما فهمته. راجع كل سطر؛ لن يُضاف شيء قبل ضغط «اعتمد المحدد».</Notice>
          {rows.map((r) => (
            <div key={r.id} className="rounded-xl border border-line bg-white p-3">
              <div className="flex flex-wrap items-center gap-2">
                <input type="checkbox" checked={r.include} onChange={(e) => upd(r.id, { include: e.target.checked })} className="h-5 w-5 accent-[#1f6a67]" aria-label="تضمين" />
                <input value={r.name} onChange={(e) => upd(r.id, { name: e.target.value })} className={`${inputCls} min-w-[9rem] flex-1`} aria-label="الاسم" />
                <Select value={r.cat} onChange={(v) => upd(r.id, { cat: v })} options={CAT_OPTIONS} label="القسم" />
                <label className="flex items-center gap-1 text-sm text-muted">
                  ساعات/يوم
                  <NumInput value={r.hours} min={0} max={24} step={0.5} onChange={(v) => upd(r.id, { hours: v })} />
                </label>
                <label className="flex items-center gap-1 text-sm text-muted">
                  أيام
                  <NumInput value={r.days} min={1} max={7} onChange={(v) => upd(r.id, { days: v })} />
                </label>
              </div>
              {r.note && <p className="mt-2 text-sm text-warn">{r.note}</p>}
            </div>
          ))}
          <div className="flex gap-2">
            <Btn onClick={apply}>اعتمد المحدد</Btn>
            <Btn variant="ghost" onClick={() => setRows(null)}>
              إلغاء
            </Btn>
          </div>
        </div>
      )}
    </Card>
  );
}
