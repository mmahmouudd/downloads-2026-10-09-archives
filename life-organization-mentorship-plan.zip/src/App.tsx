import { useEffect, useState } from 'react';
import type { Tab } from './types';
import { StoreProvider } from './lib/store';
import { Home } from './views/Home';
import { Budget } from './views/Budget';
import { Schedule } from './views/Schedule';
import { Study } from './views/Study';
import { Projects } from './views/Projects';
import { Track } from './views/Track';
import { Plan } from './views/Plan';

const TABS: { id: Tab; label: string }[] = [
  { id: 'home', label: 'الرئيسية' },
  { id: 'budget', label: 'ميزانية الأسبوع' },
  { id: 'schedule', label: 'الجدول' },
  { id: 'study', label: 'الدراسة' },
  { id: 'projects', label: 'المشاريع' },
  { id: 'track', label: 'المتابعة اليومية' },
  { id: 'plan', label: 'الخطة' },
];

const isTab = (v: string): v is Tab => TABS.some((t) => t.id === v);

export function App() {
  const [tab, setTab] = useState<Tab>(() => {
    const h = window.location.hash.replace('#', '');
    return isTab(h) ? h : 'home';
  });

  const go = (t: Tab) => {
    setTab(t);
    window.location.hash = t;
    window.scrollTo({ top: 0 });
  };

  useEffect(() => {
    const on = () => {
      const h = window.location.hash.replace('#', '');
      if (isTab(h)) setTab(h);
    };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);

  return (
    <StoreProvider>
      <div className="min-h-screen bg-paper text-ink">
        <header className="sticky top-0 z-30 border-b border-line bg-card/95 backdrop-blur">
          <div className="mx-auto max-w-5xl px-4 pt-3">
            <div className="flex items-center justify-between gap-3">
              <h1 className="text-xl font-bold text-brand-dark">منظّم الأسبوع · 168 ساعة</h1>
              <span className="hidden text-sm text-muted sm:block">بياناتك محفوظة على جهازك فقط</span>
            </div>
            <nav className="-mx-1 mt-2 flex gap-1 overflow-x-auto pb-2" aria-label="التنقل الرئيسي">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => go(t.id)}
                  aria-current={tab === t.id ? 'page' : undefined}
                  className={`shrink-0 rounded-xl px-4 py-2 text-[15px] font-semibold transition ${
                    tab === t.id ? 'bg-brand text-white' : 'text-ink hover:bg-paper'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </nav>
          </div>
        </header>

        <main className="mx-auto max-w-5xl px-4 py-6">
          {tab === 'home' && <Home go={go} />}
          {tab === 'budget' && <Budget />}
          {tab === 'schedule' && <Schedule />}
          {tab === 'study' && <Study />}
          {tab === 'projects' && <Projects />}
          {tab === 'track' && <Track />}
          {tab === 'plan' && <Plan />}
        </main>

        <footer className="mx-auto max-w-5xl px-4 pb-10 text-sm leading-7 text-muted">
          أداة تنظيم شخصية وليست استشارة طبية أو نفسية. الإدخال بالنص/الصوت يعمل محليًا بقواعد بسيطة بلا ذكاء اصطناعي خارجي ولا مفاتيح API.
        </footer>
      </div>
    </StoreProvider>
  );
}

export default App;
