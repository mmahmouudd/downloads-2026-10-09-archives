import type { CategoryId, Priority } from '../types';

export interface Cat {
  id: CategoryId;
  label: string;
  short: string;
  color: string;
  hint: string;
}

export const CATEGORIES: Cat[] = [
  { id: 'sleep', label: 'النوم والراحة والاستشفاء', short: 'النوم', color: '#5f73a8', hint: 'نوم الليل وأي قيلولة قصيرة' },
  { id: 'study', label: 'الدراسة الإلزامية (الكلية)', short: 'الكلية', color: '#2f7d6d', hint: 'المحاضرات والواجبات والمراجعة والتعويض' },
  { id: 'courses', label: 'المساقات والبرامج الإضافية', short: 'البرامج', color: '#6fa896', hint: 'زاد وأوزون برو ماكس وماكنزي و2B وغيرها' },
  { id: 'work', label: 'العمل والدخل والعمل الحر', short: 'العمل', color: '#b58a3c', hint: 'وظيفة أو عمل حر أو بحث عن دخل' },
  { id: 'projects', label: 'المشاريع الشخصية والتقنية', short: 'المشاريع', color: '#8b6aa7', hint: 'المشروع المحوري فقط، والبقية في قائمة الانتظار' },
  { id: 'worship', label: 'الصلاة والعبادات والعلم الشرعي', short: 'العبادة', color: '#3d8a9a', hint: 'الصلوات والورد والعلم الشرعي' },
  { id: 'food', label: 'الطعام والشرب', short: 'الطعام', color: '#c47a4a', hint: 'الوجبات وتجهيزها والماء' },
  { id: 'selfcare', label: 'العناية الشخصية والنظافة والملابس', short: 'العناية', color: '#c9889a', hint: 'الاستحمام والأسنان والشعر والملابس' },
  { id: 'move', label: 'الرياضة والحركة', short: 'الحركة', color: '#6d9a47', hint: 'مشي وتمارين وخروج من الغرفة' },
  { id: 'family', label: 'الأسرة والواجبات المنزلية والاجتماعية', short: 'الأسرة', color: '#a8785a', hint: 'البيت وصلة الرحم والأصدقاء' },
  { id: 'commute', label: 'المشاوير والتنقل', short: 'التنقل', color: '#8a8f98', hint: 'الطريق للكلية والمشاوير' },
  { id: 'leisure', label: 'الترفيه والسوشيال ومصادر التشتت', short: 'الترفيه', color: '#c0584d', hint: 'ما تريد وضع سقف له' },
  { id: 'buffer', label: 'الراحة والوقت الاحتياطي والمهام غير المتوقعة', short: 'الاحتياطي', color: '#b5ab94', hint: 'مرونة لما لا تتوقعه' },
];

export const catMap = Object.fromEntries(CATEGORIES.map((c) => [c.id, c])) as Record<CategoryId, Cat>;

export const PRIORITIES: Record<Priority, { label: string; cls: string }> = {
  urgent: { label: 'عاجل', cls: 'bg-[#f6dcd8] text-[#8a2f26]' },
  important: { label: 'مهم', cls: 'bg-[#f6e8c8] text-[#7a5410]' },
  optional: { label: 'اختياري', cls: 'bg-[#dde8ee] text-[#2f5566]' },
  later: { label: 'مؤجل', cls: 'bg-[#e8e5dc] text-[#5b686c]' },
};

export const PRIORITY_OPTIONS = (Object.keys(PRIORITIES) as Priority[]).map((p) => ({ value: p, label: PRIORITIES[p].label }));
export const CAT_OPTIONS = CATEGORIES.map((c) => ({ value: c.id, label: c.short }));

export const DAYS = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];

export const DEEPABLE: CategoryId[] = ['study', 'courses', 'work', 'projects'];
