import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { AppState } from '../types';
import { seedState } from './seed';

const KEY = 'week168-planner-v1';

function load(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const saved = JSON.parse(raw) as Partial<AppState>;
      if (saved && saved.v === 1) return { ...seedState(), ...saved } as AppState;
    }
  } catch {
    /* تجاهل */
  }
  return seedState();
}

interface Ctx {
  state: AppState;
  set: (f: (s: AppState) => AppState) => void;
  replace: (s: AppState) => void;
  reset: () => void;
}

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* التخزين ممتلئ أو معطّل */
    }
  }, [state]);

  const value = useMemo<Ctx>(
    () => ({
      state,
      set: (f) => setState((s) => f(s)),
      replace: (s) => setState(s),
      reset: () => setState(seedState()),
    }),
    [state],
  );

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error('StoreProvider missing');
  return c;
}
