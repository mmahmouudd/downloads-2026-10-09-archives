import type { Activity, Block, CategoryId, Project, StudyItem } from '../types';
import { CATEGORIES, DEEPABLE } from './constants';
import { toMin } from './util';

export const WEEK_HOURS = 168;

export const actHours = (a: Activity) => a.patterns.reduce((s, p) => s + p.hours * p.days, 0);
export const actDays = (a: Activity) => a.patterns.reduce((s, p) => s + p.days, 0);

export function totalsOf(acts: Activity[]) {
  const byCat = {} as Record<CategoryId, number>;
  CATEGORIES.forEach((c) => (byCat[c.id] = 0));
  acts.forEach((a) => {
    byCat[a.cat] += actHours(a);
  });
  const allocated = Object.values(byCat).reduce((x, y) => x + y, 0);
  return { byCat, allocated, unallocated: WEEK_HOURS - allocated };
}

// الفرق بين الساعات المتاحة نظريًا وما يمكن استغلاله فعليًا بتركيز
export function focusEstimate(acts: Activity[], factor: number) {
  const t = totalsOf(acts);
  const essentials = (['sleep', 'food', 'selfcare', 'worship', 'commute', 'family', 'move', 'buffer'] as CategoryId[]).reduce(
    (s, c) => s + t.byCat[c],
    0,
  );
  const fixed = acts.filter((a) => !a.deep && DEEPABLE.includes(a.cat)).reduce((s, a) => s + actHours(a), 0);
  const base = Math.max(0, WEEK_HOURS - essentials - fixed);
  const ceiling = base * factor;
  const plannedDeep = acts.filter((a) => a.deep).reduce((s, a) => s + actHours(a), 0);
  const startTarget = Math.max(2, Math.round(ceiling * 0.65 * 2) / 2);
  return { base, ceiling, plannedDeep, startTarget, fixed, essentials };
}

export function sleepStats(acts: Activity[]) {
  const pats = acts.filter((a) => a.cat === 'sleep').flatMap((a) => a.patterns.filter((p) => p.days > 0));
  const nights = pats.reduce((s, p) => s + p.days, 0);
  if (!nights) return { nights: 0, avg: 0, min: 0, max: 0, range: 0 };
  const avg = pats.reduce((s, p) => s + p.hours * p.days, 0) / nights;
  const min = Math.min(...pats.map((p) => p.hours));
  const max = Math.max(...pats.map((p) => p.hours));
  return { nights, avg, min, max, range: max - min };
}

export const blockHours = (b: Block) => {
  const d = toMin(b.end) - toMin(b.start);
  return d > 0 ? d / 60 : 0;
};

export function analyzeBlocks(blocks: Block[]) {
  const bad = new Set<string>();
  const invalid = new Set<string>();
  const pairs: { a: Block; b: Block }[] = [];
  const byDay: Block[][] = Array.from({ length: 7 }, () => []);
  blocks.forEach((b) => {
    if (toMin(b.end) <= toMin(b.start)) invalid.add(b.id);
    else byDay[b.day]?.push(b);
  });
  byDay.forEach((list) => {
    const s = [...list].sort((x, y) => toMin(x.start) - toMin(y.start));
    for (let i = 0; i < s.length; i++) {
      for (let j = i + 1; j < s.length; j++) {
        if (toMin(s[j].start) >= toMin(s[i].end)) break;
        pairs.push({ a: s[i], b: s[j] });
        bad.add(s[i].id);
        bad.add(s[j].id);
      }
    }
  });
  return { pairs, bad, invalid };
}

export function scheduleByCat(blocks: Block[]) {
  const r = {} as Record<CategoryId, number>;
  CATEGORIES.forEach((c) => (r[c.id] = 0));
  blocks.forEach((b) => {
    r[b.cat] += blockHours(b);
  });
  return r;
}

export const studyRemaining = (s: StudyItem): number | null => {
  const base = s.backlog ?? s.total;
  if (base === null || base === undefined) return null;
  return Math.max(0, base - s.done);
};

export const studyHours = (s: StudyItem): number | null => {
  const r = studyRemaining(s);
  if (r === null || s.minutes === null) return null;
  return (r * s.minutes * s.factor) / 60;
};

export const projectScore = (p: Project) => p.value + p.readiness + p.alignment + (6 - p.effort);
