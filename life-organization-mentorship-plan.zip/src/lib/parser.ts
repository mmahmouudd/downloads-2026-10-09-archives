import type { CategoryId } from '../types';
import { catMap } from './constants';
import { uid } from './util';

export interface Parsed {
  id: string;
  name: string;
  cat: CategoryId;
  hours: number;
  days: number;
  note: string;
  include: boolean;
}

// تطبيع يحافظ على أطوال النص (حرف مقابل حرف) بعد حذف التشكيل
function normalize(s: string) {
  return s
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/،/g, ',')
    .replace(/؛/g, ';')
    .replace(/\u061F/g, '?')
    .toLowerCase();
}

const WORDS: Record<string, number> = {
  واحد: 1, واحده: 1, اثنين: 2, اثنان: 2, اتنين: 2, ثلاث: 3, ثلاثه: 3, تلات: 3, تلاته: 3,
  اربع: 4, اربعه: 4, خمس: 5, خمسه: 5, ست: 6, سته: 6, سبع: 7, سبعه: 7,
  ثمان: 8, ثماني: 8, ثمانيه: 8, تمان: 8, تمانيه: 8, تسع: 9, تسعه: 9, عشر: 10, عشره: 10,
  نصف: 0.5, نص: 0.5,
};
const wordAlt = Object.keys(WORDS).sort((a, b) => b.length - a.length).join('|');
const NUM = `(\\d+(?:\\.\\d+)?|${wordAlt})`;
const LB = '(?<![\\u0600-\\u06FF\\d.])';
const HOURS_SRC = `${LB}(?:${NUM}\\s*)?(ساعتين|ساعات|ساعه|دقيقه|دقائق|دقايق)`;
const numVal = (s: string) => WORDS[s] ?? parseFloat(s);

const KW: [CategoryId, RegExp][] = [
  ['sleep', /نام|نوم|نمت/],
  ['study', /كليه|محاضر|ادرس|اذاكر|مذاكر|دراس|جامع/],
  ['courses', /زاد|اوزون|ماكنزي|كورس|دوره|اكاديم|اتعلم/],
  ['work', /شغل|اشتغل|وظيف|فريلانس/],
  ['projects', /مشروع|مشاريع|برمج|كود/],
  ['worship', /صلي|صلاه|صلوات|قران/],
  ['food', /اكل|طعام|فطار|غداء|عشاء|وجب/],
  ['selfcare', /استحم|حمام|نظاف|اسنان/],
  ['move', /رياض|امشي|مشي|جيم|تمرين|حركه/],
  ['family', /اهلي|اسره|زيار|اقارب|صله رحم/],
  ['commute', /مواصلات|مشوار|تنقل|طريق|سفر/],
  ['leisure', /تيك|ريلز|سوشيال|موبايل|يوتيوب|العاب|العب|مسلسل|افلام|فيلم|مانهوا|تصفح|ترفيه/],
  ['buffer', /راحه|استرخاء|قيلوله/],
];

function lastCat(seg: string): CategoryId | null {
  let best = -1;
  let cat: CategoryId | null = null;
  for (const [c, re] of KW) {
    const r = new RegExp(re.source, 'g');
    let m: RegExpExecArray | null;
    while ((m = r.exec(seg))) {
      if (m.index >= best) {
        best = m.index;
        cat = c;
      }
    }
  }
  return cat;
}

function firstCat(seg: string): CategoryId | null {
  let best = Infinity;
  let cat: CategoryId | null = null;
  for (const [c, re] of KW) {
    const m = re.exec(seg);
    if (m && m.index < best) {
      best = m.index;
      cat = c;
    }
  }
  return cat;
}

function parseDays(rest: string): number | null {
  let m = rest.match(new RegExp(`^\\s*(?:في|فى|ل|لمده|علي|على|خلال)?\\s*${NUM}\\s*(?:ايام|يوم|ليالي|ليال|ليله)`));
  if (m) return numVal(m[1]);
  if (/^\s*(?:في|فى|ل|لمده|علي|على)?\s*(?:يومين|ليلتين)/.test(rest)) return 2;
  if (/^\s*(?:كل\s*يوم|يوميا|في\s*اليوم|باليوم)/.test(rest)) return 7;
  m = rest.match(/^\s*(?:في|ل)?\s*(?:يوم|ليله)(?:\s|$|,)/);
  if (m) return 1;
  return null;
}

const describe = (w: string) => {
  if (/حضور/.test(w)) return 'حضوري';
  if (/اونلاين|اون|بعد/.test(w)) return 'أونلاين';
  return w;
};

export function parseText(raw: string): Parsed[] {
  const t = normalize(raw);
  const out: Parsed[] = [];
  const re = new RegExp(HOURS_SRC, 'g');
  let m: RegExpExecArray | null;
  let last = 0;
  let prev: CategoryId | null = null;

  while ((m = re.exec(t))) {
    const start = m.index;
    const end = start + m[0].length;
    const unit = m[2];
    const n = m[1] !== undefined ? numVal(m[1]) : null;
    let hours = 1;
    if (unit === 'ساعتين') hours = n ?? 2;
    else if (unit === 'ساعات' || unit === 'ساعه') hours = n ?? 1;
    else hours = (n ?? 1) / 60;

    const rest = t.slice(end, end + 30);
    const d = parseDays(rest);
    let cat = lastCat(t.slice(last, start));
    if (!cat) cat = firstCat(rest.split(/[,;.]/)[0]);
    if (!cat) cat = prev;
    if (!cat) cat = 'buffer';
    prev = cat;
    last = end;

    out.push({
      id: uid(),
      name: catMap[cat].short,
      cat,
      hours: Math.round(Math.min(24, hours) * 100) / 100,
      days: Math.min(7, Math.max(1, d ?? 7)),
      note: d === null ? 'لم تُذكر الأيام — افترضتُ كل أيام الأسبوع' : '',
      include: true,
    });
  }

  // عبارات بلا ساعات (مثل: أدرس في الكلية يومًا حضوريًا ويومًا أونلاين)
  t.split(/[,;.\n]+/).forEach((c) => {
    if (!c.trim() || new RegExp(HOURS_SRC).test(c)) return;
    const cat = lastCat(c);
    if (!cat) return;
    const dm = [...c.matchAll(/(?:يوما|يوم)\s+([^\s,]+)/g)];
    if (dm.length) {
      dm.forEach((x) =>
        out.push({
          id: uid(),
          name: `${catMap[cat].short} — ${describe(x[1])}`,
          cat,
          hours: 0,
          days: 1,
          note: 'لم تُذكر الساعات — أدخلها قبل الاعتماد',
          include: true,
        }),
      );
    } else {
      const dn = c.match(new RegExp(`${NUM}\\s*(?:ايام|يوم)`));
      out.push({
        id: uid(),
        name: catMap[cat].short,
        cat,
        hours: 0,
        days: Math.min(7, Math.max(1, dn ? numVal(dn[1]) : 1)),
        note: 'لم تُذكر الساعات — أدخلها قبل الاعتماد',
        include: true,
      });
    }
  });

  return out;
}
