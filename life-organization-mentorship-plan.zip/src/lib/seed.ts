import type { Activity, AppState, Block, CategoryId, Priority, Project, StudyItem } from '../types';
import { toMin, toTime, uid } from './util';

const A = (
  name: string,
  cat: CategoryId,
  priority: Priority,
  deep: boolean,
  pats: [number, number][],
  note?: string,
): Activity => ({
  id: uid(),
  name,
  cat,
  priority,
  deep,
  note,
  patterns: pats.map(([hours, days]) => ({ id: uid(), hours, days })),
});

// الواقع الحالي: فقط ما ذكرتَه، وكل ما عداه "غير مقيس" وليس مخترعًا
const currentActivities = (): Activity[] => [
  A('نوم الليل', 'sleep', 'important', false, [[10, 3], [14, 1], [3, 2], [9, 1]],
    'تقدير أولي من وصفك (9–15 ساعة في أيام و2–3 في أخرى). صحّحه بعد تسجيل نومك الفعلي في تبويب المتابعة.'),
  A('الطعام (مرة أو مرتين)', 'food', 'important', false, [[1, 7]], 'تقدير أولي: يعتمد على ما يُعدّه أهل البيت.'),
];

const planActivities = (): Activity[] => [
  A('نوم الليل', 'sleep', 'important', false, [[8, 5], [8.5, 2]], 'الهدف: ثبّت وقت الاستيقاظ أولًا. لا تقلّ عن 7 ساعات ولا تتجاوز 9 ساعات.'),
  A('محاضرات الكلية (يوم الحضور)', 'study', 'urgent', false, [[5, 1]], 'افتراض: عدّله بعدد الساعات الفعلي ليوم الحضور.'),
  A('محاضرات الكلية (يوم الأونلاين)', 'study', 'urgent', false, [[2.5, 1]], 'افتراض: عدّله بعدد الساعات الفعلي.'),
  A('تعويض تراكم الكلية (جلسات تركيز)', 'study', 'urgent', true, [[2, 3], [1.5, 2]], 'كل جلسة تنتهي بمخرج واضح: جزء من محاضرة + 3 نقاط ملخّص.'),
  A('حصر الدورات (زاد/أوزون/ماكنزي/2B)', 'courses', 'important', false, [[1, 3]], 'هذا الأسبوع حصر فقط، بلا محاضرات جديدة.'),
  A('خطوة مشروع واحد (20–30 دقيقة)', 'projects', 'optional', true, [[0.5, 3]], 'مشروع Vibe Coding واحد فقط.'),
  A('الصلوات الخمس', 'worship', 'important', false, [[1.25, 7]], 'الزيادة التدريجية: الفجر في مرحلة تقديم النوم لاحقًا.'),
  A('ورد القرآن (صفحة)', 'worship', 'important', false, [[0.25, 7]], 'تبدأ بصفحة واحدة.'),
  A('الوجبات (3 مواعيد)', 'food', 'important', false, [[1.5, 7]], 'مرتبطة بالأذان/الأسرة. بدائل سريعة إذا لم يُعدّ الطعام.'),
  A('العناية الأساسية (أسنان/وجه/ملابس نظيفة)', 'selfcare', 'important', false, [[0.5, 7]]),
  A('استحمام وشعر', 'selfcare', 'important', false, [[0.5, 3]], 'سبت/ثلاثاء/خميس في البداية.'),
  A('مشي (المسجد + 30 دقيقة)', 'move', 'important', false, [[0.5, 7]]),
  A('تمارين وزن الجسم', 'move', 'optional', false, [[0.25, 3]]),
  A('عمل منزلي صغير', 'family', 'important', false, [[0.5, 7]], 'غرفتك + شيء واحد للبيت.'),
  A('صلة رحم (اتصال)', 'family', 'important', false, [[0.5, 1]]),
  A('تنقل يوم الكلية', 'commute', 'important', false, [[2, 1]], 'افتراض: عدّله بوقت الطريق الفعلي.'),
  A('مشاوير أخرى', 'commute', 'optional', false, [[0.5, 2]]),
  A('ترفيه محدود (بسقف)', 'leisure', 'optional', false, [[1.5, 7]], 'مخطَّط ومحدود، لا ممنوع كليًا.'),
  A('راحة ومرونة', 'buffer', 'important', false, [[2, 7]]),
];

type Row = [string, string, string, CategoryId, Priority, boolean?];

function base(o: { wake: string; midday: boolean; earlyBed?: boolean }): Row[] {
  const w = toMin(o.wake);
  const rows: Row[] = [
    ['00:00', o.wake, 'نوم', 'sleep', 'important'],
    [o.wake, toTime(w + 30), 'روتين الاستيقاظ: ماء + ترتيب السرير + أسنان ووجه (بدون هاتف)', 'selfcare', 'important'],
    [toTime(w + 30), toTime(w + 60), 'فطار', 'food', 'important'],
    ['15:30', '15:50', 'صلاة العصر', 'worship', 'important'],
    ['17:30', '18:00', 'عمل منزلي صغير (غرفتك + شيء واحد للبيت)', 'family', 'important'],
    ['18:00', '18:20', 'صلاة المغرب', 'worship', 'important'],
    ['19:30', '19:50', 'صلاة العشاء', 'worship', 'important'],
    ['20:00', '20:45', 'عشاء مع الأسرة', 'food', 'important'],
  ];
  if (o.midday) {
    rows.push(
      ['12:00', '12:20', 'صلاة الظهر (المسجد)', 'worship', 'important'],
      ['12:20', '13:30', 'غداء', 'food', 'important'],
      ['15:00', '15:30', 'مشي 30 دقيقة', 'move', 'important'],
    );
  }
  if (o.earlyBed) {
    rows.push(
      ['22:15', '22:30', 'ورد القرآن (صفحة)', 'worship', 'important'],
      ['22:30', '23:00', 'إغلاق الأجهزة وتجهيز الغد', 'sleep', 'important'],
      ['23:00', '23:59', 'نوم (ليلة قبل يوم الكلية)', 'sleep', 'important'],
    );
  } else {
    rows.push(
      ['23:00', '23:15', 'ورد القرآن (صفحة)', 'worship', 'important'],
      ['23:15', '23:59', 'إغلاق الأجهزة: الهاتف يُشحن خارج الغرفة', 'sleep', 'important'],
    );
  }
  return rows;
}

const toBlocks = (day: number, rows: Row[]): Block[] =>
  rows.map(([start, end, title, cat, priority, deep]) => ({ id: uid(), day, start, end, title, cat, priority, deep: !!deep }));

const focus1: Row = ['09:15', '10:15', 'تركيز 1: تعويض الكلية (ابدأ بأصغر محاضرة)', 'study', 'urgent', true];
const brk: Row = ['10:15', '10:30', 'استراحة: ماء + حركة (بدون شاشة)', 'buffer', 'important'];
const focus2: Row = ['10:30', '11:30', 'تركيز 2: تعويض الكلية', 'study', 'urgent', true];
const proj: Row = ['11:30', '12:00', 'خطوة المشروع (20–30 د): شغّل مشروعًا واحدًا وسجّل ما يعمل وما ينقص', 'projects', 'optional', true];
const shower: Row = ['14:30', '15:00', 'استحمام + ملابس نظيفة (داخلية أيضًا)', 'selfcare', 'important'];
const leisure: Row = ['21:00', '22:30', 'ترفيه محدود بسقف (مؤقت)', 'leisure', 'optional'];

export function seedBlocks(): Block[] {
  return [
    // السبت: يوم تعويض
    ...toBlocks(0, [
      ...base({ wake: '08:00', midday: true, earlyBed: true }),
      focus1, brk, focus2,
      ['11:30', '12:00', 'حصر زاد: عدّ المحاضرات المتاحة وما شاهدته', 'courses', 'important'],
      ['13:30', '14:30', 'راحة بدون شاشات', 'buffer', 'important'],
      shower,
      ['21:00', '22:00', 'ترفيه محدود بسقف (مؤقت)', 'leisure', 'optional'],
    ]),
    // الأحد: يوم حضور الكلية (افتراض)
    ...toBlocks(1, [
      ...base({ wake: '07:00', midday: false }),
      ['08:00', '09:00', 'الطريق للكلية', 'commute', 'important'],
      ['09:00', '12:00', 'الكلية — حضوري (عدّل الساعات الفعلية)', 'study', 'urgent'],
      ['12:00', '12:30', 'صلاة الظهر + وجبة خفيفة', 'worship', 'important'],
      ['12:30', '14:30', 'الكلية — حضوري', 'study', 'urgent'],
      ['14:30', '15:30', 'الطريق للبيت', 'commute', 'important'],
      ['16:00', '17:30', 'تركيز: تعويض الكلية (مراجعة ما شُرح اليوم أولًا)', 'study', 'urgent', true],
      ['20:45', '21:15', 'مشي بعد العشاء', 'move', 'important'],
      ['21:15', '22:15', 'ترفيه محدود بسقف (مؤقت)', 'leisure', 'optional'],
    ]),
    // الاثنين
    ...toBlocks(2, [...base({ wake: '08:00', midday: true }), focus1, brk, focus2, proj, leisure]),
    // الثلاثاء: يوم أونلاين (افتراض)
    ...toBlocks(3, [
      ...base({ wake: '08:00', midday: true }),
      ['09:30', '12:00', 'محاضرات الكلية — أونلاين', 'study', 'urgent'],
      ['13:30', '14:30', 'حصر أوزون برو ماكس: الاسم والجدول من مجموعة Telegram', 'courses', 'important'],
      shower,
      leisure,
    ]),
    // الأربعاء
    ...toBlocks(4, [...base({ wake: '08:00', midday: true }), focus1, brk, focus2, proj, leisure]),
    // الخميس
    ...toBlocks(5, [
      ...base({ wake: '08:00', midday: true }),
      ['09:15', '10:45', 'تركيز: تعويض الكلية', 'study', 'urgent', true],
      ['10:45', '11:00', 'استراحة: ماء + حركة', 'buffer', 'important'],
      ['11:00', '11:30', 'خطوة المشروع (20–30 د)', 'projects', 'optional', true],
      ['13:30', '14:30', 'حصر ماكنزي و2B: القبول/اللغة/التكلفة/الاسم الكامل', 'courses', 'important'],
      shower,
      ['20:45', '21:15', 'اتصال بقريب (صلة رحم)', 'family', 'important'],
      ['21:15', '22:30', 'ترفيه محدود بسقف (مؤقت)', 'leisure', 'optional'],
    ]),
    // الجمعة
    ...toBlocks(6, [
      ...base({ wake: '08:30', midday: false }),
      ['09:30', '10:00', 'ملابس نظيفة + تجهيز للجمعة', 'selfcare', 'important'],
      ['10:00', '11:00', 'مراجعة الأسبوع + خطة القادم + قائمة مشتريات العناية', 'buffer', 'important'],
      ['11:30', '13:00', 'صلاة الجمعة', 'worship', 'important'],
      ['13:00', '14:00', 'غداء', 'food', 'important'],
      ['15:00', '15:30', 'مشي 30 دقيقة', 'move', 'important'],
      ['16:00', '17:00', 'وقت أسري / زيارة قريب إن أمكن', 'family', 'optional'],
      leisure,
    ]),
  ];
}

const S = (p: Partial<StudyItem> & { name: string }): StudyItem => ({
  id: uid(),
  kind: 'program',
  priority: 'important',
  total: null,
  backlog: null,
  done: 0,
  minutes: null,
  factor: 1,
  status: 'notstarted',
  deadline: '',
  review: '',
  missing: '',
  ...p,
});

export const seedStudy = (): StudyItem[] => [
  S({
    name: 'الكلية — 9 مواد',
    kind: 'mandatory',
    priority: 'urgent',
    backlog: 18,
    factor: 1.5,
    missing: 'لكل مادة: عدد المحاضرات المتراكمة، مدة المحاضرة، موعد الاختبار/التسليم. افتح بوابة الكلية وسجّلها (15 دقيقة). يمكنك تقسيم هذا السطر إلى 9 مواد.',
  }),
  S({
    name: 'أكاديمية زاد — المستوى الأول',
    priority: 'important',
    missing: 'مرّت نحو 8–9 أسابيع: ادخل المنصة وسجّل عدد المحاضرات المتاحة وما شاهدته ومدة كل محاضرة. لا تخمّن.',
  }),
  S({
    name: 'أوزون برو ماكس (محاضرات د. حازم شومان على Telegram)',
    priority: 'optional',
    missing: 'تحقق من الاسم الصحيح والجدول من مجموعة Telegram: عدد المحاضرات، هل هي مسجلة، وما المطلوب.',
  }),
  S({
    name: 'ماكنزي / McKinsey',
    priority: 'optional',
    missing: 'تحقق من القبول، لغة المحتوى (عربي/إنجليزي)، الجدول الأسبوعي، والتكلفة. لا تخصّص وقتًا قبل التأكد.',
  }),
  S({
    name: '2B (الاسم الكامل غير معروف)',
    priority: 'later',
    missing: 'الاسم الكامل وطبيعة البرنامج غير واضحين في ملاحظاتك. ابحث في رسائل القبول، ولا تخصّص وقتًا قبل التأكد.',
  }),
  S({ name: 'الإنجليزية', kind: 'optional', priority: 'later', missing: 'تدخل لاحقًا بعد تحقق بوابة "متى أضيف مسارًا جديدًا".' }),
  S({ name: 'Python والويب وFront-End (كمسار تعلم)', kind: 'optional', priority: 'later', missing: 'مؤجل: ما تفعله الآن هو نشر مشروع واحد جاهز، لا مسار جديد.' }),
  S({ name: 'التصميم', kind: 'optional', priority: 'later' }),
  S({ name: 'التسويق والتجارة الإلكترونية', kind: 'optional', priority: 'later' }),
  S({ name: 'البيزنس وريادة الأعمال', kind: 'optional', priority: 'later' }),
  S({ name: 'العلم الشرعي', kind: 'optional', priority: 'later', missing: 'الآن: ورد القرآن اليومي فقط. مسار العلم الشرعي يُضاف ضمن البوابة.' }),
];

const P = (p: Partial<Project> & { name: string }): Project => ({
  id: uid(),
  idea: '',
  status: 'idea',
  works: '',
  missing: '',
  fixHours: null,
  value: 3,
  readiness: 2,
  alignment: 2,
  effort: 3,
  next: '',
  decision: 'queue',
  ...p,
});

export const seedProjects = (): Project[] => [
  P({
    name: 'مشاريع Vibe Coding — اختيار واحد ونشره',
    idea: 'من بين مئات النسخ (تقدير غير مدقق: 100–500)، اختر مشروعًا واحدًا أقرب للعمل وانشره برابط مستقل.',
    status: 'partial',
    works: 'بعض المشاريع يعمل الـ Back-End فيها',
    missing: 'جرد واختبار، واجهات ضعيفة، نشر ورابط، README',
    value: 4, readiness: 3, alignment: 5, effort: 2,
    next: 'شغّل مشروعًا واحدًا محليًا 20 دقيقة وسجّل 3 أسطر: يعمل / ينقص / أول إصلاح.',
    decision: 'focus',
  }),
  P({ name: 'كتاب البيزنس (فتح مشروع في مصر)', idea: 'كتاب مُولَّد بالذكاء الاصطناعي.', status: 'partial', works: 'مسودة كتاب', missing: 'مراجعة الدقة (الترخيص والجوانب القانونية)، غلاف، قرار النشر', value: 3, readiness: 3, alignment: 2, effort: 3, next: 'مراجعة فصل واحد فقط عند فتح هذا المشروع.', decision: 'queue' }),
  P({ name: 'محتوى ديني بالذكاء الاصطناعي', idea: 'نظام إنتاج ثابت لمحتوى ديني.', status: 'idea', missing: 'نظام إنتاج + مراجعة شرعية للمحتوى قبل النشر', value: 3, readiness: 2, alignment: 3, effort: 3, decision: 'queue' }),
  P({ name: 'كتيبات ومخرجات أخرى', status: 'partial', missing: 'تحويلها إلى منتج منشور أو أرشفتها', value: 2, readiness: 3, alignment: 2, effort: 2, decision: 'queue' }),
  P({ name: 'وكالة/شركة تعتمد على الذكاء الاصطناعي', idea: 'شركة بشخص واحد + مسوقون ومبرمجون ومصممون عند الحاجة.', status: 'idea', missing: 'تحقق من الترخيص ونموذج الدخل وأول عميل — كلها مؤجلة', value: 4, readiness: 1, alignment: 2, effort: 5, decision: 'pause' }),
  P({ name: 'مصنع برمجي لإعادة توظيف المحتوى الرائج', idea: 'اكتشاف محتوى رائج وتحويله إلى مقاطع.', status: 'idea', missing: 'حقوق الملكية الفكرية: لا يجوز افتراض أن الانتشار يمنح حق إعادة النشر. يلزم إذن أو ترخيص.', value: 3, readiness: 1, alignment: 3, effort: 5, decision: 'pause' }),
  P({ name: 'قصص مصورة وروايات', idea: 'قصة مصورة بالذكاء الاصطناعي للبيع.', status: 'partial', missing: 'خطوة أولى واضحة وإنهاء فصل واحد', value: 3, readiness: 2, alignment: 1, effort: 4, decision: 'pause' }),
];

export function seedState(): AppState {
  return {
    v: 1,
    scenario: 'plan',
    activities: { current: currentActivities(), plan: planActivities() },
    blocks: seedBlocks(),
    study: seedStudy(),
    studyWeekly: 9,
    projects: seedProjects(),
    ideas: [],
    logs: [],
    focusFactor: 0.3,
  };
}
