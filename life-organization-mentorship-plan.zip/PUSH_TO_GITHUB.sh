#!/usr/bin/env bash
# ---------------------------------------------------------------
# رفع المشروع إلى GitHub داخل مجلد باسم فريد (لا يمسّ الملفات الموجودة)
# الاستخدام:
#   GITHUB_TOKEN=ghp_xxx ./PUSH_TO_GITHUB.sh https://github.com/user/repo
# أو:
#   export GITHUB_TOKEN=ghp_xxx
#   ./PUSH_TO_GITHUB.sh user/repo
# ---------------------------------------------------------------
set -euo pipefail

REPO_INPUT="${1:-}"
if [ -z "$REPO_INPUT" ]; then
  echo "مثال: GITHUB_TOKEN=ghp_xxx ./PUSH_TO_GITHUB.sh https://github.com/user/repo"
  exit 1
fi

if [ -z "${GITHUB_TOKEN:-}" ]; then
  echo "خطأ: ضع التوكن في المتغير GITHUB_TOKEN ولا تكتبه داخل الملف."
  exit 1
fi

# تحويل الرابط إلى user/repo
SLUG="${REPO_INPUT#https://github.com/}"
SLUG="${SLUG%.git}"
SLUG="${SLUG%/}"

# اسم مجلد فريد غير مكرر: الاسم + التاريخ + رقم عشوائي
FOLDER="week168-planner-$(date +%Y%m%d)-$(od -An -N2 -tu2 < /dev/urandom | tr -d ' ')"
echo "المجلد الجديد: ${FOLDER}"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "جارٍ استنساخ المستودع…"
git clone --depth 1 "https://x-access-token:${GITHUB_TOKEN}@github.com/${SLUG}.git" "$TMP/repo"

cd "$TMP/repo"

# إذا وُجد المجلد باسم مشابه، لا نمسحه؛ نختار اسمًا آخر
while [ -e "$FOLDER" ]; do
  FOLDER="${FOLDER}x"
done

mkdir -p "$FOLDER"

# نسخ ملفات المشروع الحالية فقط
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
for item in src public index.html package.json tsconfig.json vite.config.ts tailwind.config.js postcss.config.js; do
  if [ -e "${SRC_DIR}/${item}" ]; then
    cp -R "${SRC_DIR}/${item}" "$FOLDER/"
  fi
done

if [ -f "${SRC_DIR}/README-EXPORT.md" ]; then
  cp "${SRC_DIR}/README-EXPORT.md" "$FOLDER/README.md"
fi

# تنظيف أي ملفات بناء قديمة
rm -rf "$FOLDER/dist" "$FOLDER/node_modules"

git config user.name "${GIT_NAME:-dev}"
git config user.email "${GIT_EMAIL:-dev@users.noreply.github.com}"

git add "$FOLDER"
if git diff --cached --quiet; then
  echo "لا توجد تغييرات للرفع."
  exit 0
fi

git commit -m "add: ${FOLDER} (week168 planner)"
git push origin HEAD

echo "تم الرفع بنجاح داخل المجلد: ${FOLDER}"
echo "رابط المستودع: https://github.com/${SLUG}/tree/main/${FOLDER}"
