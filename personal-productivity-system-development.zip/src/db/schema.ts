import {
  boolean,
  date,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

// ---------- إعدادات عامة (مفتاح/قيمة) ----------
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});

// ---------- ميزانية الأسبوع: الأنشطة وأنماطها ----------
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  sectionKey: text("section_key").notNull(),
  name: text("name").notNull(),
  priority: text("priority").notNull().default("important"), // urgent | important | optional | deferred
  note: text("note"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const patterns = pgTable("patterns", {
  id: serial("id").primaryKey(),
  activityId: integer("activity_id")
    .notNull()
    .references(() => activities.id, { onDelete: "cascade" }),
  hoursPerDay: real("hours_per_day").notNull().default(0),
  days: integer("days").notNull().default(1),
  // أيام الأسبوع المحددة (0 = السبت ... 6 = الجمعة) — اختياري
  weekdays: jsonb("weekdays").$type<number[] | null>(),
  label: text("label"),
  sortOrder: integer("sort_order").notNull().default(0),
});

// ---------- التراكم الدراسي ----------
export const studySources = pgTable("study_sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("optional"), // mandatory | optional
  notes: text("notes"),
  unknowns: text("unknowns"), // معلومات ناقصة يجب التحقق منها
  nextStep: text("next_step"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const studyItems = pgTable("study_items", {
  id: serial("id").primaryKey(),
  sourceId: integer("source_id")
    .notNull()
    .references(() => studySources.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  totalLectures: integer("total_lectures"),
  doneLectures: integer("done_lectures").notNull().default(0),
  lectureMinutes: integer("lecture_minutes"),
  mode: text("mode").notNull().default("watch"), // watch | watch_solve | watch_solve_review
  status: text("status").notNull().default("not_started"), // not_started | in_progress | done
  deadline: date("deadline"),
  reviewDate: date("review_date"),
  notes: text("notes"),
  sortOrder: integer("sort_order").notNull().default(0),
});

// ---------- المشاريع والأفكار (قائمة الانتظار) ----------
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  idea: text("idea"),
  status: text("status").notNull().default("idea"), // idea | started | backend_works | needs_ui | ready | archived
  works: text("works"),
  missing: text("missing"),
  fixHours: real("fix_hours"),
  value: text("value").notNull().default("unknown"), // low | medium | high | unknown
  nextStep: text("next_step"),
  priority: text("priority").notNull().default("deferred"), // urgent | important | optional | deferred
  isFocus: boolean("is_focus").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- المتابعة اليومية (مثلث الطاقة والعادات) ----------
export const dailyLogs = pgTable("daily_logs", {
  id: serial("id").primaryKey(),
  logDate: date("log_date").notNull().unique(),
  sleepHours: real("sleep_hours"),
  sleepScore: integer("sleep_score"), // 1-5
  foodScore: integer("food_score"), // 1-5
  moveScore: integer("move_score"), // 1-5
  meals: integer("meals"),
  waterCups: integer("water_cups"),
  moveMinutes: integer("move_minutes"),
  care: jsonb("care").$type<Record<string, boolean>>(),
  prayers: integer("prayers"), // 0-5
  socialMinutes: integer("social_minutes"),
  win: text("win"),
  note: text("note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Activity = typeof activities.$inferSelect;
export type Pattern = typeof patterns.$inferSelect;
export type StudySource = typeof studySources.$inferSelect;
export type StudyItem = typeof studyItems.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type DailyLog = typeof dailyLogs.$inferSelect;
