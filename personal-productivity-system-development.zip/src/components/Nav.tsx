"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "الرئيسية" },
  { href: "/budget", label: "ميزانية 168 ساعة" },
  { href: "/study", label: "التراكم الدراسي" },
  { href: "/projects", label: "المشاريع والأفكار" },
  { href: "/daily", label: "المتابعة اليومية" },
  { href: "/plan", label: "الخطة والنظام" },
];

export default function Nav() {
  const path = usePathname();
  return (
    <header className="sticky top-0 z-20 border-b" style={{ background: "rgba(246,244,238,0.92)", backdropFilter: "blur(8px)", borderColor: "var(--line)" }}>
      <div className="container-x flex items-center justify-between gap-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg" style={{ color: "var(--primary)" }}>
          <span aria-hidden className="inline-block h-7 w-7 rounded-lg" style={{ background: "var(--primary)" }} />
          <span>168 ساعة</span>
        </Link>
        <nav className="flex gap-1 overflow-x-auto" aria-label="التنقل الرئيسي">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="nav-link" aria-current={path === l.href ? "page" : undefined}>
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
