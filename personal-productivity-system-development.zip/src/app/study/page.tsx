import { getStudyBoard } from "@/lib/data";
import StudyBoard from "./StudyBoard";

export const dynamic = "force-dynamic";

export default async function StudyPage() {
  const sources = await getStudyBoard();
  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>التراكم الدراسي</p>
        <h1 className="text-2xl md:text-3xl mt-1">احصر أولًا، ثم عوّض</h1>
        <p className="mt-2 max-w-3xl" style={{ color: "var(--muted)" }}>
          الدراسة الإلزامية (الكلية) مفصولة عن البرامج الإضافية. الحقول الفارغة = معلومات لا تعرفها بعد، وبجوار كل جهة خطوة قصيرة لمعرفتها.
          لا تبدأ متابعة جديدة قبل أن يصبح عدد المحاضرات المتبقية معروفًا.
        </p>
      </header>
      <StudyBoard sources={sources} />
    </div>
  );
}
