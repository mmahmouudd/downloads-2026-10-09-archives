"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { StudyItem, StudySource } from "@/db/schema";
import { STUDY_MODES, STUDY_STATUS } from "@/lib/constants";
import { round1 } from "@/lib/calc";
import { createStudyItem, createStudySource, deleteStudyItem, deleteStudySource, updateStudyItem, updateStudySource } from "@/lib/actions";

type Source = StudySource & { items: StudyItem[] };

const modeFactor = (m: string) => (m === "watch" ? 1 : m === "watch_solve" ? 1.6 : 2);

export function itemRemainingHours(it: StudyItem) {
  if (it.totalLectures === null || !it.lectureMinutes) return null;
  const rem = Math.max(0, it.totalLectures - it.doneLectures);
  return (rem * it.lectureMinutes * modeFactor(it.mode)) / 60;
}

export default function StudyBoard({ sources }: { sources: Source[] }) {
  const router = useRouter();
  const [local, setLocal] = useState(sources);
  const [, start] = useTransition();
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});

  useEffect(() => setLocal(sources), [sources]);

  function schedule(key: string, fn: () => Promise<void>) {
    const t = timers.current.get(key);
    if (t) clearTimeout(t);
    timers.current.set(key, setTimeout(async () => {
      timers.current.delete(key);
      await fn();
      if (timers.current.size === 0) start(() => router.refresh());
    }, 600));
  }

  function patchItem(sid: number, id: number, data: Partial<StudyItem>) {
    setLocal((prev) => prev.map((s) => (s.id !== sid ? s : { ...s, items: s.items.map((i) => (i.id !== id ? i : { ...i, ...data })) })));
    schedule(`i${id}`, () => updateStudyItem(id, data as Parameters<typeof updateStudyItem>[1]));
  }
  function patchSource(id: number, data: Partial<StudySource>) {
    setLocal((prev) => prev.map((s) => (s.id !== id ? s : { ...s, ...data })));
    schedule(`s${id}`, () => updateStudySource(id, data as Parameters<typeof updateStudySource>[1]));
  }

  // الإجماليات
  let totalRem = 0, totalHours = 0, unknown = 0;
  for (const s of local) for (const it of s.items) {
    if (it.totalLectures === null) { unknown++; continue; }
    totalRem += Math.max(0, it.totalLectures - it.doneLectures);
    totalHours += itemRemainingHours(it) ?? 0;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card-soft"><p className="text-xs" style={{ color: "var(--muted)" }}>محاضرات متبقية (معروفة)</p><p className="stat-num">{totalRem}</p></div>
        <div className="card-soft"><p className="text-xs" style={{ color: "var(--muted)" }}>ساعات عمل تقديرية</p><p className="stat-num">{round1(totalHours)}</p><p className="text-xs" style={{ color: "var(--muted)" }}>تحتاج مدة المحاضرة</p></div>
        <div className="card-soft"><p className="text-xs" style={{ color: "var(--muted)" }}>بنود بعدد غير معروف</p><p className="stat-num">{unknown}</p></div>
        <div className="card-soft"><p className="text-xs" style={{ color: "var(--muted)" }}>جهات</p><p className="stat-num">{local.length}</p></div>
      </div>
      <p className="alert alert-info text-sm">
        معامل الوقت: مشاهدة فقط ×1، مشاهدة+حل ×1.6، مشاهدة+حل+مراجعة ×2 من مدة المحاضرة. الحقول الفارغة تعني «غير معروف» ولا نخترع لها أرقامًا.
      </p>

      {local.map((s) => {
        const srcRem = s.items.reduce((a, it) => a + (it.totalLectures === null ? 0 : Math.max(0, it.totalLectures - it.doneLectures)), 0);
        const srcH = s.items.reduce((a, it) => a + (itemRemainingHours(it) ?? 0), 0);
        const isOpen = expanded[s.id] ?? true;
        return (
          <section key={s.id} className="card">
            <div className="flex flex-wrap items-center gap-2">
              <input className="input flex-1 min-w-[12rem] font-bold text-lg" value={s.name} onChange={(e) => patchSource(s.id, { name: e.target.value })} />
              <select className="select w-auto" value={s.kind} onChange={(e) => patchSource(s.id, { kind: e.target.value })}>
                <option value="mandatory">إلزامي</option>
                <option value="optional">اختياري / إضافي</option>
              </select>
              <span className={`chip ${s.kind === "mandatory" ? "chip-urgent" : "chip-optional"}`}>{srcRem} متبقية · {round1(srcH)} س</span>
              <button className="btn btn-ghost btn-sm" onClick={() => setExpanded((e) => ({ ...e, [s.id]: !isOpen }))}>{isOpen ? "طيّ" : "فتح"}</button>
              <button className="btn btn-danger btn-sm" onClick={async () => { if (confirm(`حذف «${s.name}»؟`)) { await deleteStudySource(s.id); router.refresh(); } }}>حذف</button>
            </div>

            {isOpen && (
              <>
                <div className="grid md:grid-cols-3 gap-3 mt-3">
                  <div>
                    <label className="label">ملاحظات / ما هو معروف</label>
                    <textarea className="textarea" value={s.notes ?? ""} onChange={(e) => patchSource(s.id, { notes: e.target.value })} />
                  </div>
                  <div>
                    <label className="label" style={{ color: "var(--accent)" }}>معلومات ناقصة يجب التحقق منها</label>
                    <textarea className="textarea" value={s.unknowns ?? ""} onChange={(e) => patchSource(s.id, { unknowns: e.target.value })} />
                  </div>
                  <div>
                    <label className="label" style={{ color: "var(--primary)" }}>الخطوة التالية (10–20 دقيقة)</label>
                    <textarea className="textarea" value={s.nextStep ?? ""} onChange={(e) => patchSource(s.id, { nextStep: e.target.value })} />
                  </div>
                </div>

                <div className="table-wrap mt-4">
                  <table className="w-full text-sm">
                    <thead>
                      <tr style={{ color: "var(--muted)" }}>
                        <th className="text-right p-2 font-semibold">المادة / المساق</th>
                        <th className="p-2 font-semibold">إجمالي المحاضرات</th>
                        <th className="p-2 font-semibold">المنجز</th>
                        <th className="p-2 font-semibold">دقائق/محاضرة</th>
                        <th className="p-2 font-semibold">النوع</th>
                        <th className="p-2 font-semibold">الحالة</th>
                        <th className="p-2 font-semibold">موعد نهائي</th>
                        <th className="p-2 font-semibold">موعد المراجعة</th>
                        <th className="p-2 font-semibold">متبقٍ</th>
                        <th className="p-2"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {s.items.map((it) => {
                        const rem = it.totalLectures === null ? null : Math.max(0, it.totalLectures - it.doneLectures);
                        const h = itemRemainingHours(it);
                        return (
                          <tr key={it.id} style={{ borderTop: "1px solid var(--line)" }}>
                            <td className="p-2 min-w-[12rem]"><input className="input" value={it.name} onChange={(e) => patchItem(s.id, it.id, { name: e.target.value })} /></td>
                            <td className="p-2"><input type="number" min={0} className="input input-num" placeholder="؟" value={it.totalLectures ?? ""} onChange={(e) => patchItem(s.id, it.id, { totalLectures: e.target.value === "" ? null : Number(e.target.value) })} /></td>
                            <td className="p-2"><input type="number" min={0} className="input input-num" value={it.doneLectures} onChange={(e) => patchItem(s.id, it.id, { doneLectures: Number(e.target.value) })} /></td>
                            <td className="p-2"><input type="number" min={0} className="input input-num" placeholder="؟" value={it.lectureMinutes ?? ""} onChange={(e) => patchItem(s.id, it.id, { lectureMinutes: e.target.value === "" ? null : Number(e.target.value) })} /></td>
                            <td className="p-2"><select className="select" value={it.mode} onChange={(e) => patchItem(s.id, it.id, { mode: e.target.value })}>{STUDY_MODES.map((m) => <option key={m.key} value={m.key}>{m.label}</option>)}</select></td>
                            <td className="p-2"><select className="select" value={it.status} onChange={(e) => patchItem(s.id, it.id, { status: e.target.value })}>{STUDY_STATUS.map((m) => <option key={m.key} value={m.key}>{m.label}</option>)}</select></td>
                            <td className="p-2"><input type="date" className="input" value={it.deadline ?? ""} onChange={(e) => patchItem(s.id, it.id, { deadline: e.target.value || null })} /></td>
                            <td className="p-2"><input type="date" className="input" value={it.reviewDate ?? ""} onChange={(e) => patchItem(s.id, it.id, { reviewDate: e.target.value || null })} /></td>
                            <td className="p-2 text-center whitespace-nowrap">
                              {rem === null ? <span className="chip chip-optional">غير معروف</span> : <strong>{rem}</strong>}
                              {h !== null && <div className="text-xs" style={{ color: "var(--muted)" }}>≈ {round1(h)} س</div>}
                            </td>
                            <td className="p-2"><button className="btn btn-danger btn-sm" onClick={async () => { await deleteStudyItem(it.id); router.refresh(); }}>×</button></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <button className="btn btn-secondary btn-sm mt-3" onClick={async () => { const n = prompt("اسم المادة/المساق:"); if (n === null) return; await createStudyItem(s.id, n); router.refresh(); }}>+ إضافة مادة</button>
              </>
            )}
          </section>
        );
      })}

      <button className="btn btn-ghost" onClick={async () => { const n = prompt("اسم الجهة التعليمية:"); if (n === null) return; await createStudySource(n); router.refresh(); }}>+ إضافة جهة تعليمية</button>
    </div>
  );
}
