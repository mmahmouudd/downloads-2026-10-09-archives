import Link from "next/link";
import { getActivitiesWithPatterns, getLogs, getProjects, getSettings, getStudyBoard } from "@/lib/data";
import { fmtH, round1, summarizeWeek } from "@/lib/calc";
import { WEEK_HOURS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [acts, cfg, board, projs, logs] = await Promise.all([
    getActivitiesWithPatterns(),
    getSettings(),
    getStudyBoard(),
    getProjects(),
    getLogs(7),
  ]);
  const s = summarizeWeek(acts, cfg.focusRatio);
  const focus = projs.find((p) => p.isFocus);

  // تراكم دراسي
  let remainingLectures = 0;
  let unknownCount = 0;
  let remainingHours = 0;
  for (const src of board) {
    for (const it of src.items) {
      if (it.totalLectures === null) { unknownCount++; continue; }
      const rem = Math.max(0, it.totalLectures - it.doneLectures);
      remainingLectures += rem;
      const factor = it.mode === "watch" ? 1 : it.mode === "watch_solve" ? 1.6 : 2;
      remainingHours += it.lectureMinutes ? (rem * it.lectureMinutes * factor) / 60 : 0;
    }
  }
  const sourcesWithUnknowns = board.filter((b) => b.unknowns && b.unknowns.trim().length > 0).length;

  const studyPlanned = s.sections.filter((x) => x.key === "study_mandatory").reduce((a, b) => a + b.hours, 0);
  const projectPlanned = s.sections.filter((x) => x.key === "projects").reduce((a, b) => a + b.hours, 0);
  const sleepPlanned = s.sections.find((x) => x.key === "sleep")?.hours ?? 0;

  const sorted = [...s.sections].sort((a, b) => b.hours - a.hours);
  const lastLog = logs[0];

  return (
    <div className="space-y-8">
      <section className="grid gap-4 md:grid-cols-[1.4fr_1fr] items-stretch">
        <div className="card flex flex-col justify-between gap-4">
          <div>
            <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>لوحة الملخص</p>
            <h1 className="text-2xl md:text-3xl mt-1">أين تذهب 168 ساعة في أسبوعك؟</h1>
            <p className="mt-2" style={{ color: "var(--muted)" }}>
              هذه الأرقام محسوبة من الأنماط التي أدخلتها (ساعات × أيام)، لا من افتراض أن كل الأيام متشابهة.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Stat label="موزَّع" value={fmtH(s.total)} sub={`من ${WEEK_HOURS} ساعة`} />
            <Stat label={s.overflow ? "تجاوز" : "غير موزَّع"} value={fmtH(Math.abs(s.unallocated))} sub={s.overflow ? "يجب تقليل شيء" : "متاح نظريًا"} danger={s.overflow} />
            <Stat label="قابل للتركيز فعليًا" value={fmtH(s.realisticFocus)} sub={`≈ ${Math.round(cfg.focusRatio * 100)}% من غير الموزَّع`} />
          </div>
          <div>
            <div className="bar" aria-hidden>
              <span style={{ width: `${Math.min(100, (s.total / WEEK_HOURS) * 100)}%`, background: s.overflow ? "var(--danger)" : "var(--primary)" }} />
            </div>
            <div className="flex justify-between text-xs mt-1" style={{ color: "var(--muted)" }}>
              <span>0</span><span>{WEEK_HOURS} ساعة</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link href="/budget" className="btn btn-primary">تعديل ميزانية الأسبوع</Link>
            <Link href="/daily" className="btn btn-secondary">تسجيل اليوم</Link>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg">تنبيهات</h2>
          {s.alerts.length === 0 ? (
            <p className="alert alert-ok mt-3">لا توجد تجاوزات: الأيام ≤ 7 لكل نشاط، والإجمالي ≤ 168، ولا تداخل يومي.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {s.alerts.map((a, i) => (
                <li key={i} className="alert alert-warn">{a}</li>
              ))}
            </ul>
          )}
          {s.unpinnedHours > 0 && (
            <p className="mt-3 text-sm" style={{ color: "var(--muted)" }}>
              {fmtH(s.unpinnedHours)} غير مثبتة على أيام محددة (وهذا طبيعي؛ ثبّت فقط ما له يوم ثابت مثل الكلية).
            </p>
          )}
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <div className="card">
          <h2 className="text-lg">التراكم الدراسي</h2>
          <p className="stat-num mt-2">{remainingLectures}</p>
          <p className="text-sm" style={{ color: "var(--muted)" }}>محاضرة متبقية معروفة العدد
            {remainingHours > 0 && <> · ≈ {round1(remainingHours)} ساعة عمل</>}
          </p>
          <p className="mt-2 text-sm">
            {unknownCount > 0 && <span className="chip chip-optional ml-1">{unknownCount} بند بعدد غير معروف</span>}
            {sourcesWithUnknowns > 0 && <span className="chip chip-muted">{sourcesWithUnknowns} جهات تحتاج تحققًا</span>}
          </p>
          <p className="mt-2 text-sm">مخطط لها هذا الأسبوع: <strong>{fmtH(studyPlanned)}</strong></p>
          <Link href="/study" className="btn btn-secondary btn-sm mt-3">فتح لوحة التراكم</Link>
        </div>

        <div className="card">
          <h2 className="text-lg">المشروع المحوري</h2>
          {focus ? (
            <>
              <p className="mt-2 font-bold">{focus.name}</p>
              <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>{focus.nextStep ?? "حدّد الخطوة التالية (10–20 دقيقة)."}</p>
              <p className="mt-2 text-sm">مخطط له هذا الأسبوع: <strong>{fmtH(projectPlanned)}</strong></p>
            </>
          ) : (
            <p className="mt-2 text-sm" style={{ color: "var(--muted)" }}>لم تحدد مشروعًا محوريًا بعد. اختر واحدًا فقط.</p>
          )}
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
            {projs.filter((p) => !p.isFocus && p.status !== "archived").length} فكرة/مشروع في قائمة الانتظار
          </p>
          <Link href="/projects" className="btn btn-secondary btn-sm mt-3">فتح قائمة المشاريع</Link>
        </div>

        <div className="card">
          <h2 className="text-lg">مثلث الطاقة (آخر تسجيل)</h2>
          {lastLog ? (
            <>
              <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>{lastLog.logDate}</p>
              <div className="grid grid-cols-3 gap-2 mt-2 text-center">
                <Mini label="نوم" v={lastLog.sleepScore} extra={lastLog.sleepHours !== null ? `${lastLog.sleepHours} س` : undefined} />
                <Mini label="غذاء/ماء" v={lastLog.foodScore} />
                <Mini label="حركة" v={lastLog.moveScore} />
              </div>
              {lastLog.win && <p className="mt-2 text-sm">إنجاز اليوم: <strong>{lastLog.win}</strong></p>}
            </>
          ) : (
            <p className="mt-2 text-sm" style={{ color: "var(--muted)" }}>لا توجد تسجيلات بعد. التسجيل يستغرق أقل من دقيقتين.</p>
          )}
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>النوم المخطط: {fmtH(sleepPlanned)} ≈ {round1(sleepPlanned / 7)} س/يوم</p>
          <Link href="/daily" className="btn btn-secondary btn-sm mt-3">تسجيل اليوم</Link>
        </div>
      </section>

      <section className="card">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="text-lg">توزيع الأقسام</h2>
          {s.topDrains.length > 0 && (
            <p className="text-sm" style={{ color: "var(--muted)" }}>
              أكبر مصدر استنزاف مُعلن: <strong>{s.topDrains[0].name}</strong> ({fmtH(s.topDrains[0].hours)})
            </p>
          )}
        </div>
        <ul className="mt-4 space-y-3">
          {sorted.map((sec) => (
            <li key={sec.key}>
              <div className="flex justify-between text-sm mb-1">
                <span>{sec.title}</span>
                <span className="font-semibold" style={{ fontVariantNumeric: "tabular-nums" }}>{fmtH(sec.hours)} · {Math.round(sec.share * 100)}%</span>
              </div>
              <div className="bar"><span style={{ width: `${Math.min(100, sec.share * 100)}%`, background: sec.color }} /></div>
            </li>
          ))}
          <li>
            <div className="flex justify-between text-sm mb-1">
              <span>غير موزَّع</span>
              <span className="font-semibold">{fmtH(Math.max(0, s.unallocated))}</span>
            </div>
            <div className="bar"><span style={{ width: `${Math.max(0, (s.unallocated / WEEK_HOURS) * 100)}%`, background: "#cfd4cc" }} /></div>
          </li>
        </ul>
      </section>

      <section className="card">
        <h2 className="text-lg">ملخص الأيام (الساعات المثبتة على أيام محددة فقط)</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2 mt-3">
          {s.days.map((d) => (
            <div key={d.index} className="card-soft text-center" style={d.over ? { borderColor: "var(--danger)" } : undefined}>
              <p className="font-semibold text-sm">{d.name}</p>
              <p className="stat-num text-xl mt-1">{round1(d.hours)}</p>
              <p className="text-xs" style={{ color: d.over ? "var(--danger)" : "var(--muted)" }}>{d.over ? "تداخل! > 24" : "ساعة مثبتة"}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value, sub, danger }: { label: string; value: string; sub?: string; danger?: boolean }) {
  return (
    <div className="card-soft">
      <p className="text-sm" style={{ color: "var(--muted)" }}>{label}</p>
      <p className="stat-num" style={danger ? { color: "var(--danger)" } : undefined}>{value}</p>
      {sub && <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>{sub}</p>}
    </div>
  );
}

function Mini({ label, v, extra }: { label: string; v: number | null; extra?: string }) {
  return (
    <div className="card-soft py-2">
      <p className="text-xs" style={{ color: "var(--muted)" }}>{label}</p>
      <p className="font-bold text-lg">{v ?? "—"}<span className="text-xs font-normal">/5</span></p>
      {extra && <p className="text-xs" style={{ color: "var(--muted)" }}>{extra}</p>}
    </div>
  );
}
