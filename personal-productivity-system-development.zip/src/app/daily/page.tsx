import { getLogs } from "@/lib/data";
import DailyLogForm from "./DailyLog";

export const dynamic = "force-dynamic";

export default async function DailyPage() {
  const logs = await getLogs(60);
  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>المتابعة اليومية</p>
        <h1 className="text-2xl md:text-3xl mt-1">مثلث الطاقة والعادات الأساسية</h1>
        <p className="mt-2 max-w-3xl" style={{ color: "var(--muted)" }}>
          النوم، الغذاء والترطيب، الحركة — بالإضافة إلى الصلاة والعناية والسوشيال ميديا وإنجاز واحد. المطلوب الملاحظة والتدرّج، لا الكمال.
        </p>
      </header>
      <DailyLogForm logs={logs} />
    </div>
  );
}
