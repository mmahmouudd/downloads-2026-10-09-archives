"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { DailyLog } from "@/db/schema";
import { CARE_ITEMS } from "@/lib/constants";
import { deleteDailyLog, upsertDailyLog } from "@/lib/actions";

function todayISO() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

const empty = (date: string) => ({
  logDate: date,
  sleepHours: "" as string | number,
  sleepScore: 3,
  foodScore: 3,
  moveScore: 2,
  meals: "" as string | number,
  waterCups: "" as string | number,
  moveMinutes: "" as string | number,
  care: {} as Record<string, boolean>,
  prayers: "" as string | number,
  socialMinutes: "" as string | number,
  win: "",
  note: "",
});

export default function DailyLogForm({ logs }: { logs: DailyLog[] }) {
  const router = useRouter();
  const [form, setForm] = useState(empty(todayISO()));
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState("");

  // تحميل سجل اليوم المختار إن وُجد
  useEffect(() => {
    const ex = logs.find((l) => l.logDate === form.logDate);
    if (ex) {
      setForm({
        logDate: ex.logDate,
        sleepHours: ex.sleepHours ?? "",
        sleepScore: ex.sleepScore ?? 3,
        foodScore: ex.foodScore ?? 3,
        moveScore: ex.moveScore ?? 2,
        meals: ex.meals ?? "",
        waterCups: ex.waterCups ?? "",
        moveMinutes: ex.moveMinutes ?? "",
        care: ex.care ?? {},
        prayers: ex.prayers ?? "",
        socialMinutes: ex.socialMinutes ?? "",
        win: ex.win ?? "",
        note: ex.note ?? "",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.logDate, logs]);

  const toNum = (v: string | number) => (v === "" ? null : Number(v));

  async function save() {
    setSaving(true);
    await upsertDailyLog({
      logDate: form.logDate,
      sleepHours: toNum(form.sleepHours),
      sleepScore: form.sleepScore,
      foodScore: form.foodScore,
      moveScore: form.moveScore,
      meals: toNum(form.meals),
      waterCups: toNum(form.waterCups),
      moveMinutes: toNum(form.moveMinutes),
      care: form.care,
      prayers: toNum(form.prayers),
      socialMinutes: toNum(form.socialMinutes),
      win: form.win || null,
      note: form.note || null,
    });
    setSaving(false);
    setSavedMsg("تم الحفظ.");
    setTimeout(() => setSavedMsg(""), 2000);
    router.refresh();
  }

  const recent = logs.slice(0, 14);
  const avg = (k: "sleepScore" | "foodScore" | "moveScore") => {
    const vals = recent.map((l) => l[k]).filter((v): v is number => v !== null);
    return vals.length ? (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1) : "—";
  };
  const sleepVals = recent.map((l) => l.sleepHours).filter((v): v is number => v !== null);
  const sleepMin = sleepVals.length ? Math.min(...sleepVals) : null;
  const sleepMax = sleepVals.length ? Math.max(...sleepVals) : null;

  return (
    <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
      <section className="card space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="text-lg">تسجيل سريع (أقل من دقيقتين)</h2>
          <input type="date" className="input w-auto" value={form.logDate} onChange={(e) => setForm({ ...empty(e.target.value) })} />
        </div>

        <div className="grid sm:grid-cols-3 gap-3">
          <Score label="النوم" value={form.sleepScore} onChange={(v) => setForm({ ...form, sleepScore: v })} />
          <Score label="الغذاء والترطيب" value={form.foodScore} onChange={(v) => setForm({ ...form, foodScore: v })} />
          <Score label="الحركة والنشاط" value={form.moveScore} onChange={(v) => setForm({ ...form, moveScore: v })} />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <Num label="ساعات النوم" value={form.sleepHours} step={0.5} max={24} onChange={(v) => setForm({ ...form, sleepHours: v })} />
          <Num label="عدد الوجبات" value={form.meals} max={10} onChange={(v) => setForm({ ...form, meals: v })} />
          <Num label="أكواب الماء" value={form.waterCups} max={30} onChange={(v) => setForm({ ...form, waterCups: v })} />
          <Num label="دقائق حركة/مشي" value={form.moveMinutes} max={600} onChange={(v) => setForm({ ...form, moveMinutes: v })} />
          <Num label="صلوات في وقتها (0–5)" value={form.prayers} max={5} onChange={(v) => setForm({ ...form, prayers: v })} />
          <Num label="دقائق سوشيال/ترفيه" value={form.socialMinutes} max={1440} onChange={(v) => setForm({ ...form, socialMinutes: v })} />
        </div>

        <div>
          <p className="label">العناية الشخصية اليوم</p>
          <div className="flex flex-wrap gap-2">
            {CARE_ITEMS.map((c) => (
              <button
                key={c.key}
                type="button"
                className="day-toggle"
                aria-pressed={form.care[c.key] ?? false}
                onClick={() => setForm({ ...form, care: { ...form.care, [c.key]: !form.care[c.key] } })}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="label">إنجاز واحد أساسي تحقق اليوم (ولو صغيرًا)</label>
          <input className="input" placeholder="مثال: أنهيت نصف محاضرة + رتبت السرير" value={form.win} onChange={(e) => setForm({ ...form, win: e.target.value })} />
        </div>
        <div>
          <label className="label">ملاحظة (اختياري): ما الذي أعاق أو ساعد؟</label>
          <textarea className="textarea" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
        </div>
        <div className="flex items-center gap-3">
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "جارٍ الحفظ…" : "حفظ اليوم"}</button>
          {savedMsg && <span className="chip chip-ok">{savedMsg}</span>}
        </div>
        <p className="text-xs" style={{ color: "var(--muted)" }}>
          التقييم من 1 إلى 5 وسيلة ملاحظة للاتجاه العام، لا حكم أخلاقي ولا تشخيص. إن استمر النوم خارج 6–10 ساعات لأسابيع، أو استمر ألم العين، فذلك يستحق تقييم مختص.
        </p>
      </section>

      <section className="space-y-4">
        <div className="card">
          <h2 className="text-lg">آخر 14 يومًا</h2>
          <div className="grid grid-cols-3 gap-2 mt-3 text-center">
            <div className="card-soft py-2"><p className="text-xs" style={{ color: "var(--muted)" }}>نوم</p><p className="font-bold text-xl">{avg("sleepScore")}</p></div>
            <div className="card-soft py-2"><p className="text-xs" style={{ color: "var(--muted)" }}>غذاء/ماء</p><p className="font-bold text-xl">{avg("foodScore")}</p></div>
            <div className="card-soft py-2"><p className="text-xs" style={{ color: "var(--muted)" }}>حركة</p><p className="font-bold text-xl">{avg("moveScore")}</p></div>
          </div>
          {sleepMin !== null && sleepMax !== null && (
            <p className="text-sm mt-3">
              تفاوت النوم: من <strong>{sleepMin}</strong> إلى <strong>{sleepMax}</strong> ساعة
              {sleepMax - sleepMin >= 5 && <span className="chip chip-optional mr-2">تفاوت كبير — الهدف تضييق المدى لا الكمال</span>}
            </p>
          )}
        </div>

        <div className="card">
          <h2 className="text-lg">السجل</h2>
          {logs.length === 0 && <p className="text-sm mt-2" style={{ color: "var(--muted)" }}>لا توجد تسجيلات بعد.</p>}
          <ul className="mt-3 divide-y" style={{ borderColor: "var(--line)" }}>
            {logs.map((l) => (
              <li key={l.id} className="py-2 flex items-start justify-between gap-2">
                <div>
                  <button className="font-semibold underline-offset-4 hover:underline" onClick={() => setForm({ ...empty(l.logDate) })}>{l.logDate}</button>
                  <p className="text-xs" style={{ color: "var(--muted)" }}>
                    نوم {l.sleepHours ?? "—"} س · {l.sleepScore ?? "—"}/{l.foodScore ?? "—"}/{l.moveScore ?? "—"}
                    {l.prayers !== null && <> · صلاة {l.prayers}/5</>}
                    {l.socialMinutes !== null && <> · سوشيال {l.socialMinutes} د</>}
                  </p>
                  {l.win && <p className="text-sm">✓ {l.win}</p>}
                </div>
                <button className="btn btn-danger btn-sm" onClick={async () => { if (confirm("حذف هذا اليوم؟")) { await deleteDailyLog(l.id); router.refresh(); } }}>×</button>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}

function Score({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="card-soft">
      <p className="label">{label}: {value}/5</p>
      <div className="flex gap-1" role="radiogroup" aria-label={label}>
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" role="radio" aria-checked={value === n} className="day-toggle flex-1" aria-pressed={value === n} onClick={() => onChange(n)}>{n}</button>
        ))}
      </div>
    </div>
  );
}

function Num({ label, value, onChange, step = 1, max }: { label: string; value: string | number; onChange: (v: string | number) => void; step?: number; max: number }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input type="number" min={0} max={max} step={step} className="input" placeholder="—" value={value} onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))} />
    </div>
  );
}
