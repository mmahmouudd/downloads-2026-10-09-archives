"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { Project } from "@/db/schema";
import { PRIORITIES, PRIORITY_MAP, PROJECT_STATUS, PROJECT_VALUE } from "@/lib/constants";
import { createProject, deleteProject, setFocusProject, updateProject } from "@/lib/actions";

export default function ProjectsBoard({ projects }: { projects: Project[] }) {
  const router = useRouter();
  const [local, setLocal] = useState(projects);
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const [newName, setNewName] = useState("");
  const [, start] = useTransition();
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  useEffect(() => setLocal(projects), [projects]);

  function schedule(key: string, fn: () => Promise<void>) {
    const t = timers.current.get(key);
    if (t) clearTimeout(t);
    timers.current.set(key, setTimeout(async () => {
      timers.current.delete(key);
      await fn();
      if (timers.current.size === 0) start(() => router.refresh());
    }, 600));
  }

  function patch(id: number, data: Partial<Project>) {
    setLocal((prev) => prev.map((p) => (p.id !== id ? p : { ...p, ...data })));
    schedule(`p${id}`, () => updateProject(id, data as Parameters<typeof updateProject>[1]));
  }

  const focus = local.find((p) => p.isFocus);
  const queue = local.filter((p) => !p.isFocus && p.status !== "archived");
  const archived = local.filter((p) => !p.isFocus && p.status === "archived");

  return (
    <div className="space-y-6">
      <section className="card" style={{ borderColor: "var(--primary)" }}>
        <h2 className="text-lg" style={{ color: "var(--primary)" }}>المشروع المحوري الوحيد</h2>
        {focus ? (
          <ProjectCard p={focus} patch={patch} open={true} toggle={() => {}} onDelete={async () => { if (confirm("حذف المشروع المحوري؟")) { await deleteProject(focus.id); router.refresh(); } }} />
        ) : (
          <p className="text-sm mt-2" style={{ color: "var(--muted)" }}>لا يوجد مشروع محوري. اختر واحدًا من القائمة بالضغط على «اجعله المحوري».</p>
        )}
      </section>

      <section className="card">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h2 className="text-lg">قائمة الانتظار ({queue.length})</h2>
          <form
            className="flex gap-2"
            onSubmit={async (e) => { e.preventDefault(); if (!newName.trim()) return; await createProject(newName); setNewName(""); router.refresh(); }}
          >
            <input className="input" placeholder="فكرة جديدة؟ سجّلها هنا بدل أن تبدأها" value={newName} onChange={(e) => setNewName(e.target.value)} />
            <button className="btn btn-primary btn-sm" type="submit">تسجيل</button>
          </form>
        </div>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          قاعدة: الفكرة الجديدة تُسجَّل هنا خلال 60 ثانية ثم تعود إلى المهمة الأصلية. تُراجع القائمة مرة أسبوعيًا فقط.
        </p>
        <div className="mt-4 space-y-3">
          {queue.map((p) => (
            <ProjectCard
              key={p.id}
              p={p}
              patch={patch}
              open={open[p.id] ?? false}
              toggle={() => setOpen((o) => ({ ...o, [p.id]: !(o[p.id] ?? false) }))}
              onFocus={async () => { if (confirm(`جعل «${p.name}» المشروع المحوري الوحيد؟ سيُزال التركيز عن المشروع الحالي.`)) { await setFocusProject(p.id); router.refresh(); } }}
              onDelete={async () => { if (confirm(`حذف «${p.name}»؟`)) { await deleteProject(p.id); router.refresh(); } }}
            />
          ))}
        </div>
      </section>

      {archived.length > 0 && (
        <section className="card">
          <h2 className="text-lg" style={{ color: "var(--muted)" }}>المؤرشف ({archived.length})</h2>
          <div className="mt-3 space-y-3">
            {archived.map((p) => (
              <ProjectCard key={p.id} p={p} patch={patch} open={open[p.id] ?? false} toggle={() => setOpen((o) => ({ ...o, [p.id]: !(o[p.id] ?? false) }))} onDelete={async () => { if (confirm("حذف نهائي؟")) { await deleteProject(p.id); router.refresh(); } }} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function ProjectCard({ p, patch, open, toggle, onFocus, onDelete }: {
  p: Project;
  patch: (id: number, d: Partial<Project>) => void;
  open: boolean;
  toggle: () => void;
  onFocus?: () => void;
  onDelete: () => void;
}) {
  const pr = PRIORITY_MAP[p.priority];
  const st = PROJECT_STATUS.find((s) => s.key === p.status)?.label ?? p.status;
  return (
    <article className="card-soft">
      <div className="flex flex-wrap items-center gap-2">
        <input className="input flex-1 min-w-[12rem] font-semibold" value={p.name} onChange={(e) => patch(p.id, { name: e.target.value })} />
        <span className={`chip ${pr?.cls ?? "chip-muted"}`}>{pr?.label ?? p.priority}</span>
        <span className="chip chip-muted">{st}</span>
        {!p.isFocus && <button className="btn btn-ghost btn-sm" onClick={toggle}>{open ? "طيّ" : "تفاصيل"}</button>}
        {onFocus && <button className="btn btn-secondary btn-sm" onClick={onFocus}>اجعله المحوري</button>}
        <button className="btn btn-danger btn-sm" onClick={onDelete}>حذف</button>
      </div>
      {!open && p.nextStep && <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>الخطوة التالية: {p.nextStep}</p>}
      {open && (
        <div className="grid md:grid-cols-2 gap-3 mt-3">
          <Field label="الفكرة"><textarea className="textarea" value={p.idea ?? ""} onChange={(e) => patch(p.id, { idea: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الحالة">
              <select className="select" value={p.status} onChange={(e) => patch(p.id, { status: e.target.value })}>{PROJECT_STATUS.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
            </Field>
            <Field label="الأولوية">
              <select className="select" value={p.priority} onChange={(e) => patch(p.id, { priority: e.target.value })}>{PRIORITIES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
            </Field>
            <Field label="القيمة المحتملة">
              <select className="select" value={p.value} onChange={(e) => patch(p.id, { value: e.target.value })}>{PROJECT_VALUE.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
            </Field>
            <Field label="ساعات الإصلاح المتوقعة">
              <input type="number" min={0} className="input" placeholder="؟" value={p.fixHours ?? ""} onChange={(e) => patch(p.id, { fixHours: e.target.value === "" ? null : Number(e.target.value) })} />
            </Field>
          </div>
          <Field label="ما الذي يعمل؟"><textarea className="textarea" value={p.works ?? ""} onChange={(e) => patch(p.id, { works: e.target.value })} /></Field>
          <Field label="ما الذي ينقصه؟"><textarea className="textarea" value={p.missing ?? ""} onChange={(e) => patch(p.id, { missing: e.target.value })} /></Field>
          <div className="md:col-span-2">
            <Field label="الخطوة التالية (10–20 دقيقة بمخرج واضح)"><input className="input" value={p.nextStep ?? ""} onChange={(e) => patch(p.id, { nextStep: e.target.value })} /></Field>
          </div>
        </div>
      )}
    </article>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}
