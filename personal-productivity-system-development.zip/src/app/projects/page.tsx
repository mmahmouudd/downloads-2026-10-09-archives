import { getProjects } from "@/lib/data";
import ProjectsBoard from "./ProjectsBoard";

export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const projects = await getProjects();
  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>المشاريع والأفكار</p>
        <h1 className="text-2xl md:text-3xl mt-1">مشروع واحد يُنجَز، والباقي ينتظر</h1>
        <p className="mt-2 max-w-3xl" style={{ color: "var(--muted)" }}>
          جرد موحد لكل مشروع: الفكرة، الحالة، ما يعمل، ما ينقص، وقت الإصلاح، القيمة المحتملة، والخطوة التالية.
          لا يمكن أن يكون هناك أكثر من مشروع محوري واحد في الوقت نفسه.
        </p>
      </header>
      <ProjectsBoard projects={projects} />
    </div>
  );
}
