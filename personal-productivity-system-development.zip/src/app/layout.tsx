import type { Metadata } from "next";
import type { ReactNode } from "react";
import Nav from "@/components/Nav";
import "./globals.css";

export const metadata: Metadata = {
  title: "168 ساعة — منظّم الوقت والحياة والدراسة",
  description: "أداة مرنة لتوزيع 168 ساعة أسبوعيًا على النوم والدراسة والمشاريع والحياة اليومية، مع متابعة التراكم الدراسي والطاقة.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen">
        <Nav />
        <main className="container-x py-6 md:py-8">{children}</main>
        <footer className="container-x py-8 text-sm" style={{ color: "var(--muted)" }}>
          البيانات تُحفظ في قاعدة بيانات هذا الخادم المحلي بلا تسجيل دخول. الأرقام والتقييمات هنا أداة ملاحظة، وليست تشخيصًا طبيًا أو نفسيًا.
        </footer>
      </body>
    </html>
  );
}
