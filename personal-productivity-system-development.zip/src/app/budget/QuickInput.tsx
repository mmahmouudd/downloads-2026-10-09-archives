"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { parseNaturalText, type ParsedActivity } from "@/lib/parse";
import { SECTIONS } from "@/lib/constants";
import { createActivity } from "@/lib/actions";
import { round1 } from "@/lib/calc";

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: unknown) => void) | null;
  start: () => void;
  stop: () => void;
};

const EXAMPLE = "أنام 6 ساعات في ثلاثة أيام، و10 ساعات في يومين، و14 ساعة في يومين. أدرس في الكلية يومًا حضوريًا 5 ساعات ويوم أونلاين 3 ساعات. أصلي ساعة وربع كل يوم. تيك توك ساعتين كل يوم.";

export default function QuickInput() {
  const router = useRouter();
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<ParsedActivity[] | null>(null);
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(false);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const recRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    setSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
  }, []);

  function startVoice() {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return;
    const rec = new Ctor();
    rec.lang = "ar-EG";
    rec.interimResults = true;
    rec.continuous = true;
    let finalText = text ? text + " " : "";
    rec.onresult = (e) => {
      let interim = "";
      let finals = "";
      for (let i = 0; i < e.results.length; i++) {
        const r = e.results[i] as unknown as { isFinal?: boolean; 0: { transcript: string } };
        if (r.isFinal) finals += r[0].transcript + " ";
        else interim += r[0].transcript;
      }
      setText((finalText + finals + interim).trim());
    };
    rec.onend = () => { setListening(false); finalText = ""; };
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  }

  function stopVoice() {
    recRef.current?.stop();
    setListening(false);
  }

  function analyze() {
    setParsed(parseNaturalText(text));
  }

  function patch(i: number, data: Partial<ParsedActivity>) {
    setParsed((prev) => prev?.map((p, idx) => (idx === i ? { ...p, ...data } : p)) ?? prev);
  }
  function patchPattern(i: number, j: number, data: Partial<ParsedActivity["patterns"][number]>) {
    setParsed((prev) =>
      prev?.map((p, idx) => (idx === i ? { ...p, patterns: p.patterns.map((pt, jj) => (jj === j ? { ...pt, ...data } : pt)) } : p)) ?? prev,
    );
  }

  async function apply() {
    if (!parsed) return;
    const invalid = parsed.some((p) => p.patterns.some((pt) => pt.hoursPerDay === null));
    if (invalid) {
      alert("يوجد نمط بدون عدد ساعات. أكمل الحقول الفارغة أولًا.");
      return;
    }
    setSaving(true);
    for (const p of parsed) {
      await createActivity({
        sectionKey: p.sectionKey,
        name: p.name,
        patterns: p.patterns.map((pt) => ({ hoursPerDay: pt.hoursPerDay ?? 0, days: pt.days, weekdays: pt.weekdays ?? null })),
      });
    }
    setSaving(false);
    setParsed(null);
    setText("");
    router.refresh();
  }

  return (
    <section className="card">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h2 className="text-lg">إدخال سريع بالكلام أو الكتابة</h2>
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            اكتب أو انطق وصفًا طبيعيًا، وسنعرض ما فهمناه لتصححه قبل اعتماده.
          </p>
        </div>
        <button className="btn btn-secondary btn-sm" onClick={() => setOpen((v) => !v)}>{open ? "إغلاق" : "فتح الإدخال السريع"}</button>
      </div>

      {open && (
        <div className="mt-4 space-y-3">
          <textarea
            className="textarea"
            rows={4}
            placeholder={EXAMPLE}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="flex flex-wrap gap-2 items-center">
            <button className="btn btn-primary" onClick={analyze} disabled={!text.trim()}>تحليل النص</button>
            {supported ? (
              listening ? (
                <button className="btn btn-secondary" onClick={stopVoice}>■ إيقاف الاستماع</button>
              ) : (
                <button className="btn btn-secondary" onClick={startVoice}>🎤 تحدّث</button>
              )
            ) : (
              <span className="text-sm" style={{ color: "var(--muted)" }}>المتصفح لا يدعم التعرف على الكلام؛ استخدم الكتابة.</span>
            )}
            <button className="btn btn-ghost btn-sm" onClick={() => setText(EXAMPLE)}>جرّب مثالًا</button>
          </div>
          <p className="alert alert-info text-sm">
            التحليل يتم محليًا في المتصفح بقواعد لغوية بسيطة (بدون أي نموذج ذكاء اصطناعي أو API خارجي). التعرف على الكلام يستخدم ميزة المتصفح نفسها (Chrome/Edge غالبًا)، وقد تُرسل الصوت إلى خدمة المتصفح لتحويله إلى نص.
          </p>

          {parsed && (
            <div className="card-soft">
              <h3 className="font-bold">ما فهمته — راجع وصحّح ثم اعتمد</h3>
              {parsed.length === 0 && <p className="text-sm mt-2">لم أتعرف على أي نمط «ساعات × أيام». جرّب صيغة مثل: «أنام 7 ساعات في 5 أيام».</p>}
              <div className="space-y-3 mt-3">
                {parsed.map((p, i) => (
                  <div key={i} className="rounded-xl p-3" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
                    <div className="flex flex-wrap gap-2 items-center">
                      <input className="input flex-1 min-w-[10rem]" value={p.name} onChange={(e) => patch(i, { name: e.target.value })} />
                      <select className="select w-auto" value={p.sectionKey} onChange={(e) => patch(i, { sectionKey: e.target.value as ParsedActivity["sectionKey"] })}>
                        {SECTIONS.map((s) => <option key={s.key} value={s.key}>{s.title}</option>)}
                      </select>
                      <span className={`chip ${p.confidence === "high" ? "chip-ok" : p.confidence === "medium" ? "chip-optional" : "chip-urgent"}`}>
                        ثقة {p.confidence === "high" ? "عالية" : p.confidence === "medium" ? "متوسطة" : "منخفضة"}
                      </span>
                      <button className="btn btn-danger btn-sm" onClick={() => setParsed((prev) => prev?.filter((_, idx) => idx !== i) ?? prev)}>إزالة</button>
                    </div>
                    <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>من النص: «{p.raw}»</p>
                    <div className="mt-2 space-y-2">
                      {p.patterns.map((pt, j) => (
                        <div key={j} className="flex flex-wrap items-center gap-2 text-sm">
                          <input
                            type="number" min={0} max={24} step={0.25}
                            className="input input-num"
                            placeholder="ساعات"
                            value={pt.hoursPerDay ?? ""}
                            style={pt.hoursPerDay === null ? { borderColor: "var(--danger)" } : undefined}
                            onChange={(e) => patchPattern(i, j, { hoursPerDay: e.target.value === "" ? null : Number(e.target.value) })}
                          />
                          <span>ساعة/يوم ×</span>
                          <input
                            type="number" min={0} max={7}
                            className="input input-num"
                            value={pt.days}
                            onChange={(e) => patchPattern(i, j, { days: Math.min(7, Math.max(0, Math.round(Number(e.target.value)))) })}
                          />
                          <span>أيام = <strong>{round1((pt.hoursPerDay ?? 0) * pt.days)} س</strong></span>
                          {pt.hoursPerDay === null && <span className="chip chip-urgent">أدخل الساعات</span>}
                        </div>
                      ))}
                      <p className="text-xs" style={{ color: "var(--muted)" }}>
                        مجموع الأيام: {p.patterns.reduce((s, x) => s + x.days, 0)} / 7
                        {p.patterns.reduce((s, x) => s + x.days, 0) > 7 && <span className="chip chip-urgent mr-2">أكثر من 7 أيام!</span>}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              {parsed.length > 0 && (
                <div className="mt-3 flex gap-2">
                  <button className="btn btn-primary" onClick={apply} disabled={saving}>{saving ? "جارٍ الحفظ…" : "اعتماد وإضافة إلى الميزانية"}</button>
                  <button className="btn btn-ghost" onClick={() => setParsed(null)}>إلغاء</button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
