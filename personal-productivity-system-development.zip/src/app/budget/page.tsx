import { getActivitiesWithPatterns, getSettings } from "@/lib/data";
import BudgetEditor from "./BudgetEditor";
import QuickInput from "./QuickInput";
import { SECTIONS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function BudgetPage() {
  const [acts, cfg] = await Promise.all([getActivitiesWithPatterns(), getSettings()]);
  const local = acts.map((a) => ({ ...a, patterns: a.patterns.map((p) => ({ ...p, id: p.id as number })) }));

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>ميزانية الأسبوع</p>
        <h1 className="text-2xl md:text-3xl mt-1">وزّع 168 ساعة كما تعيشها فعلًا</h1>
        <p className="mt-2 max-w-3xl" style={{ color: "var(--muted)" }}>
          كل نشاط يمكن أن يكون له أكثر من نمط: «ساعات في اليوم × عدد الأيام». مثال النوم: 8 ساعات × 5 أيام + 9 ساعات × يومين.
          الأرقام الحالية هي <strong>الأسبوع الأول المقترح</strong> لحالتك؛ عدّلها بحرية، فالحفظ تلقائي.
        </p>
        <nav className="mt-3 flex flex-wrap gap-1" aria-label="الانتقال إلى قسم">
          {SECTIONS.map((s) => (
            <a key={s.key} href={`#${s.key}`} className="chip chip-muted" style={{ textDecoration: "none" }}>{s.title.split(" و")[0]}</a>
          ))}
        </nav>
      </header>

      <QuickInput />
      <BudgetEditor activities={local} focusRatio={cfg.focusRatio} />
    </div>
  );
}
