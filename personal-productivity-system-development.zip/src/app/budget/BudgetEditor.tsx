"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { PRIORITIES, SECTIONS, WEEKDAYS, WEEK_HOURS } from "@/lib/constants";
import { activityDays, activityHours, fmtH, patternHours, round1, summarizeWeek, type ActivityLike, type PatternLike } from "@/lib/calc";
import { addPattern, createActivity, deleteActivity, deletePattern, saveSetting, updateActivity, updatePattern } from "@/lib/actions";

type LocalPattern = PatternLike & { id: number };
type LocalActivity = Omit<ActivityLike, "patterns"> & { patterns: LocalPattern[] };

export default function BudgetEditor({ activities, focusRatio }: { activities: LocalActivity[]; focusRatio: number }) {
  const router = useRouter();
  const [local, setLocal] = useState<LocalActivity[]>(activities);
  const [ratio, setRatio] = useState(focusRatio);
  const [openNotes, setOpenNotes] = useState<Record<number, boolean>>({});
  const [, startTransition] = useTransition();
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  useEffect(() => setLocal(activities), [activities]);
  useEffect(() => setRatio(focusRatio), [focusRatio]);

  const summary = useMemo(() => summarizeWeek(local, ratio), [local, ratio]);

  function schedule(key: string, fn: () => Promise<void>) {
    const existing = timers.current.get(key);
    if (existing) clearTimeout(existing);
    timers.current.set(
      key,
      setTimeout(async () => {
        timers.current.delete(key);
        await fn();
        if (timers.current.size === 0) startTransition(() => router.refresh());
      }, 600),
    );
  }

  function patchPattern(aId: number, pId: number, data: Partial<LocalPattern>) {
    setLocal((prev) =>
      prev.map((a) =>
        a.id !== aId
          ? a
          : { ...a, patterns: a.patterns.map((p) => (p.id !== pId ? p : { ...p, ...data })) },
      ),
    );
    schedule(`p${pId}`, () => updatePattern(pId, data));
  }

  function patchActivity(aId: number, data: Partial<Pick<LocalActivity, "name" | "priority" | "note">>) {
    setLocal((prev) => prev.map((a) => (a.id !== aId ? a : { ...a, ...data })));
    schedule(`a${aId}`, () => updateActivity(aId, data));
  }

  async function onAddActivity(sectionKey: string) {
    const name = window.prompt("اسم النشاط الجديد:");
    if (name === null) return;
    await createActivity({ sectionKey, name: name || "نشاط جديد" });
    router.refresh();
  }

  async function onDeleteActivity(id: number, name: string) {
    if (!window.confirm(`حذف «${name}» وكل أنماطه؟`)) return;
    setLocal((prev) => prev.filter((a) => a.id !== id));
    await deleteActivity(id);
    router.refresh();
  }

  async function onAddPattern(aId: number) {
    await addPattern(aId);
    router.refresh();
  }

  async function onDeletePattern(aId: number, pId: number) {
    setLocal((prev) => prev.map((a) => (a.id !== aId ? a : { ...a, patterns: a.patterns.filter((p) => p.id !== pId) })));
    await deletePattern(pId);
    router.refresh();
  }

  function toggleWeekday(aId: number, p: LocalPattern, d: number) {
    const cur = new Set(p.weekdays ?? []);
    if (cur.has(d)) cur.delete(d);
    else cur.add(d);
    const arr = [...cur].sort((x, y) => x - y);
    const weekdays = arr.length > 0 ? arr : null;
    patchPattern(aId, p.id, { weekdays, days: weekdays ? weekdays.length : p.days });
  }

  return (
    <div className="space-y-6">
      {/* ملخص لاصق */}
      <div className="card sticky top-[64px] z-10 shadow-md" style={{ borderColor: summary.overflow ? "var(--danger)" : "var(--line)" }}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 items-end">
          <div>
            <p className="text-xs" style={{ color: "var(--muted)" }}>الموزَّع</p>
            <p className="stat-num text-2xl">{round1(summary.total)}<span className="text-sm font-normal"> / {WEEK_HOURS}</span></p>
          </div>
          <div>
            <p className="text-xs" style={{ color: "var(--muted)" }}>{summary.overflow ? "التجاوز" : "غير الموزَّع"}</p>
            <p className="stat-num text-2xl" style={summary.overflow ? { color: "var(--danger)" } : undefined}>{round1(Math.abs(summary.unallocated))}</p>
          </div>
          <div>
            <p className="text-xs" style={{ color: "var(--muted)" }}>قابل للتركيز فعليًا</p>
            <p className="stat-num text-2xl" style={{ color: "var(--primary)" }}>{round1(summary.realisticFocus)}</p>
          </div>
          <div>
            <label className="text-xs block" style={{ color: "var(--muted)" }} htmlFor="ratio">
              نسبة ما يمكن تركيزه من الوقت الفارغ: {Math.round(ratio * 100)}%
            </label>
            <input
              id="ratio"
              type="range"
              min={0.2}
              max={0.9}
              step={0.05}
              value={ratio}
              onChange={(e) => {
                const v = Number(e.target.value);
                setRatio(v);
                schedule("ratio", () => saveSetting("focusRatio", v));
              }}
            />
          </div>
        </div>
        <div className="bar mt-3" aria-hidden>
          <span style={{ width: `${Math.min(100, (summary.total / WEEK_HOURS) * 100)}%`, background: summary.overflow ? "var(--danger)" : "var(--primary)" }} />
        </div>
        {summary.alerts.length > 0 && (
          <ul className="mt-3 flex flex-wrap gap-2">
            {summary.alerts.map((a, i) => (
              <li key={i} className="chip chip-urgent" style={{ whiteSpace: "normal" }}>{a}</li>
            ))}
          </ul>
        )}
      </div>

      {/* الأقسام */}
      {SECTIONS.map((sec) => {
        const acts = local.filter((a) => a.sectionKey === sec.key);
        const secHours = acts.reduce((s, a) => s + activityHours(a), 0);
        return (
          <section key={sec.key} className="card" id={sec.key}>
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="flex items-start gap-3">
                <span aria-hidden className="mt-2 inline-block h-3 w-3 rounded-full shrink-0" style={{ background: sec.color }} />
                <div>
                  <h2 className="text-lg">{sec.title}</h2>
                  <p className="text-sm" style={{ color: "var(--muted)" }}>{sec.hint}</p>
                </div>
              </div>
              <div className="text-left">
                <p className="stat-num text-xl">{fmtH(secHours)}</p>
                <p className="text-xs" style={{ color: "var(--muted)" }}>{Math.round((secHours / WEEK_HOURS) * 100)}% من الأسبوع</p>
              </div>
            </div>

            <div className="mt-4 space-y-4">
              {acts.length === 0 && (
                <p className="text-sm card-soft" style={{ color: "var(--muted)" }}>لا توجد أنشطة هنا بعد.</p>
              )}
              {acts.map((a) => {
                const h = activityHours(a);
                const d = activityDays(a);
                const tooMany = d > 7;
                return (
                  <article key={a.id} className="card-soft" style={tooMany ? { borderColor: "var(--danger)" } : undefined}>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        className="input flex-1 min-w-[12rem] font-semibold"
                        value={a.name}
                        aria-label="اسم النشاط"
                        onChange={(e) => patchActivity(a.id, { name: e.target.value })}
                      />
                      <select
                        className="select w-auto"
                        value={a.priority}
                        aria-label="الأولوية"
                        onChange={(e) => patchActivity(a.id, { priority: e.target.value })}
                      >
                        {PRIORITIES.map((p) => (
                          <option key={p.key} value={p.key}>{p.label}</option>
                        ))}
                      </select>
                      <div className="text-sm px-2" style={{ fontVariantNumeric: "tabular-nums" }}>
                        <strong>{fmtH(h)}</strong>
                        <span style={{ color: tooMany ? "var(--danger)" : "var(--muted)" }}> · {d} / 7 أيام</span>
                      </div>
                      <button className="btn btn-ghost btn-sm" onClick={() => setOpenNotes((o) => ({ ...o, [a.id]: !o[a.id] }))}>
                        {openNotes[a.id] ? "إخفاء الملاحظة" : a.note ? "ملاحظة ▾" : "+ ملاحظة"}
                      </button>
                      <button className="btn btn-danger btn-sm" onClick={() => onDeleteActivity(a.id, a.name)}>حذف</button>
                    </div>
                    {openNotes[a.id] && (
                      <textarea
                        className="textarea mt-2"
                        placeholder="ملاحظة قصيرة: لماذا هذا الرقم؟ ما المخرج المتوقع؟"
                        value={a.note ?? ""}
                        onChange={(e) => patchActivity(a.id, { note: e.target.value })}
                      />
                    )}
                    {!openNotes[a.id] && a.note && (
                      <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>{a.note}</p>
                    )}
                    {tooMany && (
                      <p className="alert alert-danger mt-2 text-sm">مجموع الأيام ({d}) أكبر من 7. قلّل أيام أحد الأنماط.</p>
                    )}
                    {d < 7 && d > 0 && (
                      <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>متبقٍ {7 - d} أيام لم تُوزَّع لهذا النشاط (قد يكون مقصودًا).</p>
                    )}

                    <div className="mt-3 space-y-3">
                      {a.patterns.map((p) => (
                        <PatternRow
                          key={p.id}
                          p={p}
                          onChange={(data) => patchPattern(a.id, p.id, data)}
                          onToggleDay={(dd) => toggleWeekday(a.id, p, dd)}
                          onDelete={() => onDeletePattern(a.id, p.id)}
                          canDelete={a.patterns.length > 1}
                        />
                      ))}
                      <button className="btn btn-secondary btn-sm" onClick={() => onAddPattern(a.id)}>+ نمط آخر لهذا النشاط</button>
                    </div>
                  </article>
                );
              })}
              <button className="btn btn-ghost" onClick={() => onAddActivity(sec.key)}>+ إضافة نشاط في «{sec.title}»</button>
            </div>
          </section>
        );
      })}
    </div>
  );
}

function PatternRow({
  p, onChange, onToggleDay, onDelete, canDelete,
}: {
  p: LocalPattern;
  onChange: (d: Partial<LocalPattern>) => void;
  onToggleDay: (d: number) => void;
  onDelete: () => void;
  canDelete: boolean;
}) {
  const [showDays, setShowDays] = useState(Boolean(p.weekdays && p.weekdays.length > 0));
  const pinned = Boolean(p.weekdays && p.weekdays.length > 0);
  return (
    <div className="rounded-xl p-3" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>
      <div className="grid gap-3 md:grid-cols-[1fr_1fr_auto] items-end">
        <div>
          <label className="label">ساعات في اليوم</label>
          <div className="flex items-center gap-2">
            <input
              type="number" min={0} max={24} step={0.25}
              className="input input-num"
              value={p.hoursPerDay}
              onChange={(e) => onChange({ hoursPerDay: Math.min(24, Math.max(0, Number(e.target.value))) })}
            />
            <input
              type="range" min={0} max={24} step={0.25}
              value={p.hoursPerDay}
              aria-label="منزلق الساعات"
              onChange={(e) => onChange({ hoursPerDay: Number(e.target.value) })}
            />
          </div>
        </div>
        <div>
          <label className="label">عدد الأيام في الأسبوع {pinned && <span className="chip chip-muted">محدد بالأيام المختارة</span>}</label>
          <div className="flex items-center gap-2">
            <input
              type="number" min={0} max={7} step={1}
              className="input input-num"
              value={p.days}
              disabled={pinned}
              onChange={(e) => onChange({ days: Math.min(7, Math.max(0, Math.round(Number(e.target.value)))) })}
            />
            <input
              type="range" min={0} max={7} step={1}
              value={p.days}
              disabled={pinned}
              aria-label="منزلق الأيام"
              onChange={(e) => onChange({ days: Number(e.target.value) })}
            />
          </div>
        </div>
        <div className="text-left md:text-right">
          <p className="text-xs" style={{ color: "var(--muted)" }}>المجموع</p>
          <p className="font-bold text-lg" style={{ fontVariantNumeric: "tabular-nums" }}>{round1(patternHours(p))} س</p>
        </div>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <input
          className="input flex-1 min-w-[10rem]"
          placeholder="وصف اختياري (مثل: أيام الكلية)"
          value={p.label ?? ""}
          onChange={(e) => onChange({ label: e.target.value })}
        />
        <button className="btn btn-ghost btn-sm" onClick={() => setShowDays((v) => !v)}>
          {showDays ? "إخفاء الأيام" : "تثبيت على أيام محددة"}
        </button>
        {canDelete && <button className="btn btn-danger btn-sm" onClick={onDelete}>حذف النمط</button>}
      </div>
      {showDays && (
        <div className="mt-2 flex flex-wrap gap-1" role="group" aria-label="أيام الأسبوع">
          {WEEKDAYS.map((name, i) => (
            <button key={i} type="button" className="day-toggle" aria-pressed={p.weekdays?.includes(i) ?? false} onClick={() => onToggleDay(i)}>
              {name}
            </button>
          ))}
          <span className="text-xs self-center" style={{ color: "var(--muted)" }}>اختيار الأيام يضبط العدد تلقائيًا ويُظهر التداخل في ملخص الأيام.</span>
        </div>
      )}
    </div>
  );
}
