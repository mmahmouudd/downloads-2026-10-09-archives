import { db } from "@/db";
import { activities, dailyLogs, patterns, projects, settings, studyItems, studySources } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { ensureSeeded } from "./seed";
import type { ActivityLike } from "./calc";

export async function getSettings(): Promise<{ focusRatio: number; deepWorkGoal: number }> {
  await ensureSeeded();
  const rows = await db.select().from(settings);
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    focusRatio: typeof map.focusRatio === "number" ? map.focusRatio : 0.5,
    deepWorkGoal: typeof map.deepWorkGoal === "number" ? map.deepWorkGoal : 6,
  };
}

export async function getActivitiesWithPatterns(): Promise<ActivityLike[]> {
  await ensureSeeded();
  const acts = await db.select().from(activities).orderBy(asc(activities.sortOrder), asc(activities.id));
  const pats = await db.select().from(patterns).orderBy(asc(patterns.sortOrder), asc(patterns.id));
  return acts.map((a) => ({
    id: a.id,
    sectionKey: a.sectionKey,
    name: a.name,
    priority: a.priority,
    note: a.note,
    patterns: pats
      .filter((p) => p.activityId === a.id)
      .map((p) => ({ id: p.id, hoursPerDay: p.hoursPerDay, days: p.days, weekdays: p.weekdays ?? null, label: p.label })),
  }));
}

export async function getStudyBoard() {
  await ensureSeeded();
  const sources = await db.select().from(studySources).orderBy(asc(studySources.sortOrder), asc(studySources.id));
  const items = await db.select().from(studyItems).orderBy(asc(studyItems.sortOrder), asc(studyItems.id));
  return sources.map((s) => ({ ...s, items: items.filter((i) => i.sourceId === s.id) }));
}

export async function getProjects() {
  await ensureSeeded();
  return db.select().from(projects).orderBy(desc(projects.isFocus), asc(projects.id));
}

export async function getLogs(limit = 30) {
  await ensureSeeded();
  return db.select().from(dailyLogs).orderBy(desc(dailyLogs.logDate)).limit(limit);
}

export async function getLogByDate(d: string) {
  const rows = await db.select().from(dailyLogs).where(eq(dailyLogs.logDate, d)).limit(1);
  return rows[0] ?? null;
}
