import { db } from "@/db";
import { activities, patterns, projects, settings, studyItems, studySources } from "@/db/schema";
import { eq } from "drizzle-orm";

// أيام الأسبوع: 0 السبت، 1 الأحد، 2 الاثنين، 3 الثلاثاء، 4 الأربعاء، 5 الخميس، 6 الجمعة
type SeedActivity = {
  sectionKey: string;
  name: string;
  priority: string;
  note?: string;
  patterns: { hoursPerDay: number; days: number; weekdays?: number[]; label?: string }[];
};

// ميزانية «الأسبوع الأول المقترح» — قابلة للتعديل بالكامل من صفحة الميزانية.
const WEEK_ONE: SeedActivity[] = [
  {
    sectionKey: "sleep", name: "النوم", priority: "urgent",
    note: "هدف الأسبوع الأول: تثبيت وقت الاستيقاظ لا وقت النوم. المدى 7.5–9 ساعات، ولا نرجع إلى 4–6.",
    patterns: [
      { hoursPerDay: 8, days: 5, label: "أيام الأسبوع" },
      { hoursPerDay: 9, days: 2, label: "يومان أطول (تعويض معقول)" },
    ],
  },
  {
    sectionKey: "study_mandatory", name: "يوم الحضور في الكلية", priority: "urgent",
    note: "مدة الحضور تقديرية؛ عدّلها حسب جدولك الفعلي.",
    patterns: [{ hoursPerDay: 5, days: 1, weekdays: [2], label: "حضوري" }],
  },
  {
    sectionKey: "study_mandatory", name: "يوم الكلية أونلاين", priority: "urgent",
    patterns: [{ hoursPerDay: 3, days: 1, weekdays: [4], label: "أونلاين" }],
  },
  {
    sectionKey: "study_mandatory", name: "تصفية التراكم الجامعي (18 محاضرة)", priority: "urgent",
    note: "جلسة 25 دقيقة + 5 راحة × 3 = 1.5 ساعة. المخرج: نصف محاضرة على الأقل + 5 أسئلة.",
    patterns: [{ hoursPerDay: 1.5, days: 5, label: "جلسات التعويض" }],
  },
  {
    sectionKey: "study_extra", name: "أكاديمية زاد — حصر ثم متابعة", priority: "important",
    note: "الأسبوع الأول: حصر المحاضرات المتاحة وما شوهد منها، ثم محاضرة واحدة فقط.",
    patterns: [{ hoursPerDay: 1, days: 3 }],
  },
  {
    sectionKey: "study_extra", name: "أوزون برو ماكس (د. حازم شومان) — حصر فقط", priority: "optional",
    note: "لا متابعة هذا الأسبوع؛ فقط معرفة الاسم الصحيح والجدول وعدد المحاضرات.",
    patterns: [{ hoursPerDay: 0.5, days: 1 }],
  },
  {
    sectionKey: "study_extra", name: "ماكنزي + 2B — التحقق من التفاصيل", priority: "deferred",
    note: "خانة مؤقتة: هل هناك قبول فعلي؟ لغة المحتوى؟ تكاليف؟ محاضرات أسبوعية؟",
    patterns: [{ hoursPerDay: 0.5, days: 1 }],
  },
  {
    sectionKey: "worship", name: "الصلوات الخمس (مع الذهاب للمسجد القريب)", priority: "urgent",
    note: "ابدأ بالفجر والعشاء في المسجد؛ البقية في وقتها ولو في البيت.",
    patterns: [{ hoursPerDay: 1.25, days: 7 }],
  },
  {
    sectionKey: "worship", name: "ورد قرآن قصير", priority: "important",
    note: "10 دقائق بعد الفجر. كنت تحفظ صفحة في 5 دقائق؛ نبدأ بالتلاوة فقط.",
    patterns: [{ hoursPerDay: 0.2, days: 7 }],
  },
  {
    sectionKey: "food", name: "وجبتان ثابتتان + ماء", priority: "urgent",
    note: "وجبة بعد الفجر ووجبة مع الأهل. كوب ماء مع كل صلاة = 5 أكواب كحد أدنى.",
    patterns: [{ hoursPerDay: 1.5, days: 7 }],
  },
  {
    sectionKey: "care", name: "روتين العناية الأدنى", priority: "important",
    note: "يوميًا: أسنان + غسل وجه + ملابس داخلية نظيفة. استحمام يوم بعد يوم.",
    patterns: [{ hoursPerDay: 0.5, days: 7 }],
  },
  {
    sectionKey: "sport", name: "مشي 15–20 دقيقة (بعد صلاة)", priority: "important",
    note: "المسجد 100 متر؛ أكمل المشي بعد العصر أو الفجر. بلا جيم الآن.",
    patterns: [{ hoursPerDay: 0.33, days: 5 }],
  },
  {
    sectionKey: "family", name: "جلوس مع الأهل + مهمة منزلية واحدة", priority: "important",
    note: "ترتيب الغرفة كان بداية. أضف مهمة واحدة يوميًا (غسيل أطباق/شراء شيء).",
    patterns: [{ hoursPerDay: 1, days: 7 }],
  },
  {
    sectionKey: "transport", name: "مشاوير الكلية وغيرها", priority: "important",
    patterns: [
      { hoursPerDay: 1.5, days: 1, weekdays: [2], label: "يوم الكلية" },
      { hoursPerDay: 0.5, days: 2, label: "مشاوير صغيرة" },
    ],
  },
  {
    sectionKey: "projects", name: "المشروع المحوري: Portfolio من 3 مشاريع", priority: "important",
    note: "جلسة واحدة يوميًا، تنتهي بمخرج محدد. أول خطوة: جرد 10 مشاريع في 20 دقيقة.",
    patterns: [{ hoursPerDay: 1, days: 5 }],
  },
  {
    sectionKey: "work", name: "العمل الحر / الدخل", priority: "deferred",
    note: "مؤجل حتى يكتمل الـ Portfolio ويُصفّى التراكم الجامعي. صفر ساعات مقصود.",
    patterns: [{ hoursPerDay: 0, days: 0 }],
  },
  {
    sectionKey: "entertainment", name: "ترفيه وسوشيال (محدود ومعلن)", priority: "optional",
    note: "ليس ممنوعًا؛ لكنه بعد المخرج اليومي وليس أول ساعة بعد الاستيقاظ ولا قبل النوم.",
    patterns: [{ hoursPerDay: 1.5, days: 7 }],
  },
  {
    sectionKey: "buffer", name: "راحة + طوارئ + انتقالات بين المهام", priority: "important",
    note: "وقت حقيقي يُستهلك فعلًا؛ وجوده يمنع انهيار الجدول عند أول مفاجأة.",
    patterns: [{ hoursPerDay: 2, days: 7 }],
  },
];

const STUDY: { source: Omit<typeof studySources.$inferInsert, "id">; items: Omit<typeof studyItems.$inferInsert, "id" | "sourceId">[] }[] = [
  {
    source: {
      name: "الكلية (9 مواد)", kind: "mandatory", sortOrder: 0,
      notes: "ذكرت نحو 18 محاضرة خلال أسبوعين لم تُذاكر. يوم حضوري + يوم أونلاين أسبوعيًا.",
      unknowns: "أسماء المواد التسع، مدة كل محاضرة، مواعيد الامتحانات/التسليمات، هل توجد تكليفات متأخرة.",
      nextStep: "20 دقيقة: اكتب اسم كل مادة وعدد محاضراتها المتأخرة في هذه اللوحة.",
    },
    items: Array.from({ length: 9 }, (_, i) => ({
      name: `المادة ${i + 1} (اكتب الاسم)`,
      totalLectures: 2,
      doneLectures: 0,
      lectureMinutes: null,
      mode: "watch_solve_review",
      status: "not_started",
      notes: "تقدير أولي: 18 محاضرة ÷ 9 مواد = 2 لكل مادة. عدّل الرقم الحقيقي.",
      sortOrder: i,
    })),
  },
  {
    source: {
      name: "أكاديمية زاد — المستوى الأول", kind: "optional", sortOrder: 1,
      notes: "تم القبول. تراكم نحو 8–9 أسابيع.",
      unknowns: "عدد المواد في المستوى، عدد المحاضرات المنشورة حتى الآن، هل توجد اختبارات بمواعيد نهائية، مدة المحاضرة.",
      nextStep: "15 دقيقة: افتح المنصة، اكتب أسماء المواد وعدد المحاضرات المتاحة في كل مادة هنا.",
    },
    items: [{ name: "(أضف مواد المستوى الأول بعد الحصر)", totalLectures: null, doneLectures: 0, lectureMinutes: null, mode: "watch", status: "not_started", sortOrder: 0 }],
  },
  {
    source: {
      name: "أوزون برو ماكس (محاضرات د. حازم شومان)", kind: "optional", sortOrder: 2,
      notes: "الاسم كما ورد في ملاحظاتك دون افتراض تفاصيل. مجموعة Telegram تنشر المحاضرات.",
      unknowns: "الاسم الرسمي، هل هو برنامج بجدول أم مكتبة مفتوحة، عدد المحاضرات، هل يوجد التزام زمني.",
      nextStep: "10 دقائق: افتح المجموعة واعرف الاسم الرسمي وعدد المحاضرات المنشورة.",
    },
    items: [],
  },
  {
    source: {
      name: "ماكنزي (McKinsey) — برنامج/أكاديمية", kind: "optional", sortOrder: 3,
      notes: "لا تفاصيل مؤكدة.",
      unknowns: "هل القبول مؤكد؟ المحتوى بالعربية أم بالإنجليزية؟ هل توجد تكاليف؟ محاضرات أسبوعية؟ مدة البرنامج؟",
      nextStep: "10 دقائق: ابحث في بريدك الإلكتروني عن رسالة القبول واقرأ الشروط.",
    },
    items: [],
  },
  {
    source: {
      name: "2B (خانة مؤقتة)", kind: "optional", sortOrder: 4,
      notes: "الاسم الكامل وطبيعة البرنامج غير واضحين في ملاحظاتك.",
      unknowns: "ما هو؟ هل هو التزام فعلي أم فكرة؟ هل له مواعيد؟",
      nextStep: "5 دقائق: اكتب هنا ما تتذكره عنه، أو احذفه إن لم يكن التزامًا حقيقيًا.",
    },
    items: [],
  },
];

const PROJECTS: Omit<typeof projects.$inferInsert, "id">[] = [
  {
    name: "Portfolio من 3 مشاريع منشورة", status: "started", priority: "important", isFocus: true, value: "high",
    idea: "اختيار أفضل 3 مشاريع من مشاريع Vibe Coding، إصلاح واجهاتها إلى حد «مقبول»، نشر كل واحد برابط مستقل (Vercel/Netlify/GitHub Pages)، وصفحة واحدة تعرضها مع وصف صادق.",
    works: "عشرات/مئات المشاريع موجودة بالفعل؛ بعضها بخلفية تعمل.",
    missing: "جرد موحد، معايير اختيار، إصلاح الواجهة، نشر، README لكل مشروع.",
    fixHours: 15,
    nextStep: "20 دقيقة: اكتب في هذه اللوحة 10 مشاريع فقط (اسم + ماذا يعمل + ما ينقصه).",
  },
  { name: "تصفية تراكم الكلية", status: "started", priority: "urgent", isFocus: false, value: "high", idea: "ليس مشروعًا بل التزام إلزامي؛ موضوع هنا للتذكير أنه قبل كل المشاريع.", nextStep: "راجع لوحة التراكم الدراسي.", works: "", missing: "", fixHours: null },
  { name: "كتاب البيزنس (فتح مشروع في مصر) + فكرة شركة الشخص الواحد", status: "idea", priority: "deferred", value: "medium", idea: "كتاب مولّد بالذكاء الاصطناعي عن البيزنس في مصر، وبحث عن الترخيص وشركة يديرها شخص واحد.", missing: "تحرير بشري، تحقق من المعلومات القانونية، قناة بيع.", nextStep: "مؤجل حتى يكتمل الـ Portfolio.", works: "مسودة موجودة", fixHours: null },
  { name: "وكالة تعتمد على الذكاء الاصطناعي", status: "idea", priority: "deferred", value: "unknown", idea: "وكالة تنفذ أغلب المهام بالذكاء الاصطناعي وتسند المتبقي لمستقلين.", missing: "عميل واحد حقيقي أولًا، وعرض خدمة واحدة محددة.", nextStep: "مؤجل. الخطوة المنطقية قبلها: Portfolio ثم أول خدمة صغيرة مدفوعة.", works: "", fixHours: null },
  { name: "محتوى ديني بالذكاء الاصطناعي", status: "started", priority: "deferred", value: "medium", idea: "إنتاج محتوى ديني بأدوات الذكاء الاصطناعي.", missing: "نظام إنتاج ثابت، مراجعة علمية للمحتوى، قناة نشر.", nextStep: "مؤجل حتى يستقر الأسبوع الدراسي.", works: "تجارب أولية", fixHours: null },
  { name: "«مصنع برمجي» لإعادة توظيف المحتوى الرائج", status: "idea", priority: "deferred", value: "unknown", idea: "اكتشاف المقاطع الرائجة واستخراج أفكار وتحويلها إلى بودكاست/مقاطع.", missing: "إطار قانوني للملكية الفكرية (الانتشار لا يمنح حق النسخ)، تحديد مصادر مرخّصة.", nextStep: "مؤجل. إن عاد لاحقًا فبمحتوى أصلي أو مرخّص فقط.", works: "", fixHours: null },
  { name: "قصة مصورة / رواية بالذكاء الاصطناعي", status: "started", priority: "deferred", value: "low", idea: "قصة مصورة أو رواية مولّدة للبيع.", missing: "إكمال نسخة واحدة، منصة بيع، جمهور.", nextStep: "مؤجل.", works: "بداية غير مكتملة", fixHours: null },
  { name: "الكتيبات والمخرجات المتفرقة", status: "idea", priority: "deferred", value: "low", idea: "كتيبات وأعمال متفرقة لم تتحول إلى منتجات.", missing: "اختيار واحد فقط إن كان له جمهور واضح.", nextStep: "أرشفة مؤقتة.", works: "", fixHours: null },
  { name: "برنامج سطح المكتب الذي أنشأته", status: "backend_works", priority: "optional", value: "unknown", idea: "برنامج سطح مكتب واحد على الأقل تم إنشاؤه.", missing: "اختبار، وصف، لقطات شاشة.", nextStep: "مرشح ليكون أحد مشاريع الـ Portfolio الثلاثة.", works: "يعمل (حسب وصفك)", fixHours: 3 },
];

let seededInProcess = false;

export async function ensureSeeded() {
  if (seededInProcess) return;
  const row = await db.select().from(settings).where(eq(settings.key, "seeded")).limit(1);
  if (row.length > 0) {
    seededInProcess = true;
    return;
  }

  // قفل ذري: أول طلب يُدخل صف «seeded» هو الوحيد الذي يزرع البيانات (يمنع التكرار عند الطلبات المتوازية)
  const claimed = await db
    .insert(settings)
    .values({ key: "seeded", value: true })
    .onConflictDoNothing()
    .returning({ key: settings.key });
  seededInProcess = true;
  if (claimed.length === 0) return;

  await db.insert(settings).values([
    { key: "focusRatio", value: 0.5 },
    { key: "deepWorkGoal", value: 6 },
  ]).onConflictDoNothing();

  for (let i = 0; i < WEEK_ONE.length; i++) {
    const a = WEEK_ONE[i];
    const [inserted] = await db
      .insert(activities)
      .values({ sectionKey: a.sectionKey, name: a.name, priority: a.priority, note: a.note ?? null, sortOrder: i })
      .returning({ id: activities.id });
    if (a.patterns.length > 0) {
      await db.insert(patterns).values(
        a.patterns.map((p, j) => ({
          activityId: inserted.id,
          hoursPerDay: p.hoursPerDay,
          days: p.days,
          weekdays: p.weekdays ?? null,
          label: p.label ?? null,
          sortOrder: j,
        })),
      );
    }
  }

  for (const s of STUDY) {
    const [src] = await db.insert(studySources).values(s.source).returning({ id: studySources.id });
    if (s.items.length > 0) {
      await db.insert(studyItems).values(s.items.map((it) => ({ ...it, sourceId: src.id })));
    }
  }

  await db.insert(projects).values(PROJECTS);
}
