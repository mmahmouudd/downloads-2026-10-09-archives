"use server";

import { db } from "@/db";
import { activities, dailyLogs, patterns, projects, settings, studyItems, studySources } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";

const num = (v: unknown, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};
const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

function revalidateAll() {
  revalidatePath("/");
  revalidatePath("/budget");
  revalidatePath("/study");
  revalidatePath("/projects");
  revalidatePath("/daily");
}

// ---------- الإعدادات ----------
export async function saveSetting(key: string, value: number) {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } });
  revalidateAll();
}

// ---------- الأنشطة والأنماط ----------
export async function createActivity(input: { sectionKey: string; name: string; priority?: string; note?: string | null; patterns?: { hoursPerDay: number; days: number; weekdays?: number[] | null; label?: string | null }[] }) {
  const [max] = await db.select({ m: sql<number>`coalesce(max(${activities.sortOrder}),0)` }).from(activities);
  const [a] = await db
    .insert(activities)
    .values({
      sectionKey: input.sectionKey,
      name: input.name.trim() || "نشاط بلا اسم",
      priority: input.priority ?? "important",
      note: input.note ?? null,
      sortOrder: num(max?.m) + 1,
    })
    .returning({ id: activities.id });
  const pats = input.patterns && input.patterns.length > 0 ? input.patterns : [{ hoursPerDay: 1, days: 1 }];
  await db.insert(patterns).values(
    pats.map((p, i) => ({
      activityId: a.id,
      hoursPerDay: clamp(num(p.hoursPerDay), 0, 24),
      days: clamp(Math.round(num(p.days)), 0, 7),
      weekdays: p.weekdays ?? null,
      label: p.label ?? null,
      sortOrder: i,
    })),
  );
  revalidateAll();
  return a.id;
}

export async function updateActivity(id: number, data: { name?: string; priority?: string; note?: string | null; sectionKey?: string }) {
  await db.update(activities).set(data).where(eq(activities.id, id));
  revalidateAll();
}

export async function deleteActivity(id: number) {
  await db.delete(activities).where(eq(activities.id, id));
  revalidateAll();
}

export async function addPattern(activityId: number) {
  await db.insert(patterns).values({ activityId, hoursPerDay: 1, days: 1, sortOrder: 99 });
  revalidateAll();
}

export async function updatePattern(id: number, data: { hoursPerDay?: number; days?: number; weekdays?: number[] | null; label?: string | null }) {
  const set: Partial<typeof patterns.$inferInsert> = {};
  if (data.hoursPerDay !== undefined) set.hoursPerDay = clamp(num(data.hoursPerDay), 0, 24);
  if (data.days !== undefined) set.days = clamp(Math.round(num(data.days)), 0, 7);
  if (data.weekdays !== undefined) {
    set.weekdays = data.weekdays;
    if (data.weekdays && data.weekdays.length > 0) set.days = data.weekdays.length;
  }
  if (data.label !== undefined) set.label = data.label;
  await db.update(patterns).set(set).where(eq(patterns.id, id));
  revalidateAll();
}

export async function deletePattern(id: number) {
  await db.delete(patterns).where(eq(patterns.id, id));
  revalidateAll();
}

// ---------- التراكم الدراسي ----------
export async function createStudySource(name: string) {
  await db.insert(studySources).values({ name: name.trim() || "جهة جديدة", kind: "optional", sortOrder: 99 });
  revalidateAll();
}

export async function updateStudySource(id: number, data: { name?: string; kind?: string; notes?: string | null; unknowns?: string | null; nextStep?: string | null }) {
  await db.update(studySources).set(data).where(eq(studySources.id, id));
  revalidateAll();
}

export async function deleteStudySource(id: number) {
  await db.delete(studySources).where(eq(studySources.id, id));
  revalidateAll();
}

export async function createStudyItem(sourceId: number, name: string) {
  await db.insert(studyItems).values({ sourceId, name: name.trim() || "مادة جديدة", sortOrder: 99 });
  revalidateAll();
}

export async function updateStudyItem(
  id: number,
  data: Partial<{
    name: string;
    totalLectures: number | null;
    doneLectures: number;
    lectureMinutes: number | null;
    mode: string;
    status: string;
    deadline: string | null;
    reviewDate: string | null;
    notes: string | null;
  }>,
) {
  const set: Partial<typeof studyItems.$inferInsert> = { ...data };
  if (data.totalLectures !== undefined) set.totalLectures = data.totalLectures === null ? null : clamp(Math.round(num(data.totalLectures)), 0, 999);
  if (data.doneLectures !== undefined) set.doneLectures = clamp(Math.round(num(data.doneLectures)), 0, 999);
  if (data.lectureMinutes !== undefined) set.lectureMinutes = data.lectureMinutes === null ? null : clamp(Math.round(num(data.lectureMinutes)), 0, 600);
  if (data.deadline === "") set.deadline = null;
  if (data.reviewDate === "") set.reviewDate = null;
  await db.update(studyItems).set(set).where(eq(studyItems.id, id));
  revalidateAll();
}

export async function deleteStudyItem(id: number) {
  await db.delete(studyItems).where(eq(studyItems.id, id));
  revalidateAll();
}

// ---------- المشاريع ----------
export async function createProject(name: string) {
  await db.insert(projects).values({ name: name.trim() || "فكرة جديدة", status: "idea", priority: "deferred" });
  revalidateAll();
}

export async function updateProject(
  id: number,
  data: Partial<{
    name: string;
    idea: string | null;
    status: string;
    works: string | null;
    missing: string | null;
    fixHours: number | null;
    value: string;
    nextStep: string | null;
    priority: string;
  }>,
) {
  await db.update(projects).set(data).where(eq(projects.id, id));
  revalidateAll();
}

export async function setFocusProject(id: number) {
  // مشروع محوري واحد فقط في كل مرة
  await db.update(projects).set({ isFocus: false });
  await db.update(projects).set({ isFocus: true }).where(eq(projects.id, id));
  revalidateAll();
}

export async function deleteProject(id: number) {
  await db.delete(projects).where(eq(projects.id, id));
  revalidateAll();
}

// ---------- المتابعة اليومية ----------
export async function upsertDailyLog(input: {
  logDate: string;
  sleepHours: number | null;
  sleepScore: number | null;
  foodScore: number | null;
  moveScore: number | null;
  meals: number | null;
  waterCups: number | null;
  moveMinutes: number | null;
  care: Record<string, boolean>;
  prayers: number | null;
  socialMinutes: number | null;
  win: string | null;
  note: string | null;
}) {
  const values = {
    ...input,
    sleepHours: input.sleepHours === null ? null : clamp(num(input.sleepHours), 0, 24),
    sleepScore: input.sleepScore === null ? null : clamp(Math.round(num(input.sleepScore)), 1, 5),
    foodScore: input.foodScore === null ? null : clamp(Math.round(num(input.foodScore)), 1, 5),
    moveScore: input.moveScore === null ? null : clamp(Math.round(num(input.moveScore)), 1, 5),
    prayers: input.prayers === null ? null : clamp(Math.round(num(input.prayers)), 0, 5),
  };
  await db
    .insert(dailyLogs)
    .values(values)
    .onConflictDoUpdate({ target: dailyLogs.logDate, set: values });
  revalidateAll();
}

export async function deleteDailyLog(id: number) {
  await db.delete(dailyLogs).where(eq(dailyLogs.id, id));
  revalidateAll();
}
