import { SECTIONS, WEEK_HOURS, WEEKDAYS } from "./constants";

export interface PatternLike {
  id?: number;
  hoursPerDay: number;
  days: number;
  weekdays?: number[] | null;
  label?: string | null;
}

export interface ActivityLike {
  id: number;
  sectionKey: string;
  name: string;
  priority: string;
  note?: string | null;
  patterns: PatternLike[];
}

export interface ActivitySummary {
  id: number;
  name: string;
  sectionKey: string;
  hours: number;
  days: number;
  tooManyDays: boolean;
  hasNegative: boolean;
}

export interface SectionSummary {
  key: string;
  title: string;
  color: string;
  hours: number;
  share: number;
}

export interface DaySummary {
  index: number;
  name: string;
  hours: number; // ساعات مثبتة على هذا اليوم فعلًا
  over: boolean; // > 24
  items: { activity: string; hours: number }[];
}

export interface WeekSummary {
  total: number;
  unallocated: number; // قد يكون سالبًا عند التجاوز
  overflow: boolean;
  activities: ActivitySummary[];
  sections: SectionSummary[];
  days: DaySummary[];
  unpinnedHours: number; // ساعات لم تُثبّت على أيام محددة
  alerts: string[];
  topDrains: { name: string; hours: number }[];
  realisticFocus: number;
}

export const round1 = (n: number) => Math.round(n * 10) / 10;

export function patternHours(p: PatternLike) {
  return (Number(p.hoursPerDay) || 0) * (Number(p.days) || 0);
}

export function activityHours(a: ActivityLike) {
  return a.patterns.reduce((s, p) => s + patternHours(p), 0);
}

export function activityDays(a: ActivityLike) {
  return a.patterns.reduce((s, p) => s + (Number(p.days) || 0), 0);
}

export function summarizeWeek(activities: ActivityLike[], focusRatio = 0.5): WeekSummary {
  const alerts: string[] = [];
  const actSummaries: ActivitySummary[] = activities.map((a) => {
    const hours = activityHours(a);
    const days = activityDays(a);
    const tooManyDays = days > 7;
    const hasNegative = a.patterns.some((p) => p.hoursPerDay < 0 || p.days < 0);
    if (tooManyDays) alerts.push(`«${a.name}»: مجموع الأيام ${days} يتجاوز 7 أيام في الأسبوع.`);
    if (a.patterns.some((p) => p.hoursPerDay > 24)) alerts.push(`«${a.name}»: يوجد نمط فيه أكثر من 24 ساعة في اليوم.`);
    return { id: a.id, name: a.name, sectionKey: a.sectionKey, hours, days, tooManyDays, hasNegative };
  });

  const total = actSummaries.reduce((s, a) => s + a.hours, 0);
  const unallocated = WEEK_HOURS - total;
  const overflow = unallocated < 0;
  if (overflow) alerts.push(`الإجمالي ${round1(total)} ساعة يتجاوز 168 ساعة بمقدار ${round1(-unallocated)} ساعة.`);

  const sections: SectionSummary[] = SECTIONS.map((s) => {
    const hours = actSummaries.filter((a) => a.sectionKey === s.key).reduce((x, a) => x + a.hours, 0);
    return { key: s.key, title: s.title, color: s.color, hours, share: total > 0 ? hours / WEEK_HOURS : 0 };
  });

  // توزيع يومي للأنماط المثبتة على أيام
  const days: DaySummary[] = WEEKDAYS.map((name, index) => ({ index, name, hours: 0, over: false, items: [] }));
  let unpinnedHours = 0;
  for (const a of activities) {
    for (const p of a.patterns) {
      if (p.weekdays && p.weekdays.length > 0) {
        for (const d of p.weekdays) {
          if (d >= 0 && d < 7) {
            days[d].hours += Number(p.hoursPerDay) || 0;
            days[d].items.push({ activity: a.name, hours: Number(p.hoursPerDay) || 0 });
          }
        }
      } else {
        unpinnedHours += patternHours(p);
      }
    }
  }
  for (const d of days) {
    d.over = d.hours > 24;
    if (d.over) alerts.push(`يوم ${d.name}: الساعات المثبتة ${round1(d.hours)} تتجاوز 24 ساعة — يوجد تداخل.`);
  }

  const sleepHours = sections.find((s) => s.key === "sleep")?.hours ?? 0;
  if (sleepHours > 0 && sleepHours < 42) alerts.push("متوسط النوم أقل من 6 ساعات يوميًا؛ هذا ليس هدفًا صحيًا للإنتاج.");
  if (sleepHours > 70) alerts.push("متوسط النوم أعلى من 10 ساعات يوميًا؛ راجع النمط أو ناقشه مع مختص إن استمر.");

  const drainKeys = new Set(["entertainment"]);
  const topDrains = actSummaries
    .filter((a) => drainKeys.has(a.sectionKey) && a.hours > 0)
    .sort((a, b) => b.hours - a.hours)
    .slice(0, 3)
    .map((a) => ({ name: a.name, hours: a.hours }));

  const realisticFocus = Math.max(0, unallocated) * focusRatio;

  return { total, unallocated, overflow, activities: actSummaries, sections, days, unpinnedHours, alerts, topDrains, realisticFocus };
}

export function fmtH(n: number) {
  const r = round1(n);
  return `${r} س`;
}
