import type { SectionKey } from "./constants";

export interface ParsedPattern {
  hoursPerDay: number | null;
  days: number;
  weekdays?: number[];
}

export interface ParsedActivity {
  name: string;
  sectionKey: SectionKey;
  patterns: ParsedPattern[];
  confidence: "high" | "medium" | "low";
  raw: string;
}

const AR_DIGITS: Record<string, string> = {
  "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
};

// حدود الكلمات في JS لا تعمل مع العربية؛ نستخدم lookaround على نطاق الحروف العربية، مع السماح بسابقة «و».
const arWord = (alts: string) => new RegExp(`(?<![\\u0600-\\u06FF\\d])(و)?(?:${alts})(?![\\u0600-\\u06FF])`, "g");

const NUMBER_WORDS: [RegExp, number][] = [
  [arWord("نصف|نص"), 0.5],
  [arWord("ربع"), 0.25],
  [arWord("ثلث|تلت"), 0.33],
  [arWord("واحدة|واحد|وحدة"), 1],
  [arWord("اتنين|اثنين|اثنان|اثنتين|اثنتان"), 2],
  [arWord("تلاتة|تلاته|ثلاثة|ثلاثه|ثلاث|تلات"), 3],
  [arWord("اربعة|أربعة|أربعه|اربع|أربع"), 4],
  [arWord("خمسة|خمسه|خمس"), 5],
  [arWord("ستة|سته|ست"), 6],
  [arWord("سبعة|سبعه|سبع"), 7],
  [arWord("تمانية|تمانيه|ثمانية|ثمانيه|ثمان|تمان"), 8],
  [arWord("تسعة|تسعه|تسع"), 9],
  [arWord("عشرة|عشره|عشر"), 10],
  [arWord("اتناشر|اثنا عشر|اثني عشر|اتنا عشر"), 12],
];

const WEEKDAY_WORDS: [RegExp, number][] = [
  [/السبت/g, 0],
  [/الأحد|الاحد/g, 1],
  [/الاثنين|الإثنين|الاتنين/g, 2],
  [/الثلاثاء|التلات/g, 3],
  [/الأربعاء|الاربعاء|الاربع/g, 4],
  [/الخميس/g, 5],
  [/الجمعة|الجمعه/g, 6],
];

const KEYWORDS: { re: RegExp; name: string; section: SectionKey }[] = [
  { re: /نوم|أنام|انام|بنام|نايم|قيلولة/, name: "النوم", section: "sleep" },
  { re: /كلية|الكليه|جامعة|محاضر|مذاكر|أذاكر|اذاكر|بذاكر|أدرس|ادرس|بدرس|دراسة|دراسه|واجب|امتحان|مراجعة التراكم/, name: "الدراسة الجامعية", section: "study_mandatory" },
  { re: /زاد|أوزون|اوزون|برو ?ماكس|ماكنزي|2b|كورس|دورة|مساق|أكاديمية|اكاديمية/i, name: "برامج تعليمية إضافية", section: "study_extra" },
  { re: /شغل|وظيف|عمل حر|فريلانس|دخل|عميل/, name: "العمل", section: "work" },
  { re: /مشروع|برمج|كود|موقع|تطبيق|بورتفوليو|portfolio/i, name: "المشروع المحوري", section: "projects" },
  { re: /صلا|صلي|أصلي|اصلي|بصلي|مسجد|قرآن|قران|حفظ|أذكار|اذكار|عبادة|علم شرعي/, name: "الصلاة والعبادات", section: "worship" },
  { re: /أكل|اكل|آكل|طعام|وجب|فطار|غدا|عشا|ماء|مياه|شرب/, name: "الطعام والشرب", section: "food" },
  { re: /استحم|حمام|دش|عناية|أسنان|اسنان|شعر|ملابس|هدوم/, name: "العناية الشخصية", section: "care" },
  { re: /رياض|مشي|أمشي|امشي|تمرين|جيم|جري|قتالية/, name: "الرياضة والحركة", section: "sport" },
  { re: /أهل|اهل|أسرة|اسرة|عائل|أمي|امي|أبي|ابي|بيت|منزل|زيارة|أقارب|اقارب|صلة الرحم|أصدقاء|اصدقاء|اصحاب|أصحاب/, name: "الأسرة والمنزل", section: "family" },
  { re: /مشوار|مشاوير|مواصلات|طريق|تنقل|سفر/, name: "المشاوير والتنقل", section: "transport" },
  { re: /تيك ?توك|tiktok|ريلز|reels|يوتيوب|youtube|سوشيال|فيس|انستا|مانجا|مانهوا|أغاني|اغاني|ألعاب|العاب|ترفيه|تلفزيون|مسلسل|فيلم|أفلام/i, name: "الترفيه والسوشيال", section: "entertainment" },
  { re: /راحة|احتياطي|فاضي|فراغ|غير متوقع|طوارئ/, name: "راحة واحتياطي", section: "buffer" },
];

function normalize(text: string): string {
  let t = text.replace(/[٠-٩]/g, (d) => AR_DIGITS[d] ?? d);
  t = t.replace(/[\u064B-\u0652\u0640]/g, ""); // إزالة التشكيل والتطويل
  t = t.replace(/[،,;؛]/g, " | ");
  t = t.replace(/\n+/g, " | ");
  t = t.replace(/\./g, " | ");
  // الأعداد العشرية التي حُوّلت نقطتها إلى فاصل: "1.5" أصبحت "1 | 5" — نعيدها
  t = t.replace(/(\d)\s\|\s(\d)/g, "$1.$2");
  // كلمات الأعداد (مع الاحتفاظ بسابقة «و» إن وُجدت)
  for (const [re, n] of NUMBER_WORDS) t = t.replace(re, (_m, waw) => `${waw ?? ""} ${n} `);
  // المثنى
  t = t.replace(/(و)?(ساعتين|ساعتان)/g, (_m, waw) => `${waw ?? ""} 2 ساعة`);
  t = t.replace(/(و)?(يومين|يومان)/g, (_m, waw) => `${waw ?? ""} 2 يوم`);
  // كل يوم / يوميا
  t = t.replace(/كل يوم|يوميا|طول الأسبوع|طول الاسبوع|7 ايام|7 أيام/g, " 7 يوم ");
  // "ساعة" أو "يوم" بلا رقم قبلها = 1 (مع السماح بسابقة «و»)
  const bareOne = (word: RegExp) =>
    (t = t.replace(word, (m: string, pre: string, waw: string | undefined, w: string, offset: number, str: string) => {
      const before = str.slice(0, offset).trim();
      return /\d$/.test(before) ? m : `${pre}${waw ?? ""} 1 ${w}`;
    }));
  bareOne(/(^|\s)(و)?(ساعة|ساعه)(?=\s|$)/g);
  bareOne(/(^|\s)(و)?(يوم|يوما)(?=\s|$)/g);
  // "1 ساعة و 0.5" -> "1.5 ساعة" (ساعة ونص / ساعة وربع / ساعتين وثلث)
  t = t.replace(/(\d+(?:\.\d+)?)\s*(ساع\S*)\s*و\s*(0\.\d+)/g, (_m, n, s, f) => `${Number(n) + Number(f)} ${s}`);
  // "0.5 ساعة" تبقى كما هي (نص ساعة)
  return t.replace(/\s+/g, " ").trim();
}

function detectWeekdays(segment: string): number[] {
  const found = new Set<number>();
  for (const [re, idx] of WEEKDAY_WORDS) if (re.test(segment)) found.add(idx);
  return [...found].sort((a, b) => a - b);
}

/**
 * محلل محلي (قواعد نصية، بدون أي API) يحوّل وصفًا عربيًا طبيعيًا إلى أنشطة وأنماط.
 * مثال: "أنام 6 ساعات في ثلاثة أيام، و10 ساعات في يومين، و14 ساعة في يومين"
 */
export function parseNaturalText(input: string): ParsedActivity[] {
  const text = normalize(input);
  const segments = text.split("|").map((s) => s.trim()).filter(Boolean);
  const result: ParsedActivity[] = [];
  let current: ParsedActivity | null = null;

  for (const seg of segments) {
    const kw = KEYWORDS.find((k) => k.re.test(seg));
    if (kw) {
      const existing = result.find((r) => r.sectionKey === kw.section && r.name === kw.name);
      if (existing) current = existing;
      else {
        current = { name: kw.name, sectionKey: kw.section, patterns: [], confidence: "high", raw: seg };
        result.push(current);
      }
    }
    if (!current) {
      // لا نشاط معروف بعد: نحاول استنتاج قيمة رقمية ونضعها كنشاط عام منخفض الثقة
      const hasNum = /\d/.test(seg);
      if (!hasNum) continue;
      current = { name: seg.slice(0, 30), sectionKey: "buffer", patterns: [], confidence: "low", raw: seg };
      result.push(current);
    } else if (current.raw !== seg) {
      current.raw += " | " + seg;
    }

    const weekdays = detectWeekdays(seg);
    const hourMatches = [...seg.matchAll(/(\d+(?:\.\d+)?)\s*(ساع\S*)/g)].map((m) => Number(m[1]));
    const minuteMatches = [...seg.matchAll(/(\d+(?:\.\d+)?)\s*(دقيق\S*|دقايق)/g)].map((m) => Math.round((Number(m[1]) / 60) * 100) / 100);
    const dayMatches = [...seg.matchAll(/(\d+)\s*(يوم\S*|أيام|ايام)/g)].map((m) => Number(m[1]));

    const hours = [...hourMatches, ...minuteMatches];

    if (hours.length === 0 && dayMatches.length === 0 && weekdays.length === 0) continue;

    if (hours.length > 0) {
      // زاوج كل مدة بعدد الأيام الذي يليها إن وُجد، وإلا بأيام الأسبوع المذكورة، وإلا 1 يوم
      hours.forEach((h, i) => {
        const d = dayMatches[i] ?? (weekdays.length > 0 ? weekdays.length : dayMatches[0] ?? 1);
        current!.patterns.push({ hoursPerDay: h, days: Math.min(d, 7), weekdays: weekdays.length > 0 && i === 0 ? weekdays : undefined });
      });
      if (dayMatches.length > hours.length && hours.length === 1) {
        // "6 ساعات 3 أيام و 2 أيام" نادرة؛ نتجاهل الزيادة
      }
    } else {
      // أيام بلا ساعات: "يومًا حضوريًا ويومًا أونلاين" -> أنماط بدون مدة (تحتاج تأكيد)
      const totalDays = dayMatches.length > 0 ? dayMatches.reduce((a, b) => a + b, 0) : weekdays.length;
      if (totalDays > 0) {
        current.patterns.push({ hoursPerDay: null, days: Math.min(totalDays, 7), weekdays: weekdays.length > 0 ? weekdays : undefined });
        current.confidence = "medium";
      }
    }
  }

  return result.filter((r) => r.patterns.length > 0);
}
