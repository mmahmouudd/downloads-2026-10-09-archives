export const WEEK_HOURS = 168;

export const WEEKDAYS = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];

export type SectionKey =
  | "sleep"
  | "study_mandatory"
  | "study_extra"
  | "work"
  | "projects"
  | "worship"
  | "food"
  | "care"
  | "sport"
  | "family"
  | "transport"
  | "entertainment"
  | "buffer";

export interface SectionDef {
  key: SectionKey;
  title: string;
  hint: string;
  color: string; // لون هادئ لكل قسم (يستخدم في الأشرطة)
}

export const SECTIONS: SectionDef[] = [
  { key: "sleep", title: "النوم والراحة والاستشفاء", hint: "أدخل أنماط النوم الفعلية؛ لا يلزم أن تكون متساوية كل يوم.", color: "#5b7fa6" },
  { key: "study_mandatory", title: "الدراسة الإلزامية", hint: "الكلية والمحاضرات والواجبات والمراجعة والتراكمات.", color: "#1f6f6b" },
  { key: "study_extra", title: "المساقات والبرامج التعليمية الإضافية", hint: "زاد، أوزون برو ماكس، ماكنزي، 2B، وغيرها.", color: "#3b8c84" },
  { key: "work", title: "العمل والدخل والعمل الحر", hint: "وظيفة أو عمل حر أو خدمة تُقدَّم مقابل دخل.", color: "#9a6b2f" },
  { key: "projects", title: "المشاريع الشخصية والتقنية", hint: "المشروع المحوري فقط؛ البقية في قائمة الانتظار.", color: "#b07a3a" },
  { key: "worship", title: "الصلاة والعبادات والعلم الشرعي", hint: "الفروض، الذهاب للمسجد، القرآن، الأذكار.", color: "#4f7d5a" },
  { key: "food", title: "الطعام والشرب", hint: "تحضير الوجبات وتناولها وشرب الماء.", color: "#a35d4a" },
  { key: "care", title: "العناية الشخصية والنظافة والملابس", hint: "الاستحمام، الأسنان، الشعر، تغيير الملابس.", color: "#7d6a9e" },
  { key: "sport", title: "الرياضة والحركة", hint: "مشي أو تمارين خفيفة؛ ابدأ صغيرًا.", color: "#4f8a3f" },
  { key: "family", title: "الأسرة والواجبات المنزلية والاجتماعية", hint: "الجلوس مع الأهل، أعمال البيت، صلة الرحم.", color: "#9d5f7e" },
  { key: "transport", title: "المشاوير والتنقل", hint: "الذهاب للكلية والمسجد والمشاوير الأخرى.", color: "#6f7b85" },
  { key: "entertainment", title: "الترفيه والسوشيال ميديا ومصادر التشتت", hint: "سجّله بصدق؛ الهدف الملاحظة ثم التقليل التدريجي.", color: "#b0564e" },
  { key: "buffer", title: "الراحة والوقت الاحتياطي والمهام غير المتوقعة", hint: "لا تفترض أن كل وقت فارغ هو عمل عميق.", color: "#8b8f7a" },
];

export const SECTION_MAP: Record<string, SectionDef> = Object.fromEntries(SECTIONS.map((s) => [s.key, s]));

export const PRIORITIES = [
  { key: "urgent", label: "عاجل", cls: "chip-urgent" },
  { key: "important", label: "مهم", cls: "chip-important" },
  { key: "optional", label: "اختياري", cls: "chip-optional" },
  { key: "deferred", label: "مؤجل", cls: "chip-deferred" },
] as const;

export const PRIORITY_MAP = Object.fromEntries(PRIORITIES.map((p) => [p.key, p]));

export const STUDY_MODES = [
  { key: "watch", label: "مشاهدة فقط" },
  { key: "watch_solve", label: "مشاهدة + حل" },
  { key: "watch_solve_review", label: "مشاهدة + حل + مراجعة" },
] as const;

export const STUDY_STATUS = [
  { key: "not_started", label: "لم تبدأ" },
  { key: "in_progress", label: "قيد التنفيذ" },
  { key: "done", label: "مكتملة" },
] as const;

export const PROJECT_STATUS = [
  { key: "idea", label: "فكرة في الانتظار" },
  { key: "started", label: "بدأ ولم يكتمل" },
  { key: "backend_works", label: "الخلفية تعمل" },
  { key: "needs_ui", label: "يحتاج واجهة/إصلاح" },
  { key: "ready", label: "جاهز للنشر" },
  { key: "archived", label: "مؤرشف" },
] as const;

export const PROJECT_VALUE = [
  { key: "unknown", label: "غير معروفة" },
  { key: "low", label: "منخفضة" },
  { key: "medium", label: "متوسطة" },
  { key: "high", label: "عالية" },
] as const;

export const CARE_ITEMS = [
  { key: "shower", label: "استحمام" },
  { key: "teeth", label: "تنظيف الأسنان" },
  { key: "clothes", label: "تغيير الملابس" },
  { key: "hair", label: "تمشيط/غسل الشعر" },
  { key: "face", label: "غسل الوجه" },
];
